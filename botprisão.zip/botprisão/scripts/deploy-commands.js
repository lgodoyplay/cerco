require('dotenv').config();

const fs = require('node:fs');
const path = require('node:path');
const { REST, Routes } = require('discord.js');

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else if (entry.isFile() && entry.name.endsWith('.js')) files.push(full);
  }
  return files;
}

async function main() {
  const token = process.env.DISCORD_TOKEN;
  let clientId = process.env.CLIENT_ID;
  const guildId = process.env.DEPLOY_GUILD_ID;

  if (!token) throw new Error('DISCORD_TOKEN não configurado no .env');

  const commandsPath = path.join(process.cwd(), 'src', 'commands');
  const files = fs.existsSync(commandsPath) ? walk(commandsPath) : [];
  const commands = [];

  for (const file of files) {
    const cmd = require(file);
    if (!cmd?.data?.name) continue;
    commands.push(cmd.data.toJSON());
  }

  const rest = new REST({ version: '10' }).setToken(token);

  async function resolveClientId() {
    if (clientId) return clientId;
    const app = await rest.get(Routes.oauth2CurrentApplication()).catch(() => null);
    const id = app?.id || null;
    if (!id) throw new Error('Não foi possível identificar o CLIENT_ID automaticamente.');
    clientId = id;
    return clientId;
  }

  async function deployWithClientId(id) {
    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(id, guildId), { body: commands });
      console.log(`Deploy concluído no servidor ${guildId}. Total: ${commands.length}`);
      return;
    }
    await rest.put(Routes.applicationCommands(id), { body: commands });
    console.log(`Deploy global concluído. Total: ${commands.length}`);
  }

  try {
    const id = await resolveClientId();
    await deployWithClientId(id);
  } catch (err) {
    if (err?.code === 10002) {
      clientId = null;
      const id = await resolveClientId();
      await deployWithClientId(id);
      return;
    }
    throw err;
  }
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
