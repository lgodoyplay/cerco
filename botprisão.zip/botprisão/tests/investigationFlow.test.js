const test = require('node:test');
const assert = require('node:assert/strict');

const { resolveInvestigationFinalChannel } = require('../src/modules/investigation/investigationFlow');

test('resolveInvestigationFinalChannel usa o canal de investigação como fallback quando o canal final não existe', async () => {
  const guild = {
    channels: {
      cache: new Map([
        ['investigation', { id: 'investigation', type: 0 }]
      ])
    }
  };

  const config = {
    channels: {
      investigationFinalChannelId: 'missing',
      investigationChannelId: 'investigation'
    }
  };

  const channel = await resolveInvestigationFinalChannel(guild, config);
  assert.equal(channel?.id, 'investigation');
});
