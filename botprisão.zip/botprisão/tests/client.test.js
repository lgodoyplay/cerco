const test = require('node:test');
const assert = require('node:assert/strict');

const { getIntentSettings } = require('../src/app/client');

test('habilita intents de membros e conteúdo por padrão quando a env não define nada', () => {
  const settings = getIntentSettings({});

  assert.equal(settings.enableMembers, true);
  assert.equal(settings.enableMessageContent, true);
});

test('respeita a configuração explícita false para intents', () => {
  const settings = getIntentSettings({ ENABLE_GUILD_MEMBERS_INTENT: 'false', ENABLE_MESSAGE_CONTENT_INTENT: 'false' });

  assert.equal(settings.enableMembers, false);
  assert.equal(settings.enableMessageContent, false);
});
