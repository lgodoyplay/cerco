const test = require('node:test');
const assert = require('node:assert/strict');

const { buildDisabledApprovalRow, resolveApprovalChannel, safeDeferReply } = require('../src/modules/verification/verificationFlow');

test('resolveApprovalChannel usa o canal de verificação como fallback quando o canal de aprovação não existe', async () => {
  const guild = {
    channels: {
      cache: new Map([
        ['verification', { id: 'verification', type: 0, isTextBased: () => true }]
      ])
    }
  };

  const config = {
    channels: {
      approvalChannelId: 'missing',
      verificationChannelId: 'verification'
    }
  };

  const channel = await resolveApprovalChannel(guild, config);
  assert.equal(channel?.id, 'verification');
});

test('buildDisabledApprovalRow desabilita botões sem quebrar quando a linha tiver outro componente', () => {
  const message = {
    components: [
      {
        components: [
          { data: { type: 2, custom_id: 'pc:roleApprove:test' } },
          { data: { type: 3, custom_id: 'pc:roleSelect:test' } }
        ]
      }
    ]
  };

  const row = buildDisabledApprovalRow(message);
  assert.ok(row);
  assert.equal(row.components[0].data.disabled, true);
  assert.equal(row.components[1].data.type, 3);
});

test('safeDeferReply não tenta deferir uma interação já respondida', async () => {
  const interaction = {
    deferred: false,
    replied: true,
    deferReply: async () => {
      throw new Error('should not defer');
    }
  };

  const result = await safeDeferReply(interaction);
  assert.equal(result, false);
});
