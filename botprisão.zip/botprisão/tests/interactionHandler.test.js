const test = require('node:test');
const assert = require('node:assert/strict');

const { getFriendlyErrorMessage } = require('../src/lib/handlers/interactions');

test('retorna mensagem específica para interação expirada ou desconhecida', () => {
  const message = getFriendlyErrorMessage({ code: 10062, message: 'Unknown interaction' }, 'abc123');

  assert.match(message, /expirou|já foi encerrada|tente novamente/i);
  assert.doesNotMatch(message, /Ocorreu um erro ao processar essa ação/i);
});
