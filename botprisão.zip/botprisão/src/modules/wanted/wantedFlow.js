const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ModalBuilder,
  PermissionsBitField,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  MessageFlags
} = require('discord.js');

const { BRAND } = require('../../config/constants');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { getWantedRecordById } = require('../../database/repositories/wantedRepository');

function canUseWanted(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return true;
  const allowed = new Set([config.roles?.corpRoleId, config.roles?.integration?.policeRoleId, ...(config.roles?.policeRoleIds ?? [])]);
  return [...allowed].some((roleId) => roleId && member.roles.cache.has(roleId));
}

function upsertField(embed, { name, value, inline = false }) {
  const next = EmbedBuilder.from(embed);
  const fields = Array.isArray(next.data.fields) ? [...next.data.fields] : [];
  const filtered = fields.filter((f) => String(f?.name || '') !== name);
  next.setFields(filtered);
  next.addFields({ name, value, inline });
  return next;
}

async function handleWantedCapturedButton(client, interaction) {
  const recordId = interaction.customId.split(':')[3];
  const record = await getWantedRecordById(recordId);
  if (!record) return await interaction.reply({ content: 'Registro não encontrado.', flags: MessageFlags.Ephemeral });

  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  if (!canUseWanted(config, member)) {
    return await interaction.reply({ content: 'Você não tem permissão para iniciar captura.', flags: MessageFlags.Ephemeral });
  }

  client.pendingCaptureStarts = client.pendingCaptureStarts || new Map();
  client.pendingCaptureStarts.set(`${interaction.guild.id}:${recordId}:${interaction.user.id}`, {
    messageId: interaction.message?.id || null,
    channelId: interaction.channelId
  });

  const modal = new ModalBuilder().setCustomId(`pc:wanted:captureModal:${recordId}`).setTitle('Processo de Captura');

  const by = new TextInputBuilder()
    .setCustomId('by')
    .setLabel('Preso por quem')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(60);

  const date = new TextInputBuilder()
    .setCustomId('date')
    .setLabel('Data da prisão (DD/MM/AAAA)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(10);

  const time = new TextInputBuilder()
    .setCustomId('time')
    .setLabel('Horário da prisão (HH:MM)')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(5);

  const notes = new TextInputBuilder()
    .setCustomId('notes')
    .setLabel('Observações da captura')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(900);

  modal.addComponents(
    new ActionRowBuilder().addComponents(by),
    new ActionRowBuilder().addComponents(date),
    new ActionRowBuilder().addComponents(time),
    new ActionRowBuilder().addComponents(notes)
  );

  await interaction.showModal(modal);
}

async function handleWantedCaptureModal(client, interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const recordId = interaction.customId.split(':')[3];
  const record = await getWantedRecordById(recordId);
  if (!record) return await interaction.editReply('Registro não encontrado.');

  const by = interaction.fields.getTextInputValue('by').trim();
  const date = interaction.fields.getTextInputValue('date').trim();
  const time = interaction.fields.getTextInputValue('time').trim();
  const notes = interaction.fields.getTextInputValue('notes')?.trim() || null;

  const channel = interaction.channel;
  if (!channel || channel.type !== ChannelType.GuildText) return await interaction.editReply('Canal inválido.');

  let message = null;
  const startKey = `${interaction.guild.id}:${recordId}:${interaction.user.id}`;
  const start = client.pendingCaptureStarts?.get(startKey) ?? null;
  if (start?.messageId) {
    message = await channel.messages.fetch(start.messageId).catch(() => null);
  }

  if (!message) {
    const messages = await channel.messages.fetch({ limit: 50 }).catch(() => null);
    message =
      messages?.find((m) => m.author?.bot && m.components?.some((r) => r.components?.some((c) => c.customId === `pc:wanted:captured:${recordId}`))) ??
      null;
  }

  if (!message) return await interaction.editReply('Não foi possível localizar a mensagem do procurado.');

  const captureValue =
    `Status: **EM PROCESSO DE CAPTURA**\n` +
    `Preso por: **${by}**\n` +
    `Data: **${date || '—'}**\n` +
    `Horário: **${time || '—'}**\n` +
    `Observações: ${notes || '—'}`;

  const currentEmbeds = Array.isArray(message.embeds) ? message.embeds : [];
  const first = currentEmbeds[0] ? EmbedBuilder.from(currentEmbeds[0]) : new EmbedBuilder().setColor(BRAND.colors.GRAY_DARK);
  if (!first.data.color) first.setColor(BRAND.colors.GRAY_DARK);

  const updatedFirst = upsertField(first, { name: '🚨 Captura', value: captureValue, inline: false });
  const updatedEmbeds = [updatedFirst, ...currentEmbeds.slice(1).map((e) => EmbedBuilder.from(e))];

  const disabledCaptureRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`pc:wanted:captured:${recordId}`).setLabel('JÁ FOI PRESO').setStyle(ButtonStyle.Danger).setDisabled(true)
  );

  const otherRows = (message?.components || []).slice(1);
  await message.edit({ embeds: updatedEmbeds, components: [disabledCaptureRow, ...otherRows] }).catch(() => {});

  const key = `${interaction.guild.id}:${recordId}`;
  client.pendingCaptures = client.pendingCaptures || new Map();
  client.pendingCaptures.set(key, {
    recordId,
    wantedId: record.wanted_id,
    officerId: interaction.user.id,
    messageId: message?.id || null,
    channelId: channel.id,
    by,
    date,
    time,
    notes
  });

  client.pendingCaptureStarts?.delete(startKey);

  await interaction.editReply('Captura registrada. O procurado será removido somente após você finalizar a prisão no sistema de prisões.');
}

module.exports = { handleWantedCapturedButton, handleWantedCaptureModal };
