const { handleWantedCapturedButton, handleWantedCaptureModal } = require('./wantedFlow');
module.exports = { handleWantedCapturedButton, handleWantedCaptureModal };
