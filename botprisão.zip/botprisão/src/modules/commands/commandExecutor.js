const { MessageFlags } = require('discord.js');
const { logger } = require('../../lib/logger');

function getCooldownKey(commandName, userId) {
  return `${commandName}:${userId}`;
}

async function handleCommandInteraction(client, interaction) {
  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  const now = Date.now();
  const cooldownMs = Number(command.cooldownMs ?? 3000);
  const key = getCooldownKey(command.data.name, interaction.user.id);
  const expiresAt = client.cooldowns.get(key) ?? 0;

  if (expiresAt > now) {
    const seconds = Math.ceil((expiresAt - now) / 1000);
    return await interaction.reply({
      content: `Aguarde ${seconds}s para usar esse comando novamente.`,
      flags: MessageFlags.Ephemeral
    });
  }

  client.cooldowns.set(key, now + cooldownMs);

  try {
    await command.execute(client, interaction);
  } catch (err) {
    logger.error({ err, command: command.data.name }, 'Erro no comando');
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp({ content: 'Ocorreu um erro ao executar esse comando.', flags: MessageFlags.Ephemeral }).catch(() => {});
    } else {
      await interaction.reply({ content: 'Ocorreu um erro ao executar esse comando.', flags: MessageFlags.Ephemeral }).catch(() => {});
    }
  }
}

module.exports = { handleCommandInteraction };
