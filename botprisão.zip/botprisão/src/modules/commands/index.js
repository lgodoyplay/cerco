const { handleCommandInteraction } = require('./commandExecutor');
module.exports = { handleCommandInteraction };
