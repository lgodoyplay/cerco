const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ModalBuilder,
  PermissionsBitField,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags
} = require('discord.js');
const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { BRAND } = require('../../config/constants');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { createPromotionRequest, getPromotionRequestById, updatePromotionRequest } = require('../../database/repositories/promotionRepository');
const { logger } = require('../../lib/logger');

const PROMOTION_RANKS = [
  { label: 'Jovem Aprendiz', roleId: '1504276295435944088' },
  { label: 'Aluno', roleId: '1504276479062708244' },
  { label: 'Agente', roleId: '1504276571056242708' },
  { label: 'Agente Especial', roleId: '1504276722634326156' },
  { label: 'Recrutador', roleId: '1504276727457775737' },
  { label: 'Escrivão', roleId: '1504277702327140493' },
  { label: 'Investigativo', roleId: '1504277687940812810' },
  { label: 'Comissário', roleId: '1504277882611175527' },
  { label: 'Procurador', roleId: '1504277886687776882' },
  { label: 'Procurador Geral', roleId: '1504277889506476082' },
  { label: 'Sub Comando', roleId: '1504278173775429793' },
  { label: 'Comando', roleId: '1504278162664587344' },
  { label: 'Delegado Adjunto', roleId: '1504278297482104902' },
  { label: 'Delegado Titular', roleId: '1504278317514096761' },
  { label: 'Delegado Geral', roleId: '1504278464558010428' }
];

const PROMOTION_RANK_IDS = new Set(PROMOTION_RANKS.map((r) => r.roleId));

const PROMOTION_PANEL_CHANNEL_ID = '1531064935285526528';
const PROMOTION_LOG_CHANNEL_ID = '1531064997155835954';

function buildPromotionPanelEmbed() {
  return baseEmbed({
    title: '📈 Solicitação de Promoção',
    description:
      'Caso sua patente no Discord esteja diferente da patente que você possui dentro do jogo, utilize este sistema para solicitar a atualização.\n\n' +
      '⚠️ Este sistema NÃO deve ser utilizado para solicitar promoções comuns.\n\n' +
      'Solicitações indevidas poderão ser recusadas.\n\n' +
      'Após enviar sua solicitação, aguarde a análise da equipe responsável.'
  }).setColor(BRAND.colors.GRAY_DARK);
}

function buildPromotionSelectRow() {
  const select = new StringSelectMenuBuilder()
    .setCustomId('pc:promotion:select')
    .setPlaceholder('Selecione sua patente')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(
      PROMOTION_RANKS.map((r) => ({
        label: r.label,
        value: r.roleId,
        description: `Patente: ${r.label}`
      }))
    );

  return new ActionRowBuilder().addComponents(select);
}

function buildPromotionModal(selectedRankId) {
  const rank = PROMOTION_RANKS.find((r) => r.roleId === selectedRankId);
  const rankLabel = rank ? rank.label : 'Patente';

  const modal = new ModalBuilder()
    .setCustomId(`pc:promotion:modal:${selectedRankId}`)
    .setTitle(`Solicitação de Promoção — ${rankLabel}`);

  const nameInput = new TextInputBuilder()
    .setCustomId('name')
    .setLabel('Nome RP')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(32);

  const passportInput = new TextInputBuilder()
    .setCustomId('passport')
    .setLabel('Passaporte')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(10);

  const currentRankInput = new TextInputBuilder()
    .setCustomId('currentRank')
    .setLabel('Patente Atual no Jogo')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(40);

  const reasonInput = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Justificativa')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1200)
    .setPlaceholder('Ex: No jogo já fui promovido para Investigador, porém no Discord ainda estou como Agente.');

  modal.addComponents(
    new ActionRowBuilder().addComponents(nameInput),
    new ActionRowBuilder().addComponents(passportInput),
    new ActionRowBuilder().addComponents(currentRankInput),
    new ActionRowBuilder().addComponents(reasonInput)
  );

  return modal;
}

function buildPromotionRequestEmbed({ requesterId, inGameName, passport, requestedRoleId, currentRank, reason }) {
  const ts = Math.floor(Date.now() / 1000);
  const rankLabel = PROMOTION_RANKS.find((r) => r.roleId === requestedRoleId)?.label ?? '—';

  const embed = baseEmbed({
    title: '📈 NOVA SOLICITAÇÃO DE PROMOÇÃO',
    description: 'Correção de patente • Aguardando análise'
  }).setColor(BRAND.colors.GRAY_DARK);

  embed.addFields(
    { name: '👤 Solicitante', value: `<@${requesterId}>`, inline: false },
    { name: '📛 Nome RP', value: `**${inGameName || '—'}**`, inline: true },
    { name: '📌 Passaporte', value: `**${passport || '—'}**`, inline: true },
    { name: '🎖️ Patente Solicitada', value: `**${rankLabel}**\n<@&${requestedRoleId}>`, inline: false },
    { name: '📋 Patente Atual no Jogo', value: currentRank || '—', inline: true },
    { name: '📝 Justificativa', value: reason || '—', inline: false },
    { name: '📅 Data da Solicitação', value: `<t:${ts}:F>`, inline: false },
    { name: '📌 Status', value: 'PENDENTE', inline: true }
  );

  return embed;
}

function buildPromotionActionRow(requestId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`pc:promotion:approve:${requestId}`)
      .setLabel('✅ APROVAR')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`pc:promotion:deny:${requestId}`)
      .setLabel('❌ RECUSAR')
      .setStyle(ButtonStyle.Danger)
  );
}

function canReview(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return true;
  return Boolean(config?.roles?.recruiterRoleId && member.roles.cache.has(config.roles.recruiterRoleId));
}

function buildPromotionResultEmbed(originalEmbed, status, reviewerId, reviewerTag) {
  const embed = EmbedBuilder.from(originalEmbed);
  const ts = Math.floor(Date.now() / 1000);

  const statusLabel = status === 'APPROVED' ? 'APROVADA' : 'RECUSADA';
  const statusColor = status === 'APROVED' ? BRAND.colors.BLUE : BRAND.colors.GRAY_DARK;

  embed.setColor(statusColor);

  const existingStatus = embed.fields.find((f) => f.name === '📌 Status');
  if (existingStatus) {
    embed.spliceFields(embed.fields.indexOf(existingStatus), 1);
  }

  embed.addFields(
    { name: '📌 Status', value: statusLabel, inline: true },
    { name: '🛡️ Responsável', value: `<@${reviewerId}>`, inline: true },
    { name: '📅 Data da Análise', value: `<t:${ts}:F>`, inline: false }
  );

  return embed;
}

async function handlePromotionButton(client, interaction) {
  if (interaction.customId !== 'pc:promotion:open') return;
  return await interaction.reply({
    flags: MessageFlags.Ephemeral,
    embeds: [buildPromotionPanelEmbed()],
    components: [buildPromotionSelectRow()]
  });
}

async function handlePromotionSelect(client, interaction) {
  if (interaction.customId !== 'pc:promotion:select') return;
  const roleId = interaction.values?.[0] || null;
  if (!roleId) return await interaction.reply({ content: 'Selecione uma patente válida.', flags: MessageFlags.Ephemeral }).catch(() => {});
  return await interaction.showModal(buildPromotionModal(roleId));
}

async function handlePromotionModal(client, interaction) {
  if (!interaction.customId.startsWith('pc:promotion:modal:')) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const guild = interaction.guild;
  if (!guild) return await interaction.editReply('Essa ação só pode ser usada dentro de um servidor.');

  const selectedRankId = interaction.customId.split(':')[3] || null;
  if (!selectedRankId) return await interaction.editReply('Patente inválida.');

  const inGameName = interaction.fields.getTextInputValue('name').trim();
  const passport = interaction.fields.getTextInputValue('passport').trim();
  const currentRank = interaction.fields.getTextInputValue('currentRank').trim();
  const reason = interaction.fields.getTextInputValue('reason').trim();

  if (!inGameName || !passport || !currentRank || !reason) {
    return await interaction.editReply('Todos os campos são obrigatórios.');
  }

  const logChannel = guild.channels.cache.get(PROMOTION_LOG_CHANNEL_ID);
  if (!logChannel || logChannel.type !== ChannelType.GuildText) {
    return await interaction.editReply('Canal de solicitações de promoção não configurado ou inválido.');
  }

  const embed = buildPromotionRequestEmbed({
    requesterId: interaction.user.id,
    inGameName,
    passport,
    requestedRoleId: selectedRankId,
    currentRank,
    reason
  });

  const request = await createPromotionRequest({
    guildId: guild.id,
    requesterId: interaction.user.id,
    requestedRoleId: selectedRankId,
    inGameName,
    passport,
    currentRank,
    reason,
    channelId: logChannel.id,
    messageId: null
  }).catch(() => null);

  if (!request) return await interaction.editReply('Falha ao registrar sua solicitação.');

  const row = buildPromotionActionRow(request.id);

  const sent = await logChannel
    .send({ embeds: [embed], components: [row], allowedMentions: { parse: [] } })
    .catch(() => null);

  if (!sent) return await interaction.editReply('Falha ao enviar sua solicitação. Tente novamente.');

  await updatePromotionRequest(request.id, {
    messageId: sent.id,
    channelId: logChannel.id
  }).catch(() => {});

  return await interaction.editReply('Solicitação de promoção enviada com sucesso. Aguarde a análise da equipe responsável.');
}

async function handlePromotionApprove(client, interaction) {
  if (!interaction.customId.startsWith('pc:promotion:approve:')) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const guild = interaction.guild;
  if (!guild) return await interaction.editReply('Essa ação só pode ser usada dentro de um servidor.');

  const config = await getOrCreateGuildConfig(guild.id);
  const reviewer = await guild.members.fetch(interaction.user.id).catch(() => null);
  if (!canReview(config, reviewer)) {
    return await interaction.editReply('Você não tem permissão para aprovar solicitações de promoção.');
  }

  const requestId = interaction.customId.split('pc:promotion:approve:')[1];
  if (!requestId) return await interaction.editReply('ID da solicitação inválido.');

  const request = await getPromotionRequestById(requestId);
  if (!request) return await interaction.editReply('Solicitação não encontrada.');

  if (request.status !== 'PENDING') return await interaction.editReply('Essa solicitação já foi analisada.');

  const target = await guild.members.fetch(request.requester_id).catch(() => null);
  if (!target) return await interaction.editReply('O solicitante não está mais no servidor.');

  const ranksToRemove = target.roles.cache.filter((role) => PROMOTION_RANK_IDS.has(role.id));
  if (ranksToRemove.size > 0) {
    await target.roles.remove([...ranksToRemove.keys()]).catch((err) => {
      logger.error({ err, targetId: target.id }, 'Falha ao remover patentes policiais');
    });
  }

  const rankRole = guild.roles.cache.get(request.requested_role_id) ?? (await guild.roles.fetch(request.requested_role_id).catch(() => null));
  if (rankRole) {
    await target.roles.add(rankRole).catch((err) => {
      logger.error({ err, targetId: target.id, roleId: request.requested_role_id }, 'Falha ao aplicar nova patente');
    });
  }

  await updatePromotionRequest(requestId, {
    status: 'APPROVED',
    reviewed_by: interaction.user.id,
    reviewed_at: new Date().toISOString()
  });

  try {
    const originalEmbed = interaction.message.embeds?.[0] ? EmbedBuilder.from(interaction.message.embeds[0]) : null;
    if (originalEmbed) {
      const updatedEmbed = buildPromotionResultEmbed(originalEmbed, 'APPROVED', interaction.user.id, interaction.user.tag);
      const disabledRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`pc:promotion:approve:${requestId}`).setLabel('✅ APROVAR').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId(`pc:promotion:deny:${requestId}`).setLabel('❌ RECUSAR').setStyle(ButtonStyle.Danger).setDisabled(true)
      );
      await interaction.message.edit({ embeds: [updatedEmbed], components: [disabledRow] }).catch(() => {});
    }
  } catch {}

  return await interaction.editReply('Solicitação aprovada e patente atualizada com sucesso.');
}

async function handlePromotionDeny(client, interaction) {
  if (!interaction.customId.startsWith('pc:promotion:deny:')) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const guild = interaction.guild;
  if (!guild) return await interaction.editReply('Essa ação só pode ser usada dentro de um servidor.');

  const config = await getOrCreateGuildConfig(guild.id);
  const reviewer = await guild.members.fetch(interaction.user.id).catch(() => null);
  if (!canReview(config, reviewer)) {
    return await interaction.editReply('Você não tem permissão para recusar solicitações de promoção.');
  }

  const requestId = interaction.customId.split('pc:promotion:deny:')[1];
  if (!requestId) return await interaction.editReply('ID da solicitação inválido.');

  const request = await getPromotionRequestById(requestId);
  if (!request) return await interaction.editReply('Solicitação não encontrada.');

  if (request.status !== 'PENDING') return await interaction.editReply('Essa solicitação já foi analisada.');

  await updatePromotionRequest(requestId, {
    status: 'DENIED',
    reviewed_by: interaction.user.id,
    reviewed_at: new Date().toISOString()
  });

  try {
    const originalEmbed = interaction.message.embeds?.[0] ? EmbedBuilder.from(interaction.message.embeds[0]) : null;
    if (originalEmbed) {
      const updatedEmbed = buildPromotionResultEmbed(originalEmbed, 'DENIED', interaction.user.id, interaction.user.tag);
      const disabledRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`pc:promotion:approve:${requestId}`).setLabel('✅ APROVAR').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId(`pc:promotion:deny:${requestId}`).setLabel('❌ RECUSAR').setStyle(ButtonStyle.Danger).setDisabled(true)
      );
      await interaction.message.edit({ embeds: [updatedEmbed], components: [disabledRow] }).catch(() => {});
    }
  } catch {}

  return await interaction.editReply('Solicitação recusada.');
}

module.exports = {
  buildPromotionPanelEmbed,
  handlePromotionButton,
  handlePromotionSelect,
  handlePromotionModal,
  handlePromotionApprove,
  handlePromotionDeny
};