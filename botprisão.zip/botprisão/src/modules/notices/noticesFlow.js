const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  PermissionsBitField,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  MessageFlags
} = require('discord.js');

const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { BRAND } = require('../../config/constants');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { logger } = require('../../lib/logger');

function canCreateNotice(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return true;
  return Boolean(config?.roles?.recruiterRoleId && member.roles.cache.has(config.roles.recruiterRoleId));
}

function buildNoticesPanelEmbed() {
  const embed = baseEmbed({
    title: '📢 CENTRAL DE AVISOS',
    description:
      '📌 Sistema oficial de avisos\n' +
      '📌 Comunicados institucionais\n' +
      '📌 Informações importantes da corporação\n\n' +
      '⚠️ Utilize corretamente o sistema de avisos.\n\n' +
      'Clique no botão abaixo para criar um comunicado.'
  }).setColor(BRAND.colors.GRAY_DARK);

  embed.addFields({
    name: '🔒 Permissão',
    value: 'Apenas cargos autorizados podem criar avisos.',
    inline: false
  });

  return embed;
}

function buildNoticeModal() {
  const modal = new ModalBuilder().setCustomId('pc:notices:modal').setTitle('Criar Aviso — Central Oficial');

  const title = new TextInputBuilder()
    .setCustomId('title')
    .setLabel('Título do aviso')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(80);

  const description = new TextInputBuilder()
    .setCustomId('description')
    .setLabel('Descrição do aviso')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1500);

  const type = new TextInputBuilder()
    .setCustomId('type')
    .setLabel('Tipo do aviso')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(30)
    .setPlaceholder('Ex: Aviso Geral / Reunião / Treinamento / Operação / Sistema / Atualização / Emergência');

  const priority = new TextInputBuilder()
    .setCustomId('priority')
    .setLabel('Prioridade')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(20)
    .setPlaceholder('Ex: Baixa / Média / Alta / Urgente');

  const notes = new TextInputBuilder()
    .setCustomId('notes')
    .setLabel('Observações adicionais (opcional)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(900);

  modal.addComponents(
    new ActionRowBuilder().addComponents(title),
    new ActionRowBuilder().addComponents(description),
    new ActionRowBuilder().addComponents(type),
    new ActionRowBuilder().addComponents(priority),
    new ActionRowBuilder().addComponents(notes)
  );

  return modal;
}

function buildNoticeEmbed({ title, description, type, priority, notes, creatorId }) {
  const embed = baseEmbed({
    title: '📢 NOVO AVISO OFICIAL',
    description: 'Comunicado institucional • Central oficial'
  }).setColor(BRAND.colors.GRAY_DARK);

  embed.addFields(
    { name: '📌 Título', value: `**${title}**`, inline: false },
    { name: '📂 Tipo', value: `**${type}**`, inline: true },
    { name: '⚠️ Prioridade', value: `**${priority}**`, inline: true },
    { name: '📝 Descrição', value: description, inline: false },
    { name: '👤 Criado por', value: `<@${creatorId}>`, inline: true },
    { name: '📅 Data/Hora', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
  );

  if (notes) {
    embed.addFields({ name: '🗒️ Observações', value: notes, inline: false });
  }

  return embed;
}

async function handleNoticesButton(client, interaction) {
  if (interaction.customId !== 'pc:notices:create') return;

  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  if (!canCreateNotice(config, member)) {
    return await interaction.reply({ content: 'Você não tem permissão para criar avisos.', flags: MessageFlags.Ephemeral });
  }

  return await interaction.showModal(buildNoticeModal());
}

async function handleNoticesModal(client, interaction) {
  if (interaction.customId !== 'pc:notices:modal') return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const guild = interaction.guild;
  if (!guild) return await interaction.editReply('Essa ação só pode ser usada dentro de um servidor.');

  const config = await getOrCreateGuildConfig(guild.id);
  const member = await guild.members.fetch(interaction.user.id).catch(() => null);
  if (!canCreateNotice(config, member)) {
    return await interaction.editReply('Você não tem permissão para criar avisos.');
  }

  const title = interaction.fields.getTextInputValue('title').trim();
  const description = interaction.fields.getTextInputValue('description').trim();
  const type = interaction.fields.getTextInputValue('type').trim();
  const priority = interaction.fields.getTextInputValue('priority').trim();
  const notes = interaction.fields.getTextInputValue('notes')?.trim() || null;

  const noticeChannelId = config.channels.noticesChannelId || '1504549601770737775';
  const noticeChannel =
    guild.channels.cache.get(noticeChannelId) || (await guild.channels.fetch(noticeChannelId).catch(() => null));
  if (!noticeChannel || !noticeChannel.isTextBased?.() || noticeChannel.type === ChannelType.DM) {
    return await interaction.editReply('Canal de avisos não configurado ou inválido.');
  }

  const embed = buildNoticeEmbed({
    title,
    description,
    type,
    priority,
    notes,
    creatorId: interaction.user.id
  });

  const sent = await noticeChannel
    .send({ content: '@everyone', embeds: [embed], allowedMentions: { parse: ['everyone'] } })
    .catch(() => null);

  logger.info(
    {
      guildId: guild.id,
      creatorId: interaction.user.id,
      noticeChannelId: noticeChannel.id,
      messageId: sent?.id || null,
      type,
      priority
    },
    'Aviso enviado'
  );

  if (!sent) return await interaction.editReply('Falha ao enviar o aviso no canal configurado.');
  return await interaction.editReply(`Aviso enviado com sucesso: ${sent.url}`);
}

module.exports = { buildNoticesPanelEmbed, handleNoticesButton, handleNoticesModal };
