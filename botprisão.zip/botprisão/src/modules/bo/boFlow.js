const { ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags } = require('discord.js');
const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { createBORecord } = require('../../database/repositories/boRepository');

const BO_SAVE_CHANNEL_ID = '1504303762653843658';

async function handleBOButton(client, interaction) {
  const modal = new ModalBuilder().setCustomId('pc:boModal').setTitle('Boletim de Ocorrência (BO)');

  const requesterName = new TextInputBuilder()
    .setCustomId('requesterName')
    .setLabel('Nome do solicitante')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(50);

  const requesterId = new TextInputBuilder()
    .setCustomId('requesterId')
    .setLabel('ID do solicitante')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(20);

  const occurred = new TextInputBuilder()
    .setCustomId('occurred')
    .setLabel('Ocorrido')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1500);

  const links = new TextInputBuilder()
    .setCustomId('links')
    .setLabel('Links (opcional)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(1500);

  modal.addComponents(
    new ActionRowBuilder().addComponents(requesterName),
    new ActionRowBuilder().addComponents(requesterId),
    new ActionRowBuilder().addComponents(occurred),
    new ActionRowBuilder().addComponents(links)
  );

  await interaction.showModal(modal);
}

async function handleBOModal(client, interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const record = await createBORecord({
    guildId: interaction.guild.id,
    authorId: interaction.user.id,
    requesterName: interaction.fields.getTextInputValue('requesterName').trim(),
    requesterId: interaction.fields.getTextInputValue('requesterId').trim(),
    occurred: interaction.fields.getTextInputValue('occurred').trim(),
    links: interaction.fields.getTextInputValue('links')?.trim() || null
  });

  const embed = baseEmbed({
    title: 'Boletim de Ocorrência',
    description:
      `Autor: <@${record.author_id}>\n` +
      `Solicitante: **${record.requester_name}** (ID: **${record.requester_id}**)\n\n` +
      `Ocorrido:\n${record.occurred}\n\n` +
      (record.links ? `Links:\n${record.links}` : '')
  });

  const channel =
    interaction.guild.channels.cache.get(BO_SAVE_CHANNEL_ID) ??
    interaction.guild.channels.cache.get(config.channels.boLogChannelId);
  if (channel) await channel.send({ embeds: [embed] }).catch(() => {});

  await interaction.editReply('BO enviado e registrado com sucesso.');
}

module.exports = { handleBOButton, handleBOModal };
