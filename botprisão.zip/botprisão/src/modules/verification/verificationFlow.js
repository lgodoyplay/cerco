const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  PermissionsBitField,
  MessageFlags
} = require('discord.js');

const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { logger } = require('../../lib/logger');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { createRoleSelectionRequest, getRoleSelectionRequestById, updateRoleSelectionRequest } = require('../../database/repositories/roleRequestRepository');
const { upsertMemberProfile } = require('../../database/repositories/memberRepository');

// Fluxo de verificação:
// 1) Botão "INICIAR VERIFICAÇÃO" abre painel de categorias (ephemeral)
// 2) Categoria -> menu de cargos (ephemeral)
// 3) Cargo -> modal (nome/passaporte/departamento/observações)
// 4) Salva perfil, altera nickname e aplica cargo Verificado
// 5) Envia solicitação para o canal de aprovação (Aprovar/Recusar)
const ROLE_OPTIONS = [
  { label: 'Delegado Geral', value: '1504278464558010428' },
  { label: 'Delegado Titular', value: '1504278317514096761' },
  { label: 'Delegado Adjunto', value: '1504278297482104902' },
  { label: 'Comando', value: '1504278162664587344' },
  { label: 'Sub Comando', value: '1504278173775429793' },
  { label: 'Procurador Geral', value: '1504277889506476082' },
  { label: 'Procurador', value: '1504277886687776882' },
  { label: 'Comissário', value: '1504277882611175527' },
  { label: 'Investigativo', value: '1504277687940812810' },
  { label: 'Escrivão', value: '1504277702327140493' },
  { label: 'Perito Criminal', value: '1504276730980991056' },
  { label: 'Recrutador', value: '1504276727457775737' },
  { label: 'Agente Especial', value: '1504276722634326156' },
  { label: 'Agente', value: '1504276571056242708' },
  { label: 'Aluno', value: '1504276479062708244' },
  { label: 'Jovem Aprendiz', value: '1504276295435944088' },
  { label: 'Policial', value: '1504279682965835916' },
  { label: 'Hospital', value: '1504280015569686580' },
  { label: 'SSP', value: '1504557672236847274' },
  { label: 'Jurídico', value: '1504559090838278295' }
];

const CATEGORY_OPTIONS = [
  { label: '📁 Integração', value: 'INTEGRACAO', description: 'Jovem Aprendiz • Aluno' },
  { label: '🏢 Administrativo', value: 'ADMIN', description: 'Investigativo • Escrivão • Perito • Agentes' },
  { label: '👑 Alto Escalão', value: 'ALTO', description: 'Comando • Procuradoria • Comissariado' },
  { label: '🦅 DEGEN', value: 'DEGEN', description: 'Delegados' },
  { label: '🏛️ Integração Governamental', value: 'GOV', description: 'SSP • Hospital • Policial • Jurídico' }
];

const CATEGORY_ROLE_IDS = {
  INTEGRACAO: ['1504276295435944088', '1504276479062708244'],
  ADMIN: ['1504277687940812810', '1504277702327140493', '1504276730980991056', '1504276722634326156', '1504276571056242708'],
  ALTO: ['1504278162664587344', '1504278173775429793', '1504277889506476082', '1504277886687776882', '1504277882611175527'],
  DEGEN: ['1504278464558010428', '1504278317514096761', '1504278297482104902'],
  GOV: ['1504557672236847274', '1504280015569686580', '1504279682965835916', '1504559090838278295']
};

function categoryLabel(category) {
  return CATEGORY_OPTIONS.find((c) => c.value === category)?.label ?? category;
}

function buildVerificationStartEmbed() {
  return baseEmbed({
    title: '🛡️ Verificação Institucional',
    description:
      '📌 Verificação institucional\n' +
      '📌 Seleção de departamento\n' +
      '📌 Integração automática\n' +
      '📌 Organização de cargos\n\n' +
      '⚠️ Preencha corretamente todas as informações.\n\n' +
      'Selecione a categoria para continuar.'
  });
}

function buildCategorySelectRow() {
  const select = new StringSelectMenuBuilder()
    .setCustomId('pc:verifyCategory')
    .setPlaceholder('Selecione uma categoria')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(CATEGORY_OPTIONS);

  return new ActionRowBuilder().addComponents(select);
}

function buildRoleSelectEmbed(category) {
  return baseEmbed({
    title: '📂 Seleção de Departamento',
    description:
      `Categoria: **${categoryLabel(category)}**\n\n` +
      'Agora selecione o cargo correspondente.'
  });
}

function buildRoleSelectRow(category) {
  const roleIds = CATEGORY_ROLE_IDS[category] ?? [];
  const options = ROLE_OPTIONS.filter((o) => roleIds.includes(o.value)).slice(0, 25);

  const select = new StringSelectMenuBuilder()
    .setCustomId(`pc:verifyRole:${category}`)
    .setPlaceholder('Selecione um cargo')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(options);

  return new ActionRowBuilder().addComponents(select);
}

function buildBackRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pc:verifyBack').setLabel('Voltar').setStyle(ButtonStyle.Secondary)
  );
}

function buildRoleApprovalButtons(requestId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`pc:roleApprove:${requestId}`).setLabel('Aprovar').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`pc:roleDeny:${requestId}`).setLabel('Recusar').setStyle(ButtonStyle.Danger)
  );
}

function buildVerificationApprovalEmbed({ userId, category, department, selectedRoleIds, notes }) {
  const selectedLabels = ROLE_OPTIONS.filter((opt) => selectedRoleIds.includes(opt.value)).map((opt) => opt.label);
  return baseEmbed({
    title: 'Solicitação de Verificação / Set',
    description:
      `Solicitante: <@${userId}>\n\n` +
      `Categoria: **${category ? categoryLabel(category) : '—'}**\n` +
      `Departamento: **${department || '—'}**\n\n` +
      `Cargo selecionado:\n- ${selectedLabels.join('\n- ') || '—'}\n\n` +
      (notes ? `Observações:\n${notes}` : 'Observações: —')
  });
}

function parseVerificationModalCustomId(customId) {
  const parts = String(customId || '').split(':');
  return {
    category: parts[2] || null,
    selectedRoleId: parts[3] || null
  };
}

async function sendVerificationApprovalRequest({ guild, config, interaction, request, selectedRoleIds, category, department, notes }) {
  const approvalChannel = await resolveApprovalChannel(guild, config);
  if (!approvalChannel) {
    logger.warn({ guildId: guild.id, userId: interaction.user.id }, 'Nenhum canal de aprovação disponível para a solicitação de verificação');
    return false;
  }

  const approvalEmbed = buildVerificationApprovalEmbed({
    userId: interaction.user.id,
    category,
    department,
    selectedRoleIds,
    notes
  });
  const row = buildRoleApprovalButtons(request.id);

  try {
    await approvalChannel.send({ embeds: [approvalEmbed], components: [row] });
    return true;
  } catch (err) {
    logger.error({ err, guildId: guild.id, userId: interaction.user.id }, 'Falha ao enviar solicitação de verificação para aprovação');

    const fallbackChannel = [...(guild.channels.cache?.values?.() || [])].find(
      (channel) => channel?.type === ChannelType.GuildText && channel?.isTextBased?.() && channel.id !== approvalChannel.id
    );

    if (fallbackChannel) {
      try {
        await fallbackChannel.send({ embeds: [approvalEmbed], components: [row] });
        return true;
      } catch (fallbackErr) {
        logger.error({ err: fallbackErr, guildId: guild.id, userId: interaction.user.id }, 'Falha ao enviar solicitação de verificação para canal alternativo');
      }
    }

    return false;
  }
}

async function safeDeferReply(interaction) {
  if (interaction.deferred || interaction.replied) return false;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});
  return true;
}

function buildDisabledApprovalRow(message) {
  const row = new ActionRowBuilder();
  const buttons = [];

  const existingComponents = message?.components?.[0]?.components || [];
  for (const component of existingComponents) {
    if (component?.data?.type === 2) {
      buttons.push(ButtonBuilder.from(component).setDisabled(true));
    } else if (component) {
      buttons.push(component);
    }
  }

  if (!buttons.length) {
    buttons.push(
      new ButtonBuilder().setCustomId('pc:roleApprove:disabled').setLabel('Aprovar').setStyle(ButtonStyle.Success).setDisabled(true)
    );
  }

  row.addComponents(...buttons);
  return row;
}

async function resolveApprovalChannel(guild, config) {
  if (!guild?.channels) return null;

  const channelId = config?.channels?.approvalChannelId || config?.channels?.verificationChannelId;
  if (channelId) {
    const cached = guild.channels.cache?.get?.(channelId);
    if (cached) return cached;

    if (typeof guild.channels.fetch === 'function') {
      const fetched = await guild.channels.fetch(channelId).catch(() => null);
      if (fetched) return fetched;
    }
  }

  const cacheValues = guild.channels.cache?.values?.() || [];
  for (const channel of cacheValues) {
    if (channel?.type === ChannelType.GuildText && channel?.isTextBased?.()) {
      return channel;
    }
  }

  return null;
}

async function handleVerificationButton(client, interaction) {
  if (interaction.deferred || interaction.replied) {
    return await interaction.followUp({
      flags: MessageFlags.Ephemeral,
      embeds: [buildVerificationStartEmbed()],
      components: [buildCategorySelectRow()]
    }).catch(() => {});
  }

  return await interaction.reply({
    flags: MessageFlags.Ephemeral,
    embeds: [buildVerificationStartEmbed()],
    components: [buildCategorySelectRow()]
  }).catch(() => {});
}

async function handleVerificationModal(client, interaction) {
  if (interaction.isButton?.() && interaction.customId === 'pc:verifyBack') {
    return await interaction.update({ embeds: [buildVerificationStartEmbed()], components: [buildCategorySelectRow()] }).catch(() => {});
  }

  if (interaction.isStringSelectMenu?.() && interaction.customId === 'pc:verifyCategory') {
    const category = interaction.values[0];
    return await interaction.update({
      embeds: [buildRoleSelectEmbed(category)],
      components: [buildRoleSelectRow(category), buildBackRow()]
    });
  }

  if (interaction.isStringSelectMenu?.() && interaction.customId.startsWith('pc:verifyRole:')) {
    const category = interaction.customId.split(':')[2];
    const roleId = interaction.values[0];

    const modal = new ModalBuilder().setCustomId(`pc:verifyModal:${category}:${roleId}`).setTitle('Identificação — Polícia Civil');

    const nameInput = new TextInputBuilder()
      .setCustomId('name')
      .setLabel('Nome RP')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(32);

    const passportInput = new TextInputBuilder()
      .setCustomId('passport')
      .setLabel('Passaporte')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(10);

    const deptInput = new TextInputBuilder()
      .setCustomId('department')
      .setLabel('Departamento')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(40)
      .setValue(categoryLabel(category).replace(/^[^\w]+/g, '').trim().slice(0, 40));

    const notesInput = new TextInputBuilder()
      .setCustomId('notes')
      .setLabel('Observações (opcional)')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setMaxLength(900);

    modal.addComponents(
      new ActionRowBuilder().addComponents(nameInput),
      new ActionRowBuilder().addComponents(passportInput),
      new ActionRowBuilder().addComponents(deptInput),
      new ActionRowBuilder().addComponents(notesInput)
    );

    try {
      return await interaction.showModal(modal);
    } catch (err) {
      logger.warn({ err, customId: interaction.customId, userId: interaction.user.id }, 'Falha ao abrir modal de verificação');
      return await interaction.reply({ content: 'Não foi possível abrir o formulário agora. Tente novamente.', flags: MessageFlags.Ephemeral }).catch(() => {});
    }
  }

  await safeDeferReply(interaction);

  const guild = interaction.guild;
  if (!guild) return await interaction.editReply('Essa ação só pode ser usada dentro de um servidor.');

  const config = await getOrCreateGuildConfig(guild.id);
  const { category, selectedRoleId } = parseVerificationModalCustomId(interaction.customId);

  const inGameName = interaction.fields.getTextInputValue('name').trim();
  const passport = interaction.fields.getTextInputValue('passport').trim();
  const department = interaction.fields.getTextInputValue('department').trim();
  const notes = interaction.fields.getTextInputValue('notes')?.trim() || null;

  const nickname = `${inGameName} ┃ ${passport}`;

  const member = await guild.members.fetch(interaction.user.id).catch(() => null);
  if (!member) return await interaction.editReply('Não foi possível localizar seu membro no servidor.');

  await upsertMemberProfile({
    guildId: guild.id,
    userId: interaction.user.id,
    inGameName,
    passport,
    verifiedAt: new Date().toISOString(),
    nickname
  });

  await member.setNickname(nickname).catch(() => {});

  const verifiedRoleId = config.roles.verifiedRoleId;
  if (verifiedRoleId) await member.roles.add(verifiedRoleId).catch(() => {});

  const request = await createRoleSelectionRequest({ guildId: guild.id, userId: interaction.user.id });

  const selectedRoleIds = selectedRoleId ? [selectedRoleId] : [];
  await updateRoleSelectionRequest(request.id, { selected_role_ids: selectedRoleIds });

  const sent = await sendVerificationApprovalRequest({
    guild,
    config,
    interaction,
    request,
    selectedRoleIds,
    category,
    department,
    notes
  });

  await interaction.editReply(
    sent
      ? 'Verificação registrada e solicitação enviada para aprovação.'
      : 'Verificação registrada, mas não foi possível enviar a solicitação para aprovação. Tente novamente mais tarde.'
  );
}

async function handleRoleSelect(client, interaction) {
  await safeDeferReply(interaction);

  const [_, __, requestId] = interaction.customId.split(':');
  if (!requestId) {
    return await interaction.editReply('Solicitação inválida. Reabra a verificação e tente novamente.');
  }
  const req = await getRoleSelectionRequestById(requestId);
  if (!req) return await interaction.editReply('Solicitação não encontrada ou expirada.');

  if (req.user_id !== interaction.user.id) {
    return await interaction.editReply('Apenas o autor da solicitação pode selecionar cargos aqui.');
  }

  if (req.status !== 'PENDING') {
    return await interaction.editReply('Essa solicitação já foi analisada.');
  }

  const selectedRoleIds = interaction.values;

  await updateRoleSelectionRequest(requestId, { selected_role_ids: selectedRoleIds });

  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const sent = await sendVerificationApprovalRequest({
    guild: interaction.guild,
    config,
    interaction,
    request: { id: req.id },
    selectedRoleIds,
    category: null,
    department: null,
    notes: null
  });

  if (!sent) {
    logger.warn({ guildId: interaction.guild.id, userId: interaction.user.id }, 'Nenhum canal de aprovação disponível para a atualização da solicitação de cargos');
  }

  try {
    const disabled = StringSelectMenuBuilder.from(interaction.component).setDisabled(true);
    await interaction.message.edit({ components: [new ActionRowBuilder().addComponents(disabled)] });
  } catch {}

  await interaction.editReply('Sua solicitação foi enviada para aprovação.');
}

function canReview(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return true;
  return member.roles.cache.has(config.roles.recruiterRoleId);
}

async function handleRoleApproval(client, interaction) {
  await safeDeferReply(interaction);

  if (!interaction.guild) {
    return await interaction.editReply('Essa ação só pode ser usada dentro de um servidor.');
  }

  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const reviewer = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  if (!canReview(config, reviewer)) {
    return await interaction.editReply('Você não tem permissão para aprovar/recusar solicitações.');
  }

  const isApprove = interaction.customId.startsWith('pc:roleApprove:');
  const requestId = interaction.customId.split(':')[2];
  const req = await getRoleSelectionRequestById(requestId);
  if (!req) return await interaction.editReply('Solicitação não encontrada.');

  if (req.status !== 'PENDING') return await interaction.editReply('Essa solicitação já foi analisada.');

  if (!interaction.message) {
    return await interaction.editReply('Não foi possível localizar a mensagem de aprovação. Reabra a solicitação e tente novamente.');
  }

  const target = await interaction.guild.members.fetch(req.user_id).catch(() => null);
  if (!target) return await interaction.editReply('O membro não está mais no servidor.');

  if (!isApprove) {
    await updateRoleSelectionRequest(requestId, {
      status: 'DENIED',
      reviewed_by: interaction.user.id,
      reviewed_at: new Date().toISOString()
    });

    try {
      const disabledRow = buildDisabledApprovalRow(interaction.message);
      await interaction.message.edit({ components: [disabledRow] });
    } catch (err) {
      logger.warn({ err, requestId, userId: interaction.user.id }, 'Falha ao desabilitar botões de aprovação');
    }

    await interaction.editReply('Solicitação recusada.');
    return;
  }

  const selectedRoleIds = req.selected_role_ids ?? [];
  const policeRoleIds = new Set(config.roles.policeRoleIds ?? []);
  const integrationIds = new Set(Object.values(config.roles.integration ?? {}).filter(Boolean));

  const isPoliceSelection = selectedRoleIds.some((roleId) => policeRoleIds.has(roleId) && !integrationIds.has(roleId));

  const roleIdsToAdd = new Set(selectedRoleIds);
  if (isPoliceSelection && config.roles.corpRoleId) roleIdsToAdd.add(config.roles.corpRoleId);

  await target.roles.add([...roleIdsToAdd]).catch(() => {});

  const verifiedRoleId = config.roles.verifiedRoleId;
  if (verifiedRoleId && !target.roles.cache.has(verifiedRoleId)) {
    await target.roles.add(verifiedRoleId).catch(() => {});
  }

  const autoRoleOnJoinId = config.roles.autoRoleOnJoinId;
  if (autoRoleOnJoinId && target.roles.cache.has(autoRoleOnJoinId)) {
    await target.roles.remove(autoRoleOnJoinId).catch(() => {});
  }

  await updateRoleSelectionRequest(requestId, {
    status: 'APPROVED',
    reviewed_by: interaction.user.id,
    reviewed_at: new Date().toISOString()
  });

  try {
    const disabledRow = buildDisabledApprovalRow(interaction.message);
    await interaction.message.edit({ components: [disabledRow] });
  } catch (err) {
    logger.warn({ err, requestId, userId: interaction.user.id }, 'Falha ao desabilitar botões de aprovação');
  }

  await interaction.editReply('Solicitação aprovada e cargos aplicados.');
}

module.exports = {
  buildDisabledApprovalRow,
  buildRoleApprovalButtons,
  buildVerificationApprovalEmbed,
  parseVerificationModalCustomId,
  resolveApprovalChannel,
  sendVerificationApprovalRequest,
  safeDeferReply,
  canReview,
  handleVerificationButton,
  handleVerificationModal,
  handleRoleSelect,
  handleRoleApproval
};
