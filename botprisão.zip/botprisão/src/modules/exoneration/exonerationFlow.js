const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ModalBuilder,
  PermissionsBitField,
  TextInputBuilder,
  TextInputStyle,
  UserSelectMenuBuilder,
  MessageFlags
} = require('discord.js');

const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { BRAND } = require('../../config/constants');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { logger } = require('../../lib/logger');

function canExonerate(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return true;
  return Boolean(config?.roles?.recruiterRoleId && member.roles.cache.has(config.roles.recruiterRoleId));
}

function buildExonerationPanelEmbed() {
  const embed = baseEmbed({
    title: '📑 CENTRAL DE EXONERAÇÃO',
    description:
      '📌 Solicitação de exoneração\n' +
      '📌 Exoneração administrativa\n' +
      '📌 Desligamento institucional\n\n' +
      '⚠️ Utilize corretamente o sistema.\n\n' +
      'Selecione uma opção abaixo.'
  }).setColor(BRAND.colors.GRAY_DARK);

  embed.addFields({
    name: '🔒 Permissão',
    value: 'A exoneração administrativa é restrita a cargos autorizados.',
    inline: false
  });

  return embed;
}

function buildRequestModal() {
  const modal = new ModalBuilder().setCustomId('pc:exo:requestModal').setTitle('Solicitar Exoneração');

  const name = new TextInputBuilder()
    .setCustomId('name')
    .setLabel('Nome RP')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(40);

  const passport = new TextInputBuilder()
    .setCustomId('passport')
    .setLabel('Passaporte')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(20);

  const reason = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Motivo da exoneração')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1200);

  const notes = new TextInputBuilder()
    .setCustomId('notes')
    .setLabel('Observações adicionais (opcional)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(900);

  modal.addComponents(
    new ActionRowBuilder().addComponents(name),
    new ActionRowBuilder().addComponents(passport),
    new ActionRowBuilder().addComponents(reason),
    new ActionRowBuilder().addComponents(notes)
  );

  return modal;
}

function buildAdminReasonModal(userId) {
  const modal = new ModalBuilder().setCustomId(`pc:exo:adminModal:${userId}`).setTitle('Exonerar Membro');

  const reason = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('Motivo da exoneração')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1200);

  const notes = new TextInputBuilder()
    .setCustomId('notes')
    .setLabel('Observações adicionais (opcional)')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(900);

  modal.addComponents(new ActionRowBuilder().addComponents(reason), new ActionRowBuilder().addComponents(notes));
  return modal;
}

function buildRequestEmbed({ nameRp, passport, reason, notes, requesterId }) {
  const ts = Math.floor(Date.now() / 1000);
  const embed = baseEmbed({
    title: '📋 SOLICITAÇÃO DE EXONERAÇÃO',
    description: 'Registro institucional • Aguardando ação'
  }).setColor(BRAND.colors.GRAY_DARK);

  embed.addFields(
    { name: '📌 Nome do membro', value: `**${nameRp || '—'}**`, inline: true },
    { name: '📌 ID do Discord', value: `**${requesterId}**`, inline: true },
    { name: '📌 Passaporte', value: `**${passport || '—'}**`, inline: true },
    { name: '📌 Motivo da exoneração', value: reason || '—', inline: false },
    { name: '📌 Observações', value: notes || '—', inline: false },
    { name: '📌 Data/Hora', value: `<t:${ts}:F>`, inline: true },
    { name: '📌 Solicitado por', value: `<@${requesterId}>`, inline: true }
  );

  return embed;
}

function buildDmEmbed({ reason, date }) {
  const embed = baseEmbed({
    title: '📑 EXONERAÇÃO INSTITUCIONAL',
    description:
      'Você foi exonerado da corporação.\n\n' +
      `📌 Motivo:\n${reason || '—'}\n\n` +
      `📅 Data:\n${date}\n\n` +
      '⚠️ Caso acredite que isso foi um erro, procure a administração.'
  }).setColor(BRAND.colors.GRAY_DARK);
  return embed;
}

function buildFinalizeEmbed({ originalEmbed, executorId, kicked, reasonText }) {
  const embed = baseEmbed(originalEmbed.data ?? {}).setColor(kicked ? BRAND.colors.BLUE : BRAND.colors.GRAY_DARK);
  const ts = Math.floor(Date.now() / 1000);

  embed.addFields({
    name: kicked ? '✅ Status' : '⚠️ Status',
    value:
      (kicked ? 'EXONERADO' : 'PENDENTE (falha ao expulsar)') +
      `\nResponsável: <@${executorId}>\nData/Hora: <t:${ts}:F>` +
      (reasonText ? `\nMotivo: ${reasonText.slice(0, 300)}` : ''),
    inline: false
  });

  return embed;
}

function readField(embed, startsWith) {
  const fields = Array.isArray(embed?.fields) ? embed.fields : [];
  const found = fields.find((f) => String(f?.name || '').toLowerCase().includes(startsWith.toLowerCase()));
  return found?.value ? String(found.value) : null;
}

function parseUserIdFromField(value) {
  const v = String(value || '');
  const match = v.match(/\b\d{15,25}\b/);
  return match ? match[0] : null;
}

async function handleExonerationPanelButton(client, interaction) {
  const id = interaction.customId;
  if (id === 'pc:exo:request') return await interaction.showModal(buildRequestModal());

  if (id === 'pc:exo:admin') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!canExonerate(config, member)) return await interaction.editReply('Você não tem permissão para exonerar membros.');

    const select = new UserSelectMenuBuilder()
      .setCustomId('pc:exo:selectUser')
      .setPlaceholder('Selecione o usuário para exonerar')
      .setMinValues(1)
      .setMaxValues(1);

    const row = new ActionRowBuilder().addComponents(select);
    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('pc:exo:cancel').setLabel('Cancelar').setStyle(ButtonStyle.Secondary)
    );

    return await interaction.editReply({
      embeds: [
        baseEmbed({
          title: '🚫 Exoneração Administrativa',
          description: 'Selecione o usuário. Em seguida, informe motivo e observações para concluir.'
        }).setColor(BRAND.colors.GRAY_DARK)
      ],
      components: [row, row2]
    });
  }
}

async function handleExonerationAdminSelect(client, interaction) {
  if (interaction.customId !== 'pc:exo:selectUser') return;
  const userId = interaction.values?.[0] || null;
  if (!userId) return await interaction.reply({ content: 'Selecione um usuário válido.', flags: MessageFlags.Ephemeral }).catch(() => {});
  return await interaction.showModal(buildAdminReasonModal(userId));
}

async function handleExonerationModal(client, interaction) {
  const id = interaction.customId;
  if (id === 'pc:exo:requestModal') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const logChannel = interaction.guild.channels.cache.get(config.channels.exonerationLogChannelId);
    if (!logChannel || logChannel.type !== ChannelType.GuildText) {
      return await interaction.editReply('Canal de logs/solicitações de exoneração não configurado ou inválido.');
    }

    const nameRp = interaction.fields.getTextInputValue('name').trim();
    const passport = interaction.fields.getTextInputValue('passport').trim();
    const reason = interaction.fields.getTextInputValue('reason').trim();
    const notes = interaction.fields.getTextInputValue('notes')?.trim() || null;

    const embed = buildRequestEmbed({ nameRp, passport, reason, notes, requesterId: interaction.user.id });
    const nonce = Math.random().toString(36).slice(2, 8);
    const button = new ButtonBuilder()
      .setCustomId(`pc:exo:execute:${interaction.user.id}:${Date.now().toString(36)}:${nonce}`)
      .setLabel('🚫 EXONERAR')
      .setStyle(ButtonStyle.Danger);
    const row = new ActionRowBuilder().addComponents(button);

    const sent = await logChannel.send({ embeds: [embed], components: [row], allowedMentions: { parse: [] } }).catch(() => null);
    if (!sent) return await interaction.editReply('Falha ao enviar sua solicitação.');
    return await interaction.editReply('Solicitação enviada com sucesso. Aguarde a análise administrativa.');
  }

  if (id.startsWith('pc:exo:adminModal:')) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const admin = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!canExonerate(config, admin)) return await interaction.editReply('Você não tem permissão para exonerar membros.');

    const userId = id.split(':')[3] || null;
    if (!userId) return await interaction.editReply('Usuário inválido.');

    const reason = interaction.fields.getTextInputValue('reason').trim();
    const notes = interaction.fields.getTextInputValue('notes')?.trim() || null;

    const logChannel = interaction.guild.channels.cache.get(config.channels.exonerationLogChannelId);
    if (!logChannel || logChannel.type !== ChannelType.GuildText) {
      return await interaction.editReply('Canal de logs/solicitações de exoneração não configurado ou inválido.');
    }

    const embed = buildRequestEmbed({
      nameRp: '—',
      passport: '—',
      reason,
      notes,
      requesterId: userId
    });
    embed.setTitle('📋 EXONERAÇÃO ADMINISTRATIVA');
    embed.addFields({ name: '🛡️ Ação administrativa', value: `Responsável: <@${interaction.user.id}>`, inline: false });

    const nonce = Math.random().toString(36).slice(2, 8);
    const button = new ButtonBuilder()
      .setCustomId(`pc:exo:execute:${userId}:${Date.now().toString(36)}:${nonce}`)
      .setLabel('🚫 EXONERAR')
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents(button);
    const sent = await logChannel.send({ embeds: [embed], components: [row], allowedMentions: { parse: [] } }).catch(() => null);
    if (!sent) return await interaction.editReply('Falha ao registrar a exoneração.');
    return await interaction.editReply(`Solicitação registrada: ${sent.url}`);
  }
}

async function handleExonerationExecute(client, interaction) {
  if (!interaction.customId.startsWith('pc:exo:execute:')) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const executor = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  if (!canExonerate(config, executor)) {
    return await interaction.editReply('Você não tem permissão para exonerar membros.');
  }

  const embed = interaction.message.embeds?.[0] || null;
  if (!embed) return await interaction.editReply('Mensagem inválida.');

  const discordIdField = readField(embed, 'id do discord');
  const targetUserId = parseUserIdFromField(discordIdField) || interaction.customId.split(':')[3] || null;
  if (!targetUserId) return await interaction.editReply('Não foi possível identificar o membro.');

  const reason = readField(embed, 'motivo da exoneração') || '—';
  const date = new Date().toLocaleString('pt-BR');

  const target = await interaction.guild.members.fetch(targetUserId).catch(() => null);
  if (!target) return await interaction.editReply('O membro não está mais no servidor.');

  await target.send({ embeds: [buildDmEmbed({ reason, date })] }).catch(() => {});

  let kicked = false;
  try {
    await target.kick(`Exoneração institucional • Responsável: ${interaction.user.tag}`);
    kicked = true;
  } catch {}

  try {
    const updatedEmbed = buildFinalizeEmbed({
      originalEmbed: embed,
      executorId: interaction.user.id,
      kicked,
      reasonText: reason
    });
    const disabledRow = new ActionRowBuilder().addComponents(
      ButtonBuilder.from(interaction.message.components?.[0]?.components?.[0] || new ButtonBuilder())
        .setLabel('🚫 EXONERAR')
        .setStyle(ButtonStyle.Danger)
        .setDisabled(true)
    );
    await interaction.message.edit({ embeds: [updatedEmbed], components: [disabledRow], allowedMentions: { parse: [] } }).catch(() => {});
  } catch {}

  logger.info(
    { guildId: interaction.guild.id, executorId: interaction.user.id, targetUserId, kicked, messageId: interaction.message.id },
    'Exoneração executada'
  );

  return await interaction.editReply(kicked ? 'Membro exonerado e expulso com sucesso.' : 'DM enviada, mas não foi possível expulsar o membro (verifique permissões/hierarquia).');
}

async function handleExonerationCancel(client, interaction) {
  if (interaction.customId !== 'pc:exo:cancel') return;
  return await interaction.update({ components: [], embeds: [], content: 'Ação cancelada.' }).catch(() => {});
}

module.exports = {
  buildExonerationPanelEmbed,
  handleExonerationPanelButton,
  handleExonerationModal,
  handleExonerationExecute,
  handleExonerationAdminSelect,
  handleExonerationCancel
};
