const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ModalBuilder,
  PermissionsBitField,
  StringSelectMenuBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags
} = require('discord.js');
const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { BRAND } = require('../../config/constants');
const { createCourseRequest, markCourseRequestInstructed } = require('../../database/repositories/courseRepository');
const { logger } = require('../../lib/logger');

const BASIC_COURSE_ROLE_IDS = ['1504559788330193046', '1504560021235826839'];
const BASIC_COURSE_STUDENT_ROLE_IDS = ['1531058005431418931'];

const COURSES = [
  { label: 'Tático', roleId: '1504559785553559744', emoji: '🛡️', description: 'Treinamento operacional especializado' },
  { label: 'Curso Básico', roleId: 'BASIC_COURSE', emoji: '📚', description: 'Modulação + Abordagem' },
  { label: 'Graer', roleId: '1504559791396360405', emoji: '🦅', description: 'Tática aérea e apoio tático' },
  { label: 'Speed', roleId: '1504559794327916748', emoji: '🏎️', description: 'Direção avançada e perseguição' },
  { label: 'GTM', roleId: '1504559799612997682', emoji: '🧩', description: 'Grupo tático / missões especiais' },
  { label: 'Prisão', roleId: '1504560023655940207', emoji: '⛓️', description: 'Procedimentos de custódia e prisão' },
  { label: 'Investigação', roleId: '1504560026134511767', emoji: '🕵️', description: 'Metodologia investigativa e relatórios' }
];

const COURSE_BY_ROLE_ID = new Map(COURSES.map((c) => [c.roleId, c]));

const STUDENT_ROLES = new Map([
  ['1504559785553559744', '1531057905158328371'],
  ['1504559788330193046', '1531058005431418931'],
  ['1504560021235826839', '1531058005431418931'],
  ['1504559791396360405', '1531058225217147061'],
  ['1504560026134511767', '1531058259635474602'],
  ['1504559794327916748', '1531059472774987827'],
  ['1504560023655940207', '1531058373695635506'],
  ['1504559799612997682', '1531059741311373463'],
  ['BASIC_COURSE', '1531058005431418931']
]);

const ALL_STUDENT_ROLE_IDS = [
  '1531057905158328371',
  '1531058005431418931',
  '1531058225217147061',
  '1531058259635474602',
  '1531059472774987827',
  '1531058373695635506',
  '1531059741311373463',
];

function courseLabel(roleId) {
  if (roleId === 'BASIC_COURSE') return 'Curso Básico';
  return COURSE_BY_ROLE_ID.get(String(roleId))?.label ?? 'Curso';
}

function getCourseRoleIds(roleId) {
  if (roleId === 'BASIC_COURSE') return BASIC_COURSE_ROLE_IDS;
  return [roleId];
}

function getStudentRoleIds(roleId) {
  if (roleId === 'BASIC_COURSE') return BASIC_COURSE_STUDENT_ROLE_IDS;
  const sid = STUDENT_ROLES.get(roleId);
  return sid ? [sid] : [];
}

function canInstruct(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return true;
  return Boolean(config?.roles?.recruiterRoleId && member.roles.cache.has(config.roles.recruiterRoleId));
}

function buildCoursesPanelEmbed() {
  const embed = baseEmbed({
    title: '🎓 CENTRAL DE CURSOS',
    description:
      '📌 Solicite cursos especializados\n' +
      '📌 Aguarde aprovação/instrução\n' +
      '📌 Cursos oficiais da corporação\n\n' +
      '⚠️ Informe corretamente sua disponibilidade.\n\n' +
      'Clique no botão abaixo para iniciar.'
  }).setColor(BRAND.colors.GRAY_DARK);

  embed.addFields({
    name: '📂 Cursos Disponíveis',
    value: COURSES.map((c) => {
      if (c.roleId === 'BASIC_COURSE') {
        return `${c.emoji} **${c.label}** — <@&${BASIC_COURSE_ROLE_IDS[0]}>, <@&${BASIC_COURSE_ROLE_IDS[1]}>`;
      }
      return `${c.emoji} **${c.label}** — <@&${c.roleId}>`;
    }).join('\n'),
    inline: false
  });

  return embed;
}

function buildCoursesSelectEmbed() {
  const embed = baseEmbed({
    title: '🎓 Solicitação de Cursos',
    description:
      'Selecione o curso desejado no menu abaixo.\n\n' +
      '📌 Sua solicitação será enviada para análise.\n' +
      '📌 Após instrução, o curso será aplicado automaticamente.'
  }).setColor(BRAND.colors.GRAY_DARK);

  embed.addFields({
    name: '📂 Catálogo',
    value: COURSES.map((c) => `${c.emoji} **${c.label}** — ${c.description}`).join('\n'),
    inline: false
  });

  return embed;
}

function buildCourseSelectRow() {
  const select = new StringSelectMenuBuilder()
    .setCustomId('pc:courses:select')
    .setPlaceholder('Selecione um curso')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(
      COURSES.map((c) => ({
        label: c.label,
        value: c.roleId,
        description: c.description.slice(0, 50),
        emoji: c.emoji
      }))
    );

  return new ActionRowBuilder().addComponents(select);
}

function buildCourseRequestModal(roleId) {
  const modal = new ModalBuilder()
    .setCustomId(`pc:courses:modal:${roleId}`)
    .setTitle(`Solicitação — ${courseLabel(roleId)}`);

  const nameInput = new TextInputBuilder()
    .setCustomId('name')
    .setLabel('Nome RP')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(32);

  const passportInput = new TextInputBuilder()
    .setCustomId('passport')
    .setLabel('Passaporte')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(10);

  const courseInput = new TextInputBuilder()
    .setCustomId('course')
    .setLabel('Curso selecionado')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(40)
    .setValue(courseLabel(roleId));

  const availabilityInput = new TextInputBuilder()
    .setCustomId('availability')
    .setLabel('Disponibilidade de horário')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(60)
    .setPlaceholder('Ex: 19:00–22:00');

  const daysAndNotesInput = new TextInputBuilder()
    .setCustomId('days_notes')
    .setLabel('Dias disponíveis / Observações')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(900)
    .setPlaceholder('Linha 1: Dias (ex: Seg, Qua, Sex)\nLinha 2+: Observações (opcional)');

  modal.addComponents(
    new ActionRowBuilder().addComponents(nameInput),
    new ActionRowBuilder().addComponents(passportInput),
    new ActionRowBuilder().addComponents(courseInput),
    new ActionRowBuilder().addComponents(availabilityInput),
    new ActionRowBuilder().addComponents(daysAndNotesInput)
  );

  return modal;
}

function splitDaysAndNotes(text) {
  const raw = String(text || '').trim();
  if (!raw) return { days: null, notes: null };
  const lines = raw.split('\n').map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return { days: null, notes: null };
  const [first, ...rest] = lines;
  return { days: first || null, notes: rest.join('\n') || null };
}

function buildCourseRequestEmbed({ requesterId, inGameName, passport, roleId, availability, days, notes }) {
  const courseLabels = getCourseRoleIds(roleId).map((rid) => courseLabel(rid));
  const courseMentions = getCourseRoleIds(roleId).map((rid) => `<@&${rid}>`).join('\n');
  const embed = baseEmbed({
    title: '📚 NOVA SOLICITAÇÃO DE CURSO',
    description: 'Central de Treinamentos • Solicitação registrada'
  }).setColor(BRAND.colors.GRAY_DARK);

  const ts = Math.floor(Date.now() / 1000);

  embed.addFields(
    { name: '👤 Nome', value: `**${inGameName || '—'}**`, inline: true },
    { name: '📌 Passaporte', value: `**${passport || '—'}**`, inline: true },
    { name: '🎓 Curso solicitado', value: `**${courseLabels.join(' + ')}**\n${courseMentions}`, inline: false },
    { name: '🕒 Disponibilidade', value: availability || '—', inline: true },
    { name: '📅 Dias disponíveis', value: days || '—', inline: true },
    { name: '📝 Observações', value: notes || '—', inline: false },
    { name: '📌 Data da solicitação', value: `<t:${ts}:F>`, inline: false },
    { name: '📌 Responsável pela solicitação', value: `<@${requesterId}>`, inline: false }
  );

  return embed;
}

async function handleCoursesButton(client, interaction) {
  if (interaction.customId !== 'pc:courses:open') return;
  return await interaction.reply({
    flags: MessageFlags.Ephemeral,
    embeds: [buildCoursesSelectEmbed()],
    components: [buildCourseSelectRow()]
  });
}

async function handleCoursesSelect(client, interaction) {
  if (interaction.customId !== 'pc:courses:select') return;
  const roleId = interaction.values?.[0] || null;
  if (!roleId) return await interaction.reply({ content: 'Selecione um curso válido.', flags: MessageFlags.Ephemeral }).catch(() => {});
  return await interaction.showModal(buildCourseRequestModal(roleId));
}

async function handleCoursesModal(client, interaction) {
  if (!interaction.customId.startsWith('pc:courses:modal:')) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const guild = interaction.guild;
  if (!guild) return await interaction.editReply('Essa ação só pode ser usada dentro de um servidor.');

  const roleId = interaction.customId.split(':')[3] || null;
  if (!roleId) return await interaction.editReply('Curso inválido.');

  const config = await getOrCreateGuildConfig(guild.id);
  const requestChannel = guild.channels.cache.get(config.channels.coursesRequestChannelId);
  if (!requestChannel || requestChannel.type !== ChannelType.GuildText) {
    return await interaction.editReply('Canal de solicitações de cursos não configurado ou inválido.');
  }

  const inGameName = interaction.fields.getTextInputValue('name').trim();
  const passport = interaction.fields.getTextInputValue('passport').trim();
  const availability = interaction.fields.getTextInputValue('availability').trim();
  const { days, notes } = splitDaysAndNotes(interaction.fields.getTextInputValue('days_notes'));

  const courseTyped = interaction.fields.getTextInputValue('course')?.trim() || '';
  const expectedCourse = courseLabel(roleId);
  const courseMismatch = courseTyped && expectedCourse && courseTyped.toLowerCase() !== expectedCourse.toLowerCase();

  const embed = buildCourseRequestEmbed({
    requesterId: interaction.user.id,
    inGameName,
    passport,
    roleId,
    availability,
    days,
    notes
  });

  if (courseMismatch) {
    embed.addFields({
      name: '⚠️ Atenção',
      value: `O curso selecionado foi ajustado para **${expectedCourse}** (conforme o menu).`,
      inline: false
    });
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`pc:courses:instruct:${roleId}:${interaction.user.id}`)
      .setLabel('✅ CURSO INSTRUÍDO')
      .setStyle(ButtonStyle.Success)
  );

  const sent = await requestChannel
    .send({ embeds: [embed], components: [row], allowedMentions: { parse: [] } })
    .catch(() => null);
  if (!sent) return await interaction.editReply('Falha ao enviar sua solicitação. Tente novamente.');

  await createCourseRequest({
    guildId: guild.id,
    requesterId: interaction.user.id,
    roleId,
    inGameName,
    passport,
    availability,
    days,
    notes,
    channelId: requestChannel.id,
    messageId: sent.id
  }).catch(() => {});

  const studentRoleId = STUDENT_ROLES.get(roleId);
  if (studentRoleId) {
    const target = await guild.members.fetch(interaction.user.id).catch(() => null);
    if (target) {
      const studentRole = guild.roles.cache.get(studentRoleId) ?? (await guild.roles.fetch(studentRoleId).catch(() => null));
      if (studentRole) {
        const botMember = guild.members.me;
        const canManageRoles = botMember && botMember.permissions.has(PermissionsBitField.Flags.ManageRoles);
        const botRolePosition = botMember ? botMember.roles.highest.position : 0;
        if (canManageRoles && botRolePosition > studentRole.position) {
          if (!target.roles.cache.has(studentRoleId)) {
            await target.roles.add(studentRoleId).catch((err) => {
              logger.error({ err, targetUserId: target.id, studentRoleId }, 'Falha ao aplicar cargo de aluno');
            });
          }
        }
      }
    }
  }

  return await interaction.editReply('Solicitação enviada com sucesso. Aguarde aprovação/instrução.');
}

async function handleCourseInstructButton(client, interaction) {
  if (!interaction.customId.startsWith('pc:courses:instruct:')) return;
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const guild = interaction.guild;
  if (!guild) return await interaction.editReply('Essa ação só pode ser usada dentro de um servidor.');

  const config = await getOrCreateGuildConfig(guild.id);
  const reviewer = await guild.members.fetch(interaction.user.id).catch(() => null);
  if (!canInstruct(config, reviewer)) {
    return await interaction.editReply('Você não tem permissão para marcar curso como instruído.');
  }

  const parts = interaction.customId.split(':');
  const roleId = parts[3] || null;
  const targetUserId = parts[4] || null;

  if (!roleId || !targetUserId) return await interaction.editReply('Solicitação inválida.');

  const target = await guild.members.fetch(targetUserId).catch(() => null);
  if (!target) return await interaction.editReply('O solicitante não está mais no servidor.');

  const courseRoleIds = getCourseRoleIds(roleId);
  const studentRoleIds = getStudentRoleIds(roleId);

  if (roleId !== 'BASIC_COURSE') {
    const role = guild.roles.cache.get(roleId) ?? (await guild.roles.fetch(roleId).catch(() => null));
    if (!role) return await interaction.editReply('Cargo do curso não encontrado no servidor.');
  }

  const botMember = guild.members.me;
  const canManageRoles = botMember && botMember.permissions.has(PermissionsBitField.Flags.ManageRoles);
  const botRolePosition = botMember ? botMember.roles.highest.position : 0;

  for (const sid of ALL_STUDENT_ROLE_IDS) {
    if (target.roles.cache.has(sid)) {
      const sRole = guild.roles.cache.get(sid) ?? (await guild.roles.fetch(sid).catch(() => null));
      if (sRole) {
        if (canManageRoles && botRolePosition > sRole.position) {
          await target.roles.remove(sid).catch((err) => {
            logger.error({ err, targetUserId, studentRoleId: sid }, 'Falha ao remover cargo de aluno');
          });
        } else {
          logger.warn({ targetUserId, studentRoleId: sid }, 'Bot não pode remover cargo de aluno');
        }
      }
    }
  }

  const alreadyHasAll = courseRoleIds.every((cid) => target.roles.cache.has(cid));
  if (!alreadyHasAll) {
    for (const cid of courseRoleIds) {
      await target.roles.add(cid).catch(() => null);
    }
  }

  try {
    const updated = interaction.message.embeds?.[0]
      ? EmbedBuilder.from(interaction.message.embeds[0])
          .setColor(BRAND.colors.BLUE)
          .addFields({
            name: '✅ Status',
            value: `INSTRUÍDO\nInstrutor: <@${interaction.user.id}>\nData: <t:${Math.floor(Date.now() / 1000)}:F>`,
            inline: false
          })
      : null;

    const disabledRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel('✅ CURSO INSTRUÍDO').setStyle(ButtonStyle.Success).setCustomId('pc:courses:done').setDisabled(true)
    );

    await interaction.message.edit({ embeds: updated ? [updated] : undefined, components: [disabledRow] }).catch(() => {});
  } catch {}

  await markCourseRequestInstructed(interaction.message.id, { instructedBy: interaction.user.id }).catch(() => {});

  if (alreadyHasAll) {
    return await interaction.editReply('O solicitante já possui o cargo deste curso. Marcado como instruído.');
  }

  return await interaction.editReply('Cargo do curso aplicado e solicitação marcada como instruída.');
}

module.exports = {
  buildCoursesPanelEmbed,
  handleCoursesButton,
  handleCoursesSelect,
  handleCoursesModal,
  handleCourseInstructButton
};
