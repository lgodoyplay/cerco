const { buildCoursesPanelEmbed, handleCoursesButton, handleCoursesSelect, handleCoursesModal, handleCourseInstructButton } = require('./coursesFlow');
module.exports = { buildCoursesPanelEmbed, handleCoursesButton, handleCoursesSelect, handleCoursesModal, handleCourseInstructButton };
