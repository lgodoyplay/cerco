const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ModalBuilder,
  PermissionsBitField,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags
} = require('discord.js');
const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { createTicket, getOpenTicketByChannel, closeTicketByChannel } = require('../../database/repositories/ticketRepository');

function getDraftStore(client) {
  if (!client.corregedoriaDrafts) client.corregedoriaDrafts = new Map();
  return client.corregedoriaDrafts;
}

function getUserDraftKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

function nowTs() {
  return Math.floor(Date.now() / 1000);
}

function buildPanelEmbed(draft) {
  const embed = baseEmbed({
    title: '🛡️ Denúncia — Corregedoria',
    description: 'Painel investigativo • Envio organizado de provas'
  });

  embed.addFields(
    {
      name: '🧾 Dados da denúncia',
      value:
        `Denunciante: <@${draft.authorId}>\n` +
        `Denunciado: **${draft.accusedName}**\n` +
        `Passaporte: **${draft.accusedPassport}**\n` +
        `Motivo: **${draft.motive}**\n` +
        `Data do ocorrido: **${draft.occurredDate}**`,
      inline: false
    },
    {
      name: '📝 Relato completo',
      value: draft.report.length > 950 ? `${draft.report.slice(0, 950)}…` : draft.report,
      inline: false
    },
    {
      name: '📷 Imagens',
      value: draft.evidence.images.length ? `Arquivos: **${draft.evidence.images.length}**` : 'Aguardando upload',
      inline: true
    },
    {
      name: '🎥 Vídeos',
      value: draft.evidence.videos.length ? `Arquivos: **${draft.evidence.videos.length}**` : 'Aguardando upload',
      inline: true
    },
    {
      name: '🎙️ Gravações',
      value: draft.evidence.audio.length ? `Arquivos: **${draft.evidence.audio.length}**` : 'Aguardando upload',
      inline: true
    },
    {
      name: '🔗 Links',
      value: draft.evidence.links.length ? `Links: **${draft.evidence.links.length}**` : 'Aguardando links',
      inline: true
    }
  );

  embed.addFields({
    name: '✅ Finalização',
    value:
      'Envie suas provas por categoria.\n' +
      'Você pode arrastar arquivos diretamente para este canal após clicar na categoria.\n' +
      'Quando terminar, clique em **FINALIZAR DENÚNCIA** para abrir o ticket oficial.',
    inline: false
  });

  return embed;
}

function buildPanelComponents(draftChannelId) {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`pc:corregedoria:evidence:images:${draftChannelId}`).setLabel('📷 Imagens').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`pc:corregedoria:evidence:videos:${draftChannelId}`).setLabel('🎥 Vídeos').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`pc:corregedoria:evidence:audio:${draftChannelId}`).setLabel('🎙️ Gravações').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`pc:corregedoria:links:${draftChannelId}`).setLabel('🔗 Links').setStyle(ButtonStyle.Primary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`pc:corregedoria:finalize:${draftChannelId}`).setLabel('FINALIZAR DENÚNCIA').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`pc:corregedoria:cancel:${draftChannelId}`).setLabel('Cancelar').setStyle(ButtonStyle.Danger)
  );

  return [row1, row2];
}

function isImage(att) {
  const ct = String(att?.contentType || '').toLowerCase();
  return ct.startsWith('image/');
}

function isVideo(att) {
  const ct = String(att?.contentType || '').toLowerCase();
  return ct.startsWith('video/');
}

function isAudio(att) {
  const ct = String(att?.contentType || '').toLowerCase();
  return ct.startsWith('audio/');
}

function normalizeDiscordCdnUrl(url) {
  const u = String(url || '');
  const idx = u.indexOf('?');
  return idx === -1 ? u : u.slice(0, idx);
}

async function updatePanelMessage(channel, draft) {
  const msgs = await channel.messages.fetch({ limit: 20 }).catch(() => null);
  if (!msgs) return;
  const panel = [...msgs.values()].find((m) => m.author?.bot && m.embeds?.[0]?.title === '🛡️ Denúncia — Corregedoria') ?? null;
  if (!panel) return;
  await panel.edit({ embeds: [buildPanelEmbed(draft)], components: buildPanelComponents(channel.id) }).catch(() => {});
}

async function collectAttachments(channel, userId, predicate) {
  const instruction = await channel
    .send(
      `Envie agora o(s) arquivo(s) como anexo nesta conversa.\n` +
        `• Tempo: 2 minutos\n` +
        `• Você pode arrastar e soltar os arquivos aqui`
    )
    .catch(() => null);

  const collected = await new Promise((resolve) => {
    const collector = channel.createMessageCollector({
      time: 2 * 60 * 1000,
      filter: (m) => m.author?.id === userId && m.attachments?.size > 0
    });

    const out = [];

    collector.on('collect', (m) => {
      const atts = [...m.attachments.values()];
      const filtered = predicate ? atts.filter(predicate) : atts;
      if (filtered.length === 0) return;
      out.push(...filtered);
      collector.stop('ok');
    });

    collector.on('end', () => resolve(out));
  });

  if (instruction) setTimeout(() => instruction.delete().catch(() => {}), 15000);
  return collected;
}

async function handleTicketButton(client, interaction) {
  const parts = interaction.customId.split(':');
  const action = parts[2];

  if (action === 'open') {
    const modal = new ModalBuilder().setCustomId('pc:corregedoriaModal').setTitle('Abrir Denúncia (Sigiloso)');

    const accusedName = new TextInputBuilder()
      .setCustomId('accusedName')
      .setLabel('Nome do denunciado')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(60);

    const accusedPassport = new TextInputBuilder()
      .setCustomId('accusedPassport')
      .setLabel('Passaporte do denunciado')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(20);

    const motive = new TextInputBuilder()
      .setCustomId('motive')
      .setLabel('Motivo da denúncia')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(80);

    const report = new TextInputBuilder()
      .setCustomId('report')
      .setLabel('Relato completo')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1500);

    const occurredDate = new TextInputBuilder()
      .setCustomId('occurredDate')
      .setLabel('Data do ocorrido (DD/MM/AAAA)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(10);

    modal.addComponents(
      new ActionRowBuilder().addComponents(accusedName),
      new ActionRowBuilder().addComponents(accusedPassport),
      new ActionRowBuilder().addComponents(motive),
      new ActionRowBuilder().addComponents(report),
      new ActionRowBuilder().addComponents(occurredDate)
    );

    return await interaction.showModal(modal);
  }

  if (interaction.isModalSubmit() && interaction.customId === 'pc:corregedoriaModal') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const store = getDraftStore(client);
    const key = getUserDraftKey(interaction.guild.id, interaction.user.id);
    const existing = store.get(key);
    if (existing?.channelId) {
      const ch = interaction.guild.channels.cache.get(existing.channelId);
      if (ch) return await interaction.editReply(`Você já possui uma denúncia em andamento: <#${ch.id}>`);
    }

    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const parentId = config.channels.ticketCategoryId;

    const draftChannel = await interaction.guild.channels.create({
      name: `denuncia-${interaction.user.username}`.slice(0, 90),
      type: ChannelType.GuildText,
      parent: parentId ?? undefined,
      permissionOverwrites: [
        { id: interaction.guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] }
      ]
    });

    const draft = {
      guildId: interaction.guild.id,
      authorId: interaction.user.id,
      channelId: draftChannel.id,
      createdAt: new Date().toISOString(),
      accusedName: interaction.fields.getTextInputValue('accusedName').trim(),
      accusedPassport: interaction.fields.getTextInputValue('accusedPassport').trim(),
      motive: interaction.fields.getTextInputValue('motive').trim(),
      report: interaction.fields.getTextInputValue('report').trim(),
      occurredDate: interaction.fields.getTextInputValue('occurredDate').trim(),
      evidence: { images: [], videos: [], audio: [], links: [] },
      status: 'DRAFT'
    };

    store.set(key, draft);

    const header = baseEmbed({
      title: '🛡️ Corregedoria — Canal Sigiloso',
      description:
        'Este canal é privado e destinado ao envio de provas.\n\n' +
        'Recomendações:\n' +
        '• Evite mensagens curtas (seja detalhado)\n' +
        '• Envie anexos em alta qualidade\n' +
        '• Organize por categoria para agilizar a investigação'
    }).addFields({
      name: '📌 Status',
      value: `Denúncia em pré-cadastro • <t:${nowTs()}:F>`,
      inline: false
    });

    await draftChannel.send({ embeds: [header] });
    await draftChannel.send({ embeds: [buildPanelEmbed(draft)], components: buildPanelComponents(draftChannel.id) });

    await interaction.editReply(`Denúncia iniciada. Envie as provas em: <#${draftChannel.id}>`);
    return;
  }

  if (interaction.isModalSubmit() && interaction.customId.startsWith('pc:corregedoriaLinks:')) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const channelId = interaction.customId.split(':')[2];
    const store = getDraftStore(client);
    const key = getUserDraftKey(interaction.guild.id, interaction.user.id);
    const draft = store.get(key);
    if (!draft || draft.channelId !== channelId) return await interaction.editReply('Denúncia não encontrada ou expirada.');

    const links = [
      interaction.fields.getTextInputValue('video')?.trim(),
      interaction.fields.getTextInputValue('audio')?.trim(),
      interaction.fields.getTextInputValue('image')?.trim(),
      interaction.fields.getTextInputValue('other')?.trim()
    ].filter(Boolean);

    const extraNotes = interaction.fields.getTextInputValue('notes')?.trim() || null;

    draft.evidence.links.push(...links);
    if (extraNotes) draft.evidence.links.push(`OBS: ${extraNotes}`);

    const channel = interaction.guild.channels.cache.get(draft.channelId);
    if (channel) await updatePanelMessage(channel, draft);

    await interaction.editReply('Links adicionados ao dossiê.');
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith('pc:corregedoria:links:')) {
    const channelId = interaction.customId.split(':')[3];
    const modal = new ModalBuilder().setCustomId(`pc:corregedoriaLinks:${channelId}`).setTitle('Adicionar Links/Registros');

    const video = new TextInputBuilder()
      .setCustomId('video')
      .setLabel('Link de vídeo (opcional)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setMaxLength(200);

    const audio = new TextInputBuilder()
      .setCustomId('audio')
      .setLabel('Link de gravação (opcional)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setMaxLength(200);

    const image = new TextInputBuilder()
      .setCustomId('image')
      .setLabel('Link de imagem (opcional)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setMaxLength(200);

    const other = new TextInputBuilder()
      .setCustomId('other')
      .setLabel('Outros links (opcional)')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setMaxLength(500);

    const notes = new TextInputBuilder()
      .setCustomId('notes')
      .setLabel('Observações adicionais (opcional)')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setMaxLength(500);

    modal.addComponents(
      new ActionRowBuilder().addComponents(video),
      new ActionRowBuilder().addComponents(audio),
      new ActionRowBuilder().addComponents(image),
      new ActionRowBuilder().addComponents(other),
      new ActionRowBuilder().addComponents(notes)
    );

    return await interaction.showModal(modal);
  }

  if (interaction.isButton() && interaction.customId.startsWith('pc:corregedoria:evidence:')) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const channelId = interaction.customId.split(':')[4];
    const kind = interaction.customId.split(':')[3];
    const store = getDraftStore(client);
    const key = getUserDraftKey(interaction.guild.id, interaction.user.id);
    const draft = store.get(key);
    if (!draft || draft.channelId !== channelId) return await interaction.editReply('Denúncia não encontrada ou expirada.');

    if (interaction.channelId !== draft.channelId) return await interaction.editReply('Use esse botão dentro do canal da denúncia.');

    let predicate = null;
    let bucket = null;
    let label = null;
    if (kind === 'images') {
      predicate = isImage;
      bucket = 'images';
      label = 'imagens';
    } else if (kind === 'videos') {
      predicate = isVideo;
      bucket = 'videos';
      label = 'vídeos';
    } else if (kind === 'audio') {
      predicate = isAudio;
      bucket = 'audio';
      label = 'gravações';
    } else {
      return await interaction.editReply('Categoria inválida.');
    }

    const atts = await collectAttachments(interaction.channel, interaction.user.id, predicate);
    if (!atts.length) return await interaction.editReply(`Nenhum arquivo válido foi enviado para ${label}.`);

    const mapped = atts.map((a) => ({
      url: normalizeDiscordCdnUrl(a.url),
      name: a.name,
      contentType: a.contentType ?? null,
      size: a.size ?? null
    }));

    draft.evidence[bucket].push(...mapped);
    await updatePanelMessage(interaction.channel, draft);

    await interaction.editReply(`Provas de ${label} adicionadas: ${mapped.length}.`);
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith('pc:corregedoria:cancel:')) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const channelId = interaction.customId.split(':')[3];
    const store = getDraftStore(client);
    const key = getUserDraftKey(interaction.guild.id, interaction.user.id);
    const draft = store.get(key);
    if (!draft || draft.channelId !== channelId) return await interaction.editReply('Denúncia não encontrada ou expirada.');

    store.delete(key);
    await interaction.editReply('Denúncia cancelada. O canal será removido.');
    await interaction.channel.delete('Denúncia cancelada').catch(() => {});
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith('pc:corregedoria:finalize:')) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const channelId = interaction.customId.split(':')[3];
    const store = getDraftStore(client);
    const key = getUserDraftKey(interaction.guild.id, interaction.user.id);
    const draft = store.get(key);
    if (!draft || draft.channelId !== channelId) return await interaction.editReply('Denúncia não encontrada ou expirada.');
    if (interaction.channelId !== draft.channelId) return await interaction.editReply('Use esse botão dentro do canal da denúncia.');

    const evidenceCount =
      draft.evidence.images.length + draft.evidence.videos.length + draft.evidence.audio.length + draft.evidence.links.length;
    if (evidenceCount === 0) {
      return await interaction.editReply('Envie ao menos uma prova (arquivo ou link) antes de finalizar.');
    }

    await createTicket({ guildId: interaction.guild.id, channelId: draft.channelId, openerId: interaction.user.id });

    await interaction.channel.setName(`ticket-${interaction.user.username}`.slice(0, 90)).catch(() => {});

    const summary = baseEmbed({
      title: '✅ Ticket Aberto — Corregedoria',
      description: 'Denúncia protocolada e encaminhada para investigação.'
    });

    summary.addFields(
      {
        name: '🧾 Resumo',
        value:
          `Denunciante: <@${draft.authorId}>\n` +
          `Denunciado: **${draft.accusedName}**\n` +
          `Passaporte: **${draft.accusedPassport}**\n` +
          `Motivo: **${draft.motive}**\n` +
          `Data do ocorrido: **${draft.occurredDate}**`,
        inline: false
      },
      {
        name: '📎 Provas cadastradas',
        value:
          `📷 Imagens: **${draft.evidence.images.length}**\n` +
          `🎥 Vídeos: **${draft.evidence.videos.length}**\n` +
          `🎙️ Gravações: **${draft.evidence.audio.length}**\n` +
          `🔗 Links: **${draft.evidence.links.length}**`,
        inline: false
      }
    );

    if (draft.evidence.links.length) {
      const text = draft.evidence.links.slice(0, 10).map((l) => `• ${l}`).join('\n');
      summary.addFields({ name: '🔗 Links', value: text, inline: false });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('pc:ticket:close').setLabel('Fechar Ticket').setStyle(ButtonStyle.Danger)
    );

    await interaction.channel.send({ embeds: [summary], components: [row] }).catch(() => {});
    store.delete(key);

    await interaction.editReply('Ticket criado com sucesso. A corregedoria já pode iniciar a análise.');
    return;
  }

  if (action === 'close') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const ticket = await getOpenTicketByChannel(interaction.channelId);
    if (!ticket) return await interaction.editReply('Ticket não encontrado ou já fechado.');

    const isAdmin = interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator) ?? false;
    if (!isAdmin && ticket.opener_id !== interaction.user.id) {
      return await interaction.editReply('Apenas o solicitante ou administradores podem fechar o ticket.');
    }

    const channel = interaction.channel;
    const messages = await channel.messages.fetch({ limit: 100 }).catch(() => null);
    const transcript = (messages ? [...messages.values()] : [])
      .filter((m) => !m.author?.bot)
      .sort((a, b) => a.createdTimestamp - b.createdTimestamp)
      .map((m) => ({
        authorId: m.author.id,
        content: m.content || '',
        createdAt: new Date(m.createdTimestamp)
      }));

    await closeTicketByChannel(interaction.channelId, { closedBy: interaction.user.id, transcript });

    await interaction.editReply('Ticket fechado. O canal será apagado.');
    await channel.delete('Ticket fechado').catch(() => {});
  }
}

module.exports = { handleTicketButton };
