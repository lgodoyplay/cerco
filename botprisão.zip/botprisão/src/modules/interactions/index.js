const { handleComponentInteraction } = require('./componentRouter');
module.exports = { handleComponentInteraction };
