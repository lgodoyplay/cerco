const { MessageFlags } = require('discord.js');
const { logger } = require('../../lib/logger');

const { handleVerificationButton, handleVerificationModal, handleRoleSelect, handleRoleApproval } = require('../verification/verificationFlow');
const { handleInvestigationPanelButton, handleInvestigationModal, handleEvidenceStart, handleEvidenceModal, handleEvidenceConfirm, handleInvestigationConclude, handleInvestigationConfirmPdf } = require('../investigation/investigationFlow');
const { handleBOButton, handleBOModal } = require('../bo/boFlow');
const { handleWantedCapturedButton, handleWantedCaptureModal } = require('../wanted/wantedFlow');
const { handleTicketButton } = require('../ticket/ticketFlow');
const { handleCoursesButton, handleCoursesSelect, handleCoursesModal, handleCourseInstructButton } = require('../courses/coursesFlow');
const { handleNoticesButton, handleNoticesModal } = require('../notices/noticesFlow');
const { handleExonerationPanelButton, handleExonerationModal, handleExonerationExecute, handleExonerationAdminSelect, handleExonerationCancel } = require('../exoneration/exonerationFlow');
const { handleTimeclockButton, handleTimeclockModal } = require('../timeclock/timeclockFlow');
const { handlePromotionButton, handlePromotionSelect, handlePromotionModal, handlePromotionApprove, handlePromotionDeny } = require('../promotion/promotionFlow');

const antiSpam = new Map();

function isOnCooldown(userId, ms) {
  const now = Date.now();
  const until = antiSpam.get(userId) ?? 0;
  if (until > now) return true;
  antiSpam.set(userId, now + ms);
  return false;
}

function isLegacyPrisonWanted(customId) {
  const id = String(customId || '');
  if (id.startsWith('pc:prison') || id.startsWith('pc:prison:') || id === 'pc:prisonModal') return true;
  if (id.startsWith('pc:wanted:') && !id.startsWith('pc:wanted:captured:') && !id.startsWith('pc:wanted:captureModal:')) return true;
  if (id === 'pc:wantedModal') return true;
  return false;
}

async function replyLegacyPrisonWanted(interaction) {
  const content = 'O sistema antigo de mídia de Prisões/Procurados foi removido.\nUse apenas: `/prisao` e `/procurado`.';
  if (interaction.deferred || interaction.replied) {
    return await interaction.followUp({ content, flags: MessageFlags.Ephemeral }).catch(() => {});
  }
  return await interaction.reply({ content, flags: MessageFlags.Ephemeral }).catch(() => {});
}

const ROUTE_TABLE = [
  { type: 'button', prefix: 'pc:verify', fn: handleVerificationButton },
  { type: 'button', prefix: 'pc:verifyBack', fn: handleVerificationModal },
  { type: 'button', prefix: 'pc:roleApprove:', fn: handleRoleApproval },
  { type: 'button', prefix: 'pc:roleDeny:', fn: handleRoleApproval },
  { type: 'button', prefix: 'pc:courses:open', fn: handleCoursesButton },
  { type: 'button', prefix: 'pc:courses:instruct:', fn: handleCourseInstructButton },
  { type: 'button', prefix: 'pc:notices:create', fn: handleNoticesButton },
  { type: 'button', prefix: 'pc:exo:request', fn: handleExonerationPanelButton },
  { type: 'button', prefix: 'pc:exo:admin', fn: handleExonerationPanelButton },
  { type: 'button', prefix: 'pc:exo:execute:', fn: handleExonerationExecute },
  { type: 'button', prefix: 'pc:exo:cancel', fn: handleExonerationCancel },
  { type: 'button', prefix: 'pc:investigationOpen', fn: handleInvestigationPanelButton },
  { type: 'button', prefix: 'pc:inv:', fn: handleInvestigationModal },
  { type: 'button', prefix: 'pc:investigationConclude', fn: handleInvestigationConclude },
  { type: 'button', prefix: 'pc:investigationConfirmPdf', fn: handleInvestigationConfirmPdf },
  { type: 'button', prefix: 'pc:evidenceStart', fn: handleEvidenceStart },
  { type: 'button', prefix: 'pc:evidenceConfirm:', fn: handleEvidenceConfirm },
  { type: 'button', prefix: 'pc:boFill', fn: handleBOButton },
  { type: 'button', prefix: 'pc:wanted:captured:', fn: handleWantedCapturedButton },
  { type: 'button', prefix: 'pc:ticket:', fn: handleTicketButton },
  { type: 'button', prefix: 'pc:corregedoria:', fn: handleTicketButton },
  { type: 'button', prefix: 'pc:timeclock:', fn: handleTimeclockButton },
  { type: 'select', prefix: 'pc:roleSelect:', fn: handleRoleSelect },
  { type: 'select', prefix: 'pc:verifyCategory', fn: handleVerificationModal },
  { type: 'select', prefix: 'pc:verifyRole:', fn: handleVerificationModal },
  { type: 'select', prefix: 'pc:courses:select', fn: handleCoursesSelect },
  { type: 'userSelect', prefix: 'pc:exo:selectUser', fn: handleExonerationAdminSelect },
  { type: 'modal', prefix: 'pc:verifyModal', fn: handleVerificationModal },
  { type: 'modal', prefix: 'pc:verifyModal:', fn: handleVerificationModal },
  { type: 'modal', prefix: 'pc:investigationModal', fn: handleInvestigationModal },
  { type: 'modal', prefix: 'pc:inv:', fn: handleInvestigationModal },
  { type: 'modal', prefix: 'pc:evidenceModal:', fn: handleEvidenceModal },
  { type: 'modal', prefix: 'pc:boModal', fn: handleBOModal },
  { type: 'modal', prefix: 'pc:wanted:captureModal:', fn: handleWantedCaptureModal },
  { type: 'modal', prefix: 'pc:corregedoriaModal', fn: handleTicketButton },
  { type: 'modal', prefix: 'pc:corregedoriaLinks:', fn: handleTicketButton },
  { type: 'modal', prefix: 'pc:courses:modal:', fn: handleCoursesModal },
  { type: 'modal', prefix: 'pc:notices:modal', fn: handleNoticesModal },
  { type: 'modal', prefix: 'pc:exo:requestModal', fn: handleExonerationModal },
  { type: 'modal', prefix: 'pc:exo:adminModal:', fn: handleExonerationModal },
  { type: 'modal', prefix: 'pc:timeclock:', fn: handleTimeclockModal },
  { type: 'button', prefix: 'pc:promotion:open', fn: handlePromotionButton },
  { type: 'select', prefix: 'pc:promotion:select', fn: handlePromotionSelect },
  { type: 'modal', prefix: 'pc:promotion:modal:', fn: handlePromotionModal },
  { type: 'button', prefix: 'pc:promotion:approve:', fn: handlePromotionApprove },
  { type: 'button', prefix: 'pc:promotion:deny:', fn: handlePromotionDeny }
];

function findHandler(interaction) {
  let type = null;
  if (interaction.isButton()) type = 'button';
  else if (interaction.isStringSelectMenu()) type = 'select';
  else if (interaction.isUserSelectMenu?.()) type = 'userSelect';
  else if (interaction.isModalSubmit()) type = 'modal';
  if (!type) return null;

  const customId = interaction.customId || '';
  for (const route of ROUTE_TABLE) {
    if (route.type === type && customId.startsWith(route.prefix)) {
      return route.fn;
    }
  }
  return null;
}

async function handleComponentInteraction(client, interaction) {
  if (isOnCooldown(interaction.user.id, 800)) {
    return await interaction.reply({ content: 'Aguarde um instante e tente novamente.', flags: MessageFlags.Ephemeral }).catch(() => {});
  }

  if (isLegacyPrisonWanted(interaction.customId)) {
    return await replyLegacyPrisonWanted(interaction);
  }

  const handler = findHandler(interaction);
  if (handler) {
    return await handler(client, interaction);
  }

  logger.warn({ customId: interaction.customId, type: interaction.type }, 'Interação não roteada');
}

module.exports = { handleComponentInteraction };