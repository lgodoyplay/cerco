const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField,
  MessageFlags
} = require('discord.js');

const { BRAND } = require('../../config/constants');
const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { getOrCreateGuildConfig } = require('../../services/guildConfig');
const { logger } = require('../../lib/logger');
const { uploadDiscordAttachment, guessContentGroup } = require('../../services/mediaStorage');
const {
  createInvestigation,
  getOpenInvestigationByChannel,
  getInvestigationById,
  updateInvestigation,
  createEvidence,
  getEvidenceById,
  updateEvidence,
  getEvidencesByInvestigationId,
  countEvidencesByInvestigationId
} = require('../../database/repositories/investigationRepository');

// Fluxo de investigações:
// - Painel no canal público abre modal (restrito ao Investigativo)
// - Cria canal privado na categoria configurada
// - Evidências e PDF são confirmados por botões após o usuário enviar anexos
//   (esse padrão mantém o sistema funcional mesmo após reiniciar o bot)
function sanitizeChannelName(name) {
  return name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9- ]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .slice(0, 80);
}

function normalizeDiscordCdnUrl(url) {
  const u = String(url || '');
  const idx = u.indexOf('?');
  return idx === -1 ? u : u.slice(0, idx);
}

function normalizeUrl(url) {
  return String(url || '').trim();
}

function safeButtonLabel(label) {
  const s = String(label || 'Arquivo').trim() || 'Arquivo';
  return s.length > 80 ? `${s.slice(0, 77)}...` : s;
}

function buildDownloadRows(items) {
  const rows = [];
  const list = Array.isArray(items) ? items.filter((i) => i?.url) : [];
  for (let i = 0; i < list.length; i += 5) {
    const slice = list.slice(i, i + 5);
    const row = new ActionRowBuilder().addComponents(
      ...slice.map((it) => new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel(safeButtonLabel(it.label)).setURL(normalizeUrl(it.url)))
    );
    rows.push(row);
  }
  return rows.slice(0, 5);
}

function makeImageEmbed({ title, description, url }) {
  const e = baseEmbed({ title, description, color: BRAND.colors.GRAY_DARK });
  e.setImage(normalizeUrl(url));
  return e;
}

async function uploadEvidenceAttachments({ kind, guildId, recordId, attachments, tagPrefix }) {
  const list = Array.isArray(attachments) ? attachments.filter(Boolean) : [];
  const out = [];
  for (let i = 0; i < list.length; i++) {
    const a = list[i];
    const tag = `${tagPrefix || 'anexo'}-${i + 1}`;
    const uploaded = await uploadDiscordAttachment({ kind, guildId, recordId, attachment: a, tag });
    out.push({
      url: uploaded.url,
      name: a.name || uploaded.name,
      contentType: uploaded.contentType || a.contentType || null,
      size: a.size ?? null
    });
  }
  return out;
}

function firstImageUrl(attachments) {
  const list = Array.isArray(attachments) ? attachments : [];
  const first = list.find((a) => guessContentGroup(a?.contentType, a?.name) === 'image');
  return first?.url ? normalizeUrl(first.url) : null;
}

function getDraftStore(client) {
  if (!client.investigationDrafts) client.investigationDrafts = new Map();
  return client.investigationDrafts;
}

function getDraftKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

async function ensureCommandId(client, guild, name) {
  const n = String(name || '').trim();
  if (!n) return null;
  if (client?.commandIds?.get?.(n)) return client.commandIds.get(n);

  await client.application?.fetch?.().catch(() => {});

  const global = await client.application?.commands.fetch().catch(() => null);
  if (global) {
    for (const cmd of global.values()) {
      if (cmd?.name && cmd?.id) client.commandIds.set(String(cmd.name), String(cmd.id));
    }
  }

  const guildCmds = await guild?.commands?.fetch?.().catch(() => null);
  if (guildCmds) {
    for (const cmd of guildCmds.values()) {
      if (cmd?.name && cmd?.id) client.commandIds.set(String(cmd.name), String(cmd.id));
    }
  }

  return client?.commandIds?.get?.(n) || null;
}

function typeLabel(type) {
  if (type === 'GOV') return '🏛️ Organização do Governo';
  if (type === 'CRIME') return '💀 Organização Criminosa';
  if (type === 'PERSON') return '👤 Pessoa';
  return '📁 Outros';
}

function typeSlug(type) {
  if (type === 'GOV') return 'gov';
  if (type === 'CRIME') return 'crime';
  if (type === 'PERSON') return 'pessoa';
  return 'outros';
}

function buildTypeSelectEmbed() {
  return baseEmbed({
    title: '🕵️ Abertura de Investigação',
    description:
      'Selecione o tipo de investigação para continuar.\n\n' +
      '• Cards investigativos\n' +
      '• Fluxo guiado\n' +
      '• Provas organizadas por categoria\n' +
      '• Tema escuro e profissional'
  });
}

function buildTypeSelectComponents() {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pc:inv:type:GOV').setLabel('🏛️ Governo').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('pc:inv:type:CRIME').setLabel('💀 Criminosa').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('pc:inv:type:PERSON').setLabel('👤 Pessoa').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('pc:inv:type:OTHER').setLabel('📁 Outros').setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pc:inv:cancelWizard').setLabel('Cancelar').setStyle(ButtonStyle.Danger)
  );

  return [row1, row2];
}

function buildDraftPanelEmbed(draft) {
  const embed = baseEmbed({
    title: '📂 Painel Investigativo (Pré-abertura)',
    description: 'Catálogo premium • Provas organizadas por categorias'
  });

  embed.addFields(
    {
      name: '📌 Identificação',
      value:
        `Tipo: **${typeLabel(draft.type)}**\n` +
        `Alvo: **${draft.subjectDisplay}**\n` +
        (draft.subjectPassport ? `Passaporte: **${draft.subjectPassport}**\n` : '') +
        `Responsável: <@${draft.creatorId}>`,
      inline: false
    },
    {
      name: '📝 Detalhes',
      value:
        `Motivo: **${draft.motive}**\n` +
        `Prioridade: **${draft.priority}**\n` +
        `Data do ocorrido: **${draft.occurredDate}**\n` +
        `Observações: ${draft.notes || '—'}`,
      inline: false
    },
    {
      name: '📷 Imagens',
      value: draft.evidence.images.length ? `Arquivos: **${draft.evidence.images.length}**` : 'Aguardando upload',
      inline: true
    },
    {
      name: '🎥 Vídeos',
      value: draft.evidence.videos.length ? `Arquivos: **${draft.evidence.videos.length}**` : 'Aguardando upload',
      inline: true
    },
    {
      name: '🎙️ Gravações',
      value: draft.evidence.audio.length ? `Arquivos: **${draft.evidence.audio.length}**` : 'Aguardando upload',
      inline: true
    },
    {
      name: '🔗 Links',
      value: draft.evidence.links.length ? `Links: **${draft.evidence.links.length}**` : 'Aguardando links',
      inline: true
    }
  );

  embed.addFields({
    name: '✅ Finalização',
    value:
      'Envie provas por categoria.\n' +
      'Você pode arrastar os arquivos para este canal após clicar na categoria.\n' +
      'Depois, clique em **FINALIZAR INVESTIGAÇÃO** para abrir o ticket oficial.',
    inline: false
  });

  return embed;
}

function buildDraftPanelComponents(channelId) {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`pc:inv:evidence:images:${channelId}`).setLabel('📷 Imagens').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`pc:inv:evidence:videos:${channelId}`).setLabel('🎥 Vídeos').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`pc:inv:evidence:audio:${channelId}`).setLabel('🎙️ Gravações').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`pc:inv:links:${channelId}`).setLabel('🔗 Links').setStyle(ButtonStyle.Primary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`pc:inv:finalize:${channelId}`).setLabel('FINALIZAR INVESTIGAÇÃO').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`pc:inv:cancel:${channelId}`).setLabel('Cancelar').setStyle(ButtonStyle.Danger)
  );

  return [row1, row2];
}

async function resolveInvestigationFinalChannel(guild, config) {
  if (!guild?.channels) return null;

  const candidateIds = [config?.channels?.investigationFinalChannelId, config?.channels?.investigationChannelId].filter(Boolean);
  for (const channelId of candidateIds) {
    const cached = guild.channels.cache?.get?.(channelId);
    if (cached?.type === ChannelType.GuildText) return cached;

    if (typeof guild.channels.fetch === 'function') {
      const fetched = await guild.channels.fetch(channelId).catch(() => null);
      if (fetched?.type === ChannelType.GuildText) return fetched;
    }
  }

  return null;
}

async function updateDraftPanelMessage(channel, draft) {
  const messages = await channel.messages.fetch({ limit: 20 }).catch(() => null);
  if (!messages) return;
  const panel = [...messages.values()].find((m) => m.author?.bot && m.embeds?.[0]?.title === '📂 Painel Investigativo (Pré-abertura)') ?? null;
  if (!panel) return;
  await panel.edit({ embeds: [buildDraftPanelEmbed(draft)], components: buildDraftPanelComponents(channel.id) }).catch(() => {});
}

function bulletList(items, toLine, maxItems = 20) {
  const list = Array.isArray(items) ? items.filter(Boolean) : [];
  const max = Math.max(1, Math.min(40, Number(maxItems) || 20));
  const head = list.slice(0, max);
  const lines = head.map((x) => `• ${toLine(x)}`);
  if (list.length > max) lines.push(`• ... +${list.length - max}`);
  return lines.join('\n');
}

function parseUrls(text) {
  const raw = String(text || '').trim();
  if (!raw) return [];

  const tokens = [];
  for (const line of raw.split('\n')) {
    const parts = String(line || '')
      .trim()
      .split(/\s+/g)
      .filter(Boolean);
    for (const part of parts) {
      if (part.startsWith('http://') || part.startsWith('https://')) tokens.push(part);
    }
  }

  const uniq = [];
  const seen = new Set();
  for (const u of tokens) {
    if (seen.has(u)) continue;
    seen.add(u);
    uniq.push(u);
  }
  return uniq.slice(0, 20);
}

function formatNamedLinks({ name, urls }) {
  const base = String(name || '').trim();
  const list = Array.isArray(urls) ? urls.filter(Boolean) : [];
  if (!base || !list.length) return null;
  const lines = list.map((u, idx) => {
    const label = list.length > 1 ? `${base} ${idx + 1}` : base;
    return `• [${label}](${u})`;
  });
  return lines.join('\n').slice(0, 1200);
}

function normalizeText(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function countImageAttachments(evidence) {
  const atts = Array.isArray(evidence?.attachments) ? evidence.attachments : [];
  return atts.filter((a) => guessContentGroup(a?.contentType, a?.name) === 'image').length;
}

function hasNameAndPassport(text) {
  const t = normalizeText(text);
  if (!t) return false;
  const hasPassportWord = t.includes('passaporte') || t.includes('passap');
  const hasNumber = /\b\d{1,6}\b/.test(t);
  const hasLetters = /[a-z]{3,}/.test(t);
  return (hasPassportWord && hasNumber) || (hasNumber && hasLetters);
}

const INVESTIGATION_CLOSURE_REQUIREMENTS = [
  {
    key: 'bau',
    title: 'Foto da localização do baú',
    required: true,
    minPhotos: 1,
    maxPhotos: 3,
    sample: 'BAÚ — localização'
  },
  {
    key: 'armados',
    title: 'Pessoas armadas dentro da facção',
    required: true,
    minPhotos: 1,
    maxPhotos: 4,
    requireIdentity: true,
    sample: 'ARMADOS — NOME SOBRENOME — Passaporte 123'
  },
  { key: 'rosto00', title: 'Rosto do(a) 00', required: true, minPhotos: 1, maxPhotos: 1, requireIdentity: true, sample: 'ROSTO 00 — NOME — Passaporte 123' },
  { key: 'rosto01', title: 'Rosto do(a) 01', required: true, minPhotos: 1, maxPhotos: 1, requireIdentity: true, sample: 'ROSTO 01 — NOME — Passaporte 123' },
  { key: 'rosto02', title: 'Rosto do(a) 02 (opcional)', required: false, minPhotos: 0, maxPhotos: 1, requireIdentity: true, sample: 'ROSTO 02 — NOME — Passaporte 123' },
  {
    key: 'gerente',
    title: 'Rosto do(a) gerente',
    required: true,
    minPhotos: 1,
    maxPhotos: 1,
    requireIdentity: true,
    sample: 'GERENTE — NOME — Passaporte 123'
  },
  {
    key: 'gerente2',
    title: 'Rosto do(a) gerente 2 (opcional)',
    required: false,
    minPhotos: 0,
    maxPhotos: 1,
    requireIdentity: true,
    sample: 'GERENTE 2 — NOME — Passaporte 123'
  },
  { key: 'mapa', title: 'Foto do mapa marcando a localização', required: true, minPhotos: 1, maxPhotos: 1, sample: 'MAPA — localização marcada' }
];

function evidenceMatchesRequirement(evidence, reqKey) {
  const desc = normalizeText(evidence?.description);
  if (!desc) return false;
  if (desc.includes(`req:${String(reqKey || '').toLowerCase()}`)) return true;
  if (reqKey === 'bau') return desc.includes('bau') || desc.includes('baú');
  if (reqKey === 'armados') return desc.includes('armad') || desc.includes('armados');
  if (reqKey === 'rosto00') return desc.includes('rosto 00') || desc.includes('00') && desc.includes('rosto');
  if (reqKey === 'rosto01') return desc.includes('rosto 01') || desc.includes('01') && desc.includes('rosto');
  if (reqKey === 'rosto02') return desc.includes('rosto 02') || desc.includes('02') && desc.includes('rosto');
  if (reqKey === 'gerente2') return desc.includes('gerente 2') || desc.includes('gerente2');
  if (reqKey === 'gerente') return desc.includes('gerente') && !desc.includes('gerente 2') && !desc.includes('gerente2');
  if (reqKey === 'mapa') return desc.includes('mapa');
  return false;
}

function buildClosureChecklistEmbed({ inv, items }) {
  const embed = baseEmbed({
    title: '✅ Checklist de Encerramento',
    description: `Investigação: **${inv?.name || '—'}**\nEnvie o que estiver faltando usando **/fotos**.`
  }).setColor(BRAND.colors.GRAY_DARK);

  for (const it of items) {
    const optionalDone = !it.required && it.photos > 0 && it.identityOk;
    const status = it.ok || optionalDone ? '✅ OK' : it.required ? '❌ FALTANDO' : '⚪ Opcional';
    const detailsParts = [];
    if (it.maxPhotos > 0) detailsParts.push(`Fotos: **${it.photos}/${it.maxPhotos}** (mín: ${it.minPhotos})`);
    if (it.requireIdentity) detailsParts.push(it.identityOk ? 'Identificação: **OK**' : 'Identificação: **FALTANDO**');
    embed.addFields({
      name: `${status} • ${it.title}`,
      value: detailsParts.join('\n') || '—',
      inline: false
    });
  }

  embed.addFields({
    name: '📌 Como enviar',
    value:
      'Use o comando **/fotos** neste canal.\n' +
      'No campo **nome**, use o padrão sugerido nos botões.\n' +
      'Para “Outras provas”, use `/fotos nome:"OUTRA PROVA — resumo da prova"`.',
    inline: false
  });

  return embed;
}

async function getClosureChecklistState(inv) {
  const evidences = await getEvidencesByInvestigationId(inv.id).catch(() => []);

  const items = INVESTIGATION_CLOSURE_REQUIREMENTS.map((req) => {
    const matching = evidences.filter((ev) => evidenceMatchesRequirement(ev, req.key));
    const photos = matching.reduce((sum, ev) => sum + countImageAttachments(ev), 0);
    const capped = req.maxPhotos > 0 ? Math.min(photos, req.maxPhotos) : photos;
    const identityOk = req.requireIdentity ? matching.some((ev) => hasNameAndPassport(ev.description)) : true;
    const ok = req.required ? capped >= req.minPhotos && identityOk : false;
    return { ...req, photos: capped, identityOk, ok };
  });

  const missingRequired = items.filter((it) => it.required && !it.ok).map((it) => it.key);
  const canProceedPdf = missingRequired.length === 0;

  return { items, canProceedPdf };
}

function buildClosureChecklistComponents({ items, canProceedPdf }) {
  const missingRequired = items.filter((it) => it.required && !it.ok);
  const missingOptional = items.filter((it) => !it.required && it.photos === 0);
  const order = [...missingRequired, ...missingOptional];

  function labelForKey(key) {
    if (key === 'bau') return 'BAÚ';
    if (key === 'armados') return 'ARMADOS';
    if (key === 'rosto00') return 'ROSTO 00';
    if (key === 'rosto01') return 'ROSTO 01';
    if (key === 'rosto02') return 'ROSTO 02';
    if (key === 'gerente') return 'GERENTE';
    if (key === 'gerente2') return 'GERENTE 2';
    if (key === 'mapa') return 'MAPA';
    return String(key || 'ITEM').toUpperCase();
  }

  const buttons = order.map((it) =>
    new ButtonBuilder()
      .setCustomId(`pc:inv:req:${it.key}`)
      .setLabel(it.required ? `📷 ${labelForKey(it.key)}` : `➕ ${labelForKey(it.key)}`)
      .setStyle(it.required ? ButtonStyle.Primary : ButtonStyle.Secondary)
  );

  const rows = [];
  for (let i = 0; i < buttons.length; i += 5) {
    rows.push(new ActionRowBuilder().addComponents(...buttons.slice(i, i + 5)));
  }

  const rowActions = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pc:inv:req:refresh').setLabel('🔄 Atualizar').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('pc:inv:req:pdf')
      .setLabel('📄 Ir para PDF')
      .setStyle(ButtonStyle.Success)
      .setDisabled(!canProceedPdf)
  );

  rows.push(rowActions);
  return rows.slice(0, 5);
}

async function upsertClosureChecklistMessage(channel, inv) {
  const state = await getClosureChecklistState(inv);
  const embed = buildClosureChecklistEmbed({ inv, items: state.items });
  const components = buildClosureChecklistComponents(state);

  const targetId = inv?.closure_checklist_message_id ? String(inv.closure_checklist_message_id) : null;
  let msg = null;

  if (targetId) {
    msg = await channel.messages.fetch(targetId).catch(() => null);
  }

  if (!msg) {
    const recent = await channel.messages.fetch({ limit: 30 }).catch(() => null);
    msg =
      recent?.find((m) => m.author?.bot && m.embeds?.[0]?.title === '✅ Checklist de Encerramento') ??
      null;
  }

  if (msg) {
    await msg.edit({ embeds: [embed], components }).catch(() => {});
  } else {
    msg = await channel.send({ embeds: [embed], components }).catch(() => null);
  }

  if (msg && (!targetId || targetId !== msg.id)) {
    await updateInvestigation(inv.id, { closure_checklist_message_id: msg.id }).catch(() => {});
  }

  return { message: msg, state };
}

function buildDraftEvidenceEmbed({ draft, authorId, kindLabel, items }) {
  const embed = baseEmbed({
    title: `📎 ${kindLabel} adicionados`,
    description:
      `Investigado: **${draft.subjectDisplay}**\n` +
      `Responsável: <@${authorId}>\n\n` +
      (items.length ? bulletList(items, (x) => x, 25) : 'Nenhum item.')
  });
  return embed;
}

function buildDraftFilesEmbed({ draft, authorId, kindLabel, files }) {
  const embed = baseEmbed({
    title: `📎 ${kindLabel} adicionados`,
    description:
      `Investigado: **${draft.subjectDisplay}**\n` +
      `Responsável: <@${authorId}>\n\n` +
      (files.length ? bulletList(files, (f) => `[${f.name}](${f.url})`, 25) : 'Nenhum arquivo.')
  });

  const preview = firstImageUrl(files);
  if (preview) embed.setImage(preview);

  return embed;
}

function isImage(att) {
  return guessContentGroup(att?.contentType, att?.name) === 'image';
}

function isVideo(att) {
  return guessContentGroup(att?.contentType, att?.name) === 'video';
}

function isAudio(att) {
  return guessContentGroup(att?.contentType, att?.name) === 'audio';
}

async function collectAttachments(channel, userId, predicate) {
  const instruction = await channel
    .send(
      `Envie agora o(s) arquivo(s) como anexo nesta conversa.\n` +
        `• Tempo: 2 minutos\n` +
        `• Você pode arrastar e soltar os arquivos aqui`
    )
    .catch(() => null);

  const collected = await new Promise((resolve) => {
    const collector = channel.createMessageCollector({
      time: 2 * 60 * 1000,
      filter: (m) => m.author?.id === userId && m.attachments?.size > 0
    });

    const out = [];

    collector.on('collect', (m) => {
      const atts = [...m.attachments.values()];
      const filtered = predicate ? atts.filter(predicate) : atts;
      if (!filtered.length) return;
      out.push(...filtered);
      m.delete().catch(() => {});
      collector.stop('ok');
    });

    collector.on('end', () => resolve(out));
  });

  if (instruction) setTimeout(() => instruction.delete().catch(() => {}), 15000);
  return collected;
}

async function fetchLatestAttachmentMessage(channel, userId, predicate) {
  const messages = await channel.messages.fetch({ limit: 100 });
  const found = [...messages.values()]
    .sort((a, b) => b.createdTimestamp - a.createdTimestamp)
    .find((m) => m.author?.id === userId && m.attachments?.size > 0);
  if (!found) return null;

  const attachments = [...found.attachments.values()];
  const filtered = predicate ? attachments.filter(predicate) : attachments;
  if (filtered.length === 0) return null;

  return { message: found, attachments: filtered };
}

function isInvestigative(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return true;
  return member.roles.cache.has(config.roles.investigativeRoleId);
}

async function showModalSafe(interaction, modal) {
  if (typeof interaction.showModal === 'function') {
    return await interaction.showModal(modal);
  }
  const v = (() => {
    try {
      return require('discord.js')?.version || null;
    } catch {
      return null;
    }
  })();
  logger.error(
    { discordjs: v, type: interaction?.type, customId: interaction?.customId },
    'Interaction sem showModal()'
  );
  const content =
    'Falha ao abrir modal: sua hospedagem está rodando com discord.js sem suporte a modais.\n' +
    `Versão detectada: ${v || 'desconhecida'}\n` +
    'No Discloud, faça rebuild completo (reinstalar dependências) e confirme discord.js v14.';
  if (interaction.deferred || interaction.replied) {
    return await interaction.followUp({ content, flags: MessageFlags.Ephemeral }).catch(() => {});
  }
  return await interaction.reply({ content, flags: MessageFlags.Ephemeral }).catch(() => {});
}

async function handleInvestigationPanelButton(client, interaction) {
  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  if (!isInvestigative(config, member)) {
    return await interaction.reply({ content: 'Apenas membros do Investigativo podem abrir investigações.', flags: MessageFlags.Ephemeral });
  }

  await interaction.reply({
    flags: MessageFlags.Ephemeral,
    embeds: [buildTypeSelectEmbed()],
    components: buildTypeSelectComponents()
  });
}

async function handleInvestigationModal(client, interaction) {
  if (interaction.isButton() && interaction.customId === 'pc:inv:fotos') {
    const inv = await getOpenInvestigationByChannel(interaction.channelId);
    if (!inv) return await interaction.reply({ content: 'Nenhuma investigação aberta encontrada neste canal.', flags: MessageFlags.Ephemeral });

    const cmdId = await ensureCommandId(client, interaction.guild, 'fotos');
    const mention = cmdId ? `</fotos:${cmdId}>` : null;

    return await interaction.reply({
      flags: MessageFlags.Ephemeral,
      content: mention
        ? `Clique para abrir o comando: ${mention}\n\nUse aqui mesmo neste canal para enviar fotos/vídeos/gravações e o bot salvar em embeds.`
        : `O comando **/fotos** ainda não foi registrado no Discord.\nRode \`npm run deploy:commands\` (de preferência com DEPLOY_GUILD_ID) e reinicie o bot.`
    });
  }

  if (interaction.isButton() && interaction.customId.startsWith('pc:inv:req:')) {
    const parts = interaction.customId.split(':');
    const key = parts[3] || null;
    const inv = await getOpenInvestigationByChannel(interaction.channelId);
    if (!inv) return await interaction.reply({ content: 'Nenhuma investigação aberta encontrada neste canal.', flags: MessageFlags.Ephemeral });

    if (key === 'open') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const { message } = await upsertClosureChecklistMessage(interaction.channel, inv);
      if (!message) return await interaction.editReply('Falha ao criar/atualizar o checklist. Verifique permissões do bot no canal.');
      return await interaction.editReply(`Checklist atualizado: ${message.url}`);
    }

    if (key === 'refresh') {
      await interaction.deferUpdate().catch(() => {});
      await upsertClosureChecklistMessage(interaction.channel, inv).catch(() => {});
      return;
    }

    if (key === 'pdf') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const state = await getClosureChecklistState(inv);
      if (!state.canProceedPdf) {
        return await interaction.editReply('Ainda faltam itens obrigatórios do checklist. Clique em **🔄 Atualizar** após enviar as fotos.');
      }

      const embed = baseEmbed({
        title: 'Finalização de Investigação',
        description:
          'Envie o **PDF do Inquérito** como anexo neste canal e depois clique em **Confirmar PDF**.\n\n' +
          'Somente após o envio do PDF a investigação será finalizada.'
      });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:investigationConfirmPdf').setLabel('Confirmar PDF').setStyle(ButtonStyle.Success)
      );

      await interaction.channel.send({ embeds: [embed], components: [row] }).catch(() => {});
      return await interaction.editReply('Checklist completo. Envie o PDF no canal e confirme no botão.');
    }

    const req = INVESTIGATION_CLOSURE_REQUIREMENTS.find((r) => r.key === key) || null;
    if (!req) return await interaction.reply({ content: 'Opção inválida.', flags: MessageFlags.Ephemeral });

    const cmdId = await ensureCommandId(client, interaction.guild, 'fotos');
    const mention = cmdId ? `</fotos:${cmdId}>` : '`/fotos`';
    const slots =
      req.maxPhotos && req.maxPhotos > 1
        ? `foto_1 (obrigatória) + foto_2..foto_${Math.min(5, req.maxPhotos)}`
        : 'foto_1 (obrigatória)';

    const content =
      `Envio necessário: **${req.title}**\n` +
      `Use: ${mention} neste canal\n` +
      `Campo **categoria**: **${req.key}**\n` +
      `Campo **nome**: **${req.sample}**\n` +
      (req.requireIdentity ? 'Campo **identificacao**: informe **Nome e Passaporte** (pode ser várias linhas).\n' : '') +
      `Fotos: ${slots}`;

    return await interaction.reply({ content, flags: MessageFlags.Ephemeral });
  }

  if (
    interaction.isButton() &&
    (interaction.customId.startsWith('pc:inv:evidence:') ||
      interaction.customId.startsWith('pc:inv:links:') ||
      interaction.customId.startsWith('pc:inv:finalize:') ||
      interaction.customId.startsWith('pc:inv:cancel:'))
  ) {
    const cmdId = client?.commandIds?.get?.('fotos') || null;
    const mention = cmdId ? `</fotos:${cmdId}>` : '`/fotos`';
    const res = await interaction.reply({
      flags: MessageFlags.Ephemeral,
      content: `Esse método antigo foi removido.\nUse ${mention} neste canal para enviar as mídias no mesmo formato do /prisao.`
    });
    try {
      if (interaction.message?.editable) {
        const embed = baseEmbed({
          title: 'Atualização do Sistema',
          description: `Envio por botões foi removido.\nUse ${mention} neste canal.`
        });
        await interaction.message.edit({ embeds: [embed], components: [] }).catch(() => {});
      }
      if (interaction.message?.deletable) {
        setTimeout(() => interaction.message.delete().catch(() => {}), 4000);
      }
    } catch {}
    return res;
  }

  if (interaction.isButton() && interaction.customId === 'pc:inv:cancelWizard') {
    return await interaction.reply({ content: 'Abertura de investigação cancelada.', flags: MessageFlags.Ephemeral });
  }

  if (interaction.isButton() && interaction.customId === 'pc:inv:openDetails') {
    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!isInvestigative(config, member)) {
      return await interaction.reply({ content: 'Apenas membros do Investigativo podem abrir investigações.', flags: MessageFlags.Ephemeral });
    }

    const store = getDraftStore(client);
    const key = getDraftKey(interaction.guild.id, interaction.user.id);
    const draft = store.get(key);
    if (!draft) return await interaction.reply({ content: 'Sessão de investigação expirada. Refaça a abertura.', flags: MessageFlags.Ephemeral });

    const modal = new ModalBuilder().setCustomId('pc:inv:detailsModal').setTitle('Etapa 3 — Detalhes');

    const motive = new TextInputBuilder()
      .setCustomId('motive')
      .setLabel('Motivo da investigação')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(120);

    const report = new TextInputBuilder()
      .setCustomId('report')
      .setLabel('Relato completo')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1500);

    const priority = new TextInputBuilder()
      .setCustomId('priority')
      .setLabel('Nível de prioridade')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(30);

    const occurredDate = new TextInputBuilder()
      .setCustomId('occurredDate')
      .setLabel('Data do ocorrido (DD/MM/AAAA)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(10);

    const notes = new TextInputBuilder()
      .setCustomId('notes')
      .setLabel('Observações (opcional)')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setMaxLength(900);

    modal.addComponents(
      new ActionRowBuilder().addComponents(motive),
      new ActionRowBuilder().addComponents(report),
      new ActionRowBuilder().addComponents(priority),
      new ActionRowBuilder().addComponents(occurredDate),
      new ActionRowBuilder().addComponents(notes)
    );

    return await showModalSafe(interaction, modal);
  }

  if (interaction.isButton() && interaction.customId.startsWith('pc:inv:type:')) {
    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!isInvestigative(config, member)) {
      return await interaction.reply({ content: 'Apenas membros do Investigativo podem abrir investigações.', flags: MessageFlags.Ephemeral });
    }

    const type = interaction.customId.split(':')[3];
    const modal = new ModalBuilder().setCustomId(`pc:inv:idModal:${type}`).setTitle('Etapa 2 — Identificação');

    if (type === 'GOV') {
      const org = new TextInputBuilder()
        .setCustomId('orgName')
        .setLabel('Nome da organização')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(60);
      modal.addComponents(new ActionRowBuilder().addComponents(org));
    } else if (type === 'CRIME') {
      const fac = new TextInputBuilder()
        .setCustomId('orgName')
        .setLabel('Nome da facção/organização')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(60);
      modal.addComponents(new ActionRowBuilder().addComponents(fac));
    } else if (type === 'PERSON') {
      const name = new TextInputBuilder()
        .setCustomId('personName')
        .setLabel('Nome da pessoa')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(60);
      const passport = new TextInputBuilder()
        .setCustomId('passport')
        .setLabel('Passaporte')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(20);
      modal.addComponents(new ActionRowBuilder().addComponents(name), new ActionRowBuilder().addComponents(passport));
    } else {
      const title = new TextInputBuilder()
        .setCustomId('title')
        .setLabel('Nome/título da investigação')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(60);
      modal.addComponents(new ActionRowBuilder().addComponents(title));
    }

    return await showModalSafe(interaction, modal);
  }

  if (interaction.isModalSubmit() && interaction.customId.startsWith('pc:inv:idModal:')) {
    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!isInvestigative(config, member)) {
      return await interaction.reply({ content: 'Apenas membros do Investigativo podem abrir investigações.', flags: MessageFlags.Ephemeral });
    }

    const type = interaction.customId.split(':')[3];

    const store = getDraftStore(client);
    const key = getDraftKey(interaction.guild.id, interaction.user.id);

    let subjectDisplay = '';
    let subjectPassport = null;

    if (type === 'GOV' || type === 'CRIME') {
      subjectDisplay = interaction.fields.getTextInputValue('orgName').trim();
    } else if (type === 'PERSON') {
      const personName = interaction.fields.getTextInputValue('personName').trim();
      subjectPassport = interaction.fields.getTextInputValue('passport').trim();
      subjectDisplay = `${personName} ┃ ${subjectPassport}`;
    } else {
      subjectDisplay = interaction.fields.getTextInputValue('title').trim();
    }

    store.set(key, {
      guildId: interaction.guild.id,
      creatorId: interaction.user.id,
      type,
      subjectDisplay,
      subjectPassport,
      motive: null,
      report: null,
      priority: null,
      notes: null,
      occurredDate: null,
      evidence: { images: [], videos: [], audio: [], links: [] },
      draftChannelId: null
    });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('pc:inv:openDetails').setLabel('Continuar').setStyle(ButtonStyle.Primary)
    );
    return await interaction.reply({
      flags: MessageFlags.Ephemeral,
      content: 'Etapa 3 — Detalhes: clique em **Continuar** para abrir o próximo formulário.',
      components: [row]
    });
  }

  if (interaction.isModalSubmit() && interaction.customId === 'pc:inv:detailsModal') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!isInvestigative(config, member)) {
      return await interaction.editReply('Apenas membros do Investigativo podem abrir investigações.');
    }

    const store = getDraftStore(client);
    const key = getDraftKey(interaction.guild.id, interaction.user.id);
    const draft = store.get(key);
    if (!draft) return await interaction.editReply('Sessão de investigação expirada. Refaça a abertura.');

    draft.motive = interaction.fields.getTextInputValue('motive').trim();
    draft.report = interaction.fields.getTextInputValue('report').trim();
    draft.priority = interaction.fields.getTextInputValue('priority').trim();
    draft.occurredDate = interaction.fields.getTextInputValue('occurredDate').trim();
    draft.notes = interaction.fields.getTextInputValue('notes')?.trim() || null;

    const parentId = config.channels.investigationCategoryId || null;
    const slug = sanitizeChannelName(draft.subjectDisplay) || sanitizeChannelName(interaction.user.username) || 'investigacao';
    let channel = null;
    try {
      channel = await interaction.guild.channels.create({
        name: slug.slice(0, 90),
        type: ChannelType.GuildText,
        parent: parentId ?? undefined,
        permissionOverwrites: [
          { id: interaction.guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] }
        ]
      });
    } catch (err) {
      const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      logger.error({ err, errorId, flow: 'investigation', step: 'createChannel', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao criar canal de investigação');
      return await interaction.editReply(`Falha ao criar o canal da investigação. (erro: ${errorId})`);
    }

    const invName = `${typeLabel(draft.type)} • ${draft.subjectDisplay}`;
    const reason =
      `Tipo: ${typeLabel(draft.type)}\n` +
      `Investigado: ${draft.subjectDisplay}\n` +
      (draft.subjectPassport ? `Passaporte: ${draft.subjectPassport}\n` : '') +
      `Prioridade: ${draft.priority}\n` +
      `Data do ocorrido: ${draft.occurredDate}\n\n` +
      `Motivo: ${draft.motive}\n\n` +
      `Relato:\n${draft.report}\n\n` +
      (draft.notes ? `Observações:\n${draft.notes}` : '');

    await createInvestigation({
      guildId: interaction.guild.id,
      channelId: channel.id,
      creatorId: interaction.user.id,
      name: invName,
      reason
    });

    const embed = baseEmbed({
      title: 'Investigação Aberta',
      description:
        `Tipo: **${typeLabel(draft.type)}**\n` +
        `Investigado: **${draft.subjectDisplay}**\n` +
        `Investigador responsável: <@${interaction.user.id}>\n\n` +
        `Prioridade: **${draft.priority}**\n` +
        `Data do ocorrido: **${draft.occurredDate}**\n\n` +
        `Motivo:\n${draft.motive}\n\n` +
        `Relato:\n${draft.report}`
    });

    const actions = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('pc:evidenceStart').setLabel('Adicionar Evidência').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('pc:inv:fotos').setLabel('📷 /fotos').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('pc:inv:req:open').setLabel('✅ Checklist').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('pc:investigationConclude').setLabel('Concluir Investigação').setStyle(ButtonStyle.Secondary)
    );

    await channel.send({ embeds: [embed], components: [actions] }).catch((err) => {
      logger.warn({ err, flow: 'investigation', step: 'sendInvestigationOpenedMessage', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao enviar mensagem de investigação aberta');
    });

    store.delete(key);
    await interaction.editReply(`Investigação criada com sucesso: <#${channel.id}>`);
    return;
  }

  if (interaction.isModalSubmit() && interaction.customId === 'pc:investigationModal') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const config = await getOrCreateGuildConfig(interaction.guild.id);
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!isInvestigative(config, member)) {
      return await interaction.editReply('Apenas membros do Investigativo podem abrir investigações.');
    }

    const name = interaction.fields.getTextInputValue('name').trim();
    const reason = interaction.fields.getTextInputValue('reason').trim();

    const parentId = config.channels.investigationCategoryId || interaction.channel?.parentId || null;
    const channelName = (sanitizeChannelName(name) || sanitizeChannelName(interaction.user.username) || 'investigacao').slice(0, 90);

    let channel = null;
    try {
      channel = await interaction.guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: parentId ?? undefined,
        permissionOverwrites: [
          { id: interaction.guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] }
        ]
      });
    } catch (err) {
      const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      logger.error({ err, errorId, flow: 'investigation', step: 'createChannelLegacy', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao criar canal de investigação (fluxo legado)');
      return await interaction.editReply(`Falha ao criar o canal da investigação. (erro: ${errorId})`);
    }

    try {
      await createInvestigation({
        guildId: interaction.guild.id,
        channelId: channel.id,
        creatorId: interaction.user.id,
        name,
        reason
      });
    } catch (err) {
      const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      logger.error({ err, errorId, flow: 'investigation', step: 'createInvestigation', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao abrir investigação');
      await channel.delete().catch(() => {});
      return await interaction.editReply(`Falha ao salvar a investigação no banco. (erro: ${errorId})`);
    }

    const embed = baseEmbed({
      title: 'Investigação Aberta',
      description:
        `Nome: **${name}**\n` +
        `Investigador responsável: <@${interaction.user.id}>\n\n` +
        `Motivo:\n${reason}`
    });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('pc:evidenceStart').setLabel('Adicionar Evidência').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('pc:inv:fotos').setLabel('📷 /fotos').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('pc:inv:req:open').setLabel('✅ Checklist').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('pc:investigationConclude').setLabel('Concluir Investigação').setStyle(ButtonStyle.Secondary)
    );

    await channel.send({ embeds: [embed], components: [row] }).catch((err) => {
      logger.warn({ err, flow: 'investigation', step: 'sendInvestigationMessage', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao enviar mensagem de investigação');
    });

    await interaction.editReply(`Investigação criada com sucesso: <#${channel.id}>`);
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  if (!isInvestigative(config, member)) {
    return await interaction.editReply('Apenas membros do Investigativo podem abrir investigações.');
  }

  logger.warn({ customId: interaction.customId, type: interaction.type }, 'Interação de investigação não roteada');
}

async function handleEvidenceStart(client, interaction) {
  const inv = await getOpenInvestigationByChannel(interaction.channelId);
  if (!inv) return await interaction.reply({ content: 'Nenhuma investigação aberta encontrada neste canal.', flags: MessageFlags.Ephemeral });

  if (inv.creator_id !== interaction.user.id && !interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
    return await interaction.reply({ content: 'Apenas o responsável ou administradores podem adicionar evidências.', flags: MessageFlags.Ephemeral });
  }

  const modal = new ModalBuilder().setCustomId(`pc:evidenceModal:${inv.id}`).setTitle('Adicionar Evidência');

  const personName = new TextInputBuilder()
    .setCustomId('personName')
    .setLabel('Nome da pessoa envolvida')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(50);

  const personId = new TextInputBuilder()
    .setCustomId('personId')
    .setLabel('ID da pessoa')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(20);

  const description = new TextInputBuilder()
    .setCustomId('description')
    .setLabel('Descrição da evidência')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(1200);

  const linkName = new TextInputBuilder()
    .setCustomId('linkName')
    .setLabel('Nome do link (se for enviar)')
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setMaxLength(60);

  const links = new TextInputBuilder()
    .setCustomId('links')
    .setLabel('Links (URLs) — um por linha')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(1200);

  modal.addComponents(
    new ActionRowBuilder().addComponents(personName),
    new ActionRowBuilder().addComponents(personId),
    new ActionRowBuilder().addComponents(description),
    new ActionRowBuilder().addComponents(linkName),
    new ActionRowBuilder().addComponents(links)
  );

  await showModalSafe(interaction, modal);
}

async function handleEvidenceModal(client, interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const investigationId = interaction.customId.split(':')[2];
  const inv = await getInvestigationById(investigationId);
  if (!inv || inv.status !== 'OPEN') return await interaction.editReply('Investigação não encontrada ou já concluída.');

  if (inv.channel_id !== interaction.channelId) return await interaction.editReply('Canal inválido para essa investigação.');

  const rawLinks = interaction.fields.getTextInputValue('links')?.trim() || '';
  const urls = parseUrls(rawLinks);
  const linkName = interaction.fields.getTextInputValue('linkName')?.trim() || '';
  if (urls.length && !linkName) {
    return await interaction.editReply('Antes de enviar links, informe também o **Nome do link**.');
  }
  const linksFormatted = urls.length ? formatNamedLinks({ name: linkName, urls }) : null;

  let evidence = null;
  try {
    evidence = await createEvidence({
      guildId: interaction.guild.id,
      investigationId: inv.id,
      channelId: interaction.channelId,
      authorId: interaction.user.id,
      personName: interaction.fields.getTextInputValue('personName').trim(),
      personId: interaction.fields.getTextInputValue('personId').trim(),
      description: interaction.fields.getTextInputValue('description').trim(),
      links: linksFormatted
    });
  } catch (err) {
    const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    logger.error(
      { err, errorId, flow: 'investigation', step: 'createEvidence', guildId: interaction.guild.id, userId: interaction.user.id },
      'Falha ao criar evidência'
    );
    return await interaction.editReply(`Falha ao criar a evidência no banco. (erro: ${errorId})`);
  }

  const embed = baseEmbed({
    title: 'Evidência (pré-registro)',
    description:
      `Autor: <@${interaction.user.id}>\n` +
      `Envolvido: **${evidence.person_name}** (ID: **${evidence.person_id}**)\n\n` +
      `Descrição:\n${evidence.description}\n\n` +
      (evidence.links ? `Links:\n${evidence.links}\n\n` : '') +
      'Para enviar fotos/vídeos/gravações, use o botão **📷 /fotos** neste canal.'
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pc:inv:fotos').setLabel('📷 /fotos').setStyle(ButtonStyle.Secondary)
  );

  await interaction.channel.send({ embeds: [embed], components: [row] });

  await interaction.editReply('Evidência registrada. Use /fotos neste canal para enviar as mídias.');
}

async function handleEvidenceConfirm(client, interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const evidenceId = interaction.customId.split(':')[2];
  const evidence = await getEvidenceById(evidenceId);
  if (!evidence) return await interaction.editReply('Evidência não encontrada.');
  if (evidence.author_id !== interaction.user.id) return await interaction.editReply('Apenas o autor pode confirmar os anexos.');

  const channel = interaction.channel;
  const latest = await fetchLatestAttachmentMessage(channel, interaction.user.id);
  if (!latest) return await interaction.editReply('Nenhum anexo encontrado. Envie os arquivos e tente novamente.');

  let uploaded = null;
  try {
    uploaded = await uploadEvidenceAttachments({
      kind: 'investigacoes',
      guildId: interaction.guild.id,
      recordId: evidenceId,
      attachments: latest.attachments,
      tagPrefix: 'evidencia'
    });
    await updateEvidence(evidenceId, { attachments: uploaded });
    latest.message.delete().catch(() => {});
  } catch (err) {
    const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    logger.error(
      { err, errorId, flow: 'investigation', step: 'confirmEvidence', guildId: interaction.guild.id, userId: interaction.user.id },
      'Falha ao confirmar evidência'
    );
    if (String(err?.message || '') === 'UNSUPPORTED_MEDIA_TYPE') {
      return await interaction.editReply(
        `Tipo de arquivo não suportado. Envie apenas imagens/vídeos/áudios/PDFs. (erro: ${errorId})`
      );
    }
    return await interaction.editReply(`Falha ao salvar os anexos. (erro: ${errorId})`);
  }

  const list = uploaded.map((a) => `• [${a.name}](${a.url})`).join('\n');
  const finalEmbed = baseEmbed({
    title: 'Evidência Registrada',
    description:
      `Autor: <@${evidence.author_id}>\n` +
      `Envolvido: **${evidence.person_name}** (ID: **${evidence.person_id}**)\n\n` +
      `Descrição:\n${evidence.description}\n\n` +
      (evidence.links ? `Links:\n${evidence.links}\n\n` : '') +
      `Arquivos:\n${list || 'Nenhum'}`
  });

  const imgs = uploaded.filter((a) => guessContentGroup(a?.contentType, a?.name) === 'image');
  const preview = firstImageUrl(imgs);
  if (preview) finalEmbed.setImage(preview);

  const embeds = [finalEmbed];
  for (let i = 0; i < Math.min(imgs.length, 9); i++) {
    const img = imgs[i];
    if (!img?.url) continue;
    embeds.push(
      makeImageEmbed({
        title: `📷 IMAGEM ${i + 1}`,
        description: `Evidência: **${evidence.person_name}**`,
        url: img.url
      })
    );
  }

  const downloadRows = buildDownloadRows(
    uploaded.map((a, idx) => ({
      label: a?.name ? String(a.name) : `Arquivo ${idx + 1}`,
      url: a?.url
    }))
  );

  if (interaction.message?.editable) {
    await interaction.message.edit({ embeds, components: downloadRows }).catch(() => {});
  } else {
    await channel.send({ embeds, components: downloadRows }).catch(() => {});
  }

  await interaction.editReply('Anexos confirmados e evidência registrada no canal.');
}

async function handleInvestigationConclude(client, interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const inv = await getOpenInvestigationByChannel(interaction.channelId);
  if (!inv) return await interaction.editReply('Nenhuma investigação aberta encontrada neste canal.');

  if (inv.creator_id !== interaction.user.id && !interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
    return await interaction.editReply('Apenas o responsável ou administradores podem concluir a investigação.');
  }

  const state = await getClosureChecklistState(inv);
  if (!state.canProceedPdf) {
    const { message } = await upsertClosureChecklistMessage(interaction.channel, inv);
    if (!message) {
      return await interaction.editReply('Falha ao criar/atualizar o checklist. Verifique permissões do bot no canal.');
    }
    return await interaction.editReply(
      `Checklist de encerramento atualizado: ${message.url}\nEnvie o que estiver faltando e clique em **🔄 Atualizar** no checklist.`
    );
  }

  const embed = baseEmbed({
    title: 'Finalização de Investigação',
    description:
      'Checklist completo ✅\n\n' +
      'Envie o **PDF do Inquérito** como anexo neste canal e depois clique em **Confirmar PDF**.\n\n' +
      'Somente após o envio do PDF a investigação será finalizada.'
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pc:investigationConfirmPdf').setLabel('Confirmar PDF').setStyle(ButtonStyle.Success)
  );

  await interaction.channel.send({ embeds: [embed], components: [row] });
  await interaction.editReply('Checklist completo. Envie o PDF no canal e confirme no botão.');
}

async function handleInvestigationConfirmPdf(client, interaction) {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const inv = await getOpenInvestigationByChannel(interaction.channelId);
  if (!inv) return await interaction.editReply('Nenhuma investigação aberta encontrada neste canal.');

  if (inv.creator_id !== interaction.user.id && !interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
    return await interaction.editReply('Apenas o responsável ou administradores podem confirmar o PDF.');
  }

  const messages = await interaction.channel.messages.fetch({ limit: 25 });
  const pdfMessage = [...messages.values()]
    .sort((a, b) => b.createdTimestamp - a.createdTimestamp)
    .find((m) => m.attachments?.size > 0 && [...m.attachments.values()].some((a) => (a.contentType || '').toLowerCase().includes('pdf') || (a.name || '').toLowerCase().endsWith('.pdf')));

  if (!pdfMessage) return await interaction.editReply('Nenhum PDF encontrado. Envie o PDF e tente novamente.');

  const pdf = [...pdfMessage.attachments.values()].find(
    (a) => (a.contentType || '').toLowerCase().includes('pdf') || (a.name || '').toLowerCase().endsWith('.pdf')
  );
  if (!pdf) return await interaction.editReply('Nenhum PDF válido encontrado. Envie o PDF e tente novamente.');

  let uploadedPdf = null;
  try {
    uploadedPdf = await uploadDiscordAttachment({
      kind: 'investigacoes',
      guildId: interaction.guild.id,
      recordId: inv.id,
      attachment: pdf,
      tag: 'inquerito'
    });
  } catch (err) {
    const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    logger.error({ err, errorId, flow: 'investigation', step: 'uploadPdf', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao enviar PDF');
    if (String(err?.message || '') === 'UNSUPPORTED_MEDIA_TYPE') {
      return await interaction.editReply(`Tipo de arquivo não suportado. Envie apenas PDF. (erro: ${errorId})`);
    }
    return await interaction.editReply(`Falha ao processar o PDF. (erro: ${errorId})`);
  }

  const closedAt = new Date().toISOString();
  await updateInvestigation(inv.id, {
    status: 'CLOSED',
    closed_at: closedAt,
    pdf: { url: uploadedPdf.url, name: pdf.name, size: pdf.size ?? null }
  });

  pdfMessage.delete().catch(() => {});

  await interaction.channel.setName(`✅-${interaction.channel.name}`.slice(0, 100)).catch((err) => {
    logger.warn({ err, flow: 'investigation', step: 'renameClosedChannel', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao renomear canal de investigação fechado');
  });
  await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: false }).catch((err) => {
    logger.warn({ err, flow: 'investigation', step: 'lockClosedChannel', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao bloquear canal de investigação fechado');
  });

  const config = await getOrCreateGuildConfig(interaction.guild.id);
  const finalChannel = await resolveInvestigationFinalChannel(interaction.guild, config);

  const embed = baseEmbed({
    title: 'Investigação Concluída',
    description:
      `Nome: **${inv.name}**\n` +
      `Investigador responsável: <@${inv.creator_id}>\n` +
      `Data: <t:${Math.floor(new Date(closedAt).getTime() / 1000)}:F>`,
    color: BRAND.colors.GRAY_DARK
  });

  const evidenceCount = await countEvidencesByInvestigationId(inv.id).catch(() => 0);
  embed.addFields({ name: '📎 Evidências', value: `Total registradas: **${evidenceCount}**`, inline: false });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setLabel('Baixar PDF').setStyle(ButtonStyle.Link).setURL(uploadedPdf.url)
  );

  if (finalChannel && finalChannel.type === ChannelType.GuildText) {
    await finalChannel.send({ embeds: [embed], components: [row] }).catch((err) => {
      logger.error({ err, flow: 'investigation', step: 'sendFinalChannel', guildId: interaction.guild.id, userId: interaction.user.id }, 'Falha ao enviar investigação finalizada para o canal de encerramentos');
    });
  } else {
    logger.warn({ guildId: interaction.guild.id, userId: interaction.user.id }, 'Canal de encerramento de investigações não encontrado');
  }

  await interaction.editReply('Investigação finalizada e enviada para o canal de encerramentos.');
}

module.exports = {
  resolveInvestigationFinalChannel,
  handleInvestigationPanelButton,
  handleInvestigationModal,
  handleEvidenceStart,
  handleEvidenceModal,
  handleEvidenceConfirm,
  handleInvestigationConclude,
  handleInvestigationConfirmPdf
};
