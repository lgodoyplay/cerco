const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');
const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { setGuildConfig } = require('../../services/guildConfig');
const { buildCoursesPanelEmbed } = require('../courses/coursesFlow');
const { buildNoticesPanelEmbed } = require('../notices/noticesFlow');
const { buildExonerationPanelEmbed } = require('../exoneration/exonerationFlow');
const { buildPromotionPanelEmbed } = require('../promotion/promotionFlow');
const { TIME_CLOCK_PANEL_CHANNEL_ID, buildPanelMessage: buildTimeclockPanelMessage } = require('../timeclock/timeclockFlow');

async function tryFetchMessage(channel, messageId) {
  if (!channel || !messageId) return null;
  try {
    return await channel.messages.fetch(messageId);
  } catch {
    return null;
  }
}

async function clearChannel(channel) {
  if (!channel || channel.type !== ChannelType.GuildText) return;

  const me = channel.guild.members.me;
  const perms = me ? channel.permissionsFor(me) : null;
  if (!perms?.has(PermissionsBitField.Flags.ManageMessages)) return;

  const fourteenDaysMs = 14 * 24 * 60 * 60 * 1000;
  let before;

  for (let i = 0; i < 10; i++) {
    const messages = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) }).catch(() => null);
    if (!messages || messages.size === 0) break;

    const deletable = messages.filter((m) => !m.pinned && m.deletable);
    const now = Date.now();
    const bulk = deletable.filter((m) => now - m.createdTimestamp < fourteenDaysMs);
    const older = deletable.filter((m) => now - m.createdTimestamp >= fourteenDaysMs);

    if (bulk.size > 0) await channel.bulkDelete(bulk, true).catch(() => {});
    for (const msg of older.values()) {
      await msg.delete().catch(() => {});
    }

    before = messages.last().id;
  }
}

async function ensurePanel({ guild, channelId, messageId, buildMessage, clearBeforeSend = false, forceResend = false }) {
  const channel = guild.channels.cache.get(channelId);
  if (!channel || channel.type !== ChannelType.GuildText) return { channel: null, message: null };

  if (!forceResend) {
    const existing = await tryFetchMessage(channel, messageId);
    if (existing) return { channel, message: existing };
  }

  if (clearBeforeSend) await clearChannel(channel);

  const msgPayload = await buildMessage();
  const created = await channel.send(msgPayload);
  return { channel, message: created };
}

async function ensurePanels(client, guild, config, options = {}) {
  const panels = { ...(config.panels ?? {}) };
  const clearBeforeSend = options.clearBeforeSend === true;
  const forceResend = options.forceResend === true;

  const verification = await ensurePanel({
    guild,
    channelId: config.channels.verificationChannelId,
    messageId: panels.verificationMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const embed = baseEmbed({
        title: '🛡️ Sistema de Identificação',
        description:
          '📌 Verificação institucional\n' +
          '📌 Seleção de departamento\n' +
          '📌 Integração automática\n' +
          '📌 Organização de cargos\n\n' +
          '⚠️ Preencha corretamente todas as informações.\n\n' +
          'Clique no botão abaixo para iniciar.'
      });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:verify').setLabel('INICIAR VERIFICAÇÃO').setStyle(ButtonStyle.Primary)
      );

      return { embeds: [embed], components: [row] };
    }
  });
  if (verification.message) panels.verificationMessageId = verification.message.id;

  const investigation = await ensurePanel({
    guild,
    channelId: config.channels.investigationChannelId,
    messageId: panels.investigationMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const embed = baseEmbed({
        title: 'Central de Investigações',
        description: 'Apenas membros do **Investigativo** podem abrir uma investigação.'
      });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:investigationOpen').setLabel('ABRIR INVESTIGAÇÃO').setStyle(ButtonStyle.Primary)
      );

      return { embeds: [embed], components: [row] };
    }
  });
  if (investigation.message) panels.investigationMessageId = investigation.message.id;

  const bo = await ensurePanel({
    guild,
    channelId: config.channels.boPanelChannelId ?? '1504304478172614667',
    messageId: panels.boMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const embed = baseEmbed({
        title: 'Boletim de Ocorrência (BO)',
        description: 'Clique no botão abaixo para preencher um BO via formulário.'
      });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:boFill').setLabel('Preencher BO').setStyle(ButtonStyle.Primary)
      );

      return { embeds: [embed], components: [row], allowedMentions: { parse: [] } };
    }
  });
  if (bo.message) panels.boMessageId = bo.message.id;

  const prison = await ensurePanel({
    guild,
    channelId: config.channels.prisonPanelChannelId,
    messageId: panels.prisonMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const embed = baseEmbed({
        title: '🚔 Central de Prisões',
        description:
          'Registro oficial de prisões • Fluxo institucional\n\n' +
          'Use o comando:\n' +
          ' `/prisao`\n\n' +
          'O Discord abrirá os campos nativos de upload (arrastar e soltar).\n' +
          'A embed final sai completa e organizada: **todas as imagens aparecem visualmente** em múltiplas embeds, sem anexos soltos e sem links expirando.'
      });

      return { embeds: [embed], components: [], allowedMentions: { parse: [] } };
    }
  });
  if (prison.message) panels.prisonMessageId = prison.message.id;

  const wanted = await ensurePanel({
    guild,
    channelId: config.channels.wantedPanelChannelId,
    messageId: panels.wantedMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const embed = baseEmbed({
        title: '🚨 Central de Procurados',
        description:
          'Registro oficial de procurados • Catálogo investigativo\n\n' +
          'Use o comando:\n' +
          ' `/procurado`\n\n' +
          'O Discord abrirá os campos nativos de upload.\n' +
          'A embed final exibe **todas as imagens visualmente** em múltiplas embeds e inclui o botão **JÁ FOI PRESO**.'
      });

      return { embeds: [embed], components: [], allowedMentions: { parse: [] } };
    }
  });
  if (wanted.message) panels.wantedMessageId = wanted.message.id;

  const courses = await ensurePanel({
    guild,
    channelId: config.channels.coursesPanelChannelId,
    messageId: panels.coursesMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:courses:open').setLabel('SOLICITAR CURSO').setStyle(ButtonStyle.Primary)
      );

      return { embeds: [buildCoursesPanelEmbed()], components: [row], allowedMentions: { parse: [] } };
    }
  });
  if (courses.message) panels.coursesMessageId = courses.message.id;

  const notices = await ensurePanel({
    guild,
    channelId: config.channels.noticesPanelChannelId,
    messageId: panels.noticesMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:notices:create').setLabel('CRIAR AVISO').setStyle(ButtonStyle.Danger)
      );

      return { embeds: [buildNoticesPanelEmbed()], components: [row], allowedMentions: { parse: [] } };
    }
  });
  if (notices.message) panels.noticesMessageId = notices.message.id;

  const exoneration = await ensurePanel({
    guild,
    channelId: config.channels.exonerationPanelChannelId,
    messageId: panels.exonerationMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:exo:request').setLabel('SOLICITAR EXONERAÇÃO').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('pc:exo:admin').setLabel('EXONERAR MEMBRO').setStyle(ButtonStyle.Danger)
      );

      return { embeds: [buildExonerationPanelEmbed()], components: [row], allowedMentions: { parse: [] } };
    }
  });
  if (exoneration.message) panels.exonerationMessageId = exoneration.message.id;

  const corregedoria = await ensurePanel({
    guild,
    channelId: config.channels.corregedoriaPanelChannelId,
    messageId: panels.corregedoriaMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const embed = baseEmbed({
        title: '🛡️ Corregedoria Geral',
        description:
          '📌 Denúncias internas\n' +
          '📌 Abuso de autoridade\n' +
          '📌 Corrupção\n' +
          '📌 Quebra de conduta\n' +
          '📌 Investigação disciplinar\n\n' +
          '⚠️ **Todas as denúncias são sigilosas.**\n\n' +
          'Antes de abrir sua denúncia:\n' +
          '• Reúna todas as provas possíveis\n' +
          '• Envie vídeos, imagens, links, gravações e prints\n' +
          '• Escreva um relato completo e detalhado\n\n' +
          'Quanto mais informações forem enviadas, maior a qualidade da investigação.'
      });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:ticket:open').setLabel('ABRIR DENÚNCIA').setStyle(ButtonStyle.Danger)
      );

      return { embeds: [embed], components: [row] };
    }
  });
  if (corregedoria.message) panels.corregedoriaMessageId = corregedoria.message.id;

  const timeclock = await ensurePanel({
    guild,
    channelId: TIME_CLOCK_PANEL_CHANNEL_ID,
    messageId: panels.timeclockMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => buildTimeclockPanelMessage()
  });
  if (timeclock.message) panels.timeclockMessageId = timeclock.message.id;

  const promotion = await ensurePanel({
    guild,
    channelId: config.channels.promotionPanelChannelId,
    messageId: panels.promotionMessageId,
    clearBeforeSend,
    forceResend,
    buildMessage: async () => {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:promotion:open').setLabel('📈 SOLICITAR PROMOÇÃO').setStyle(ButtonStyle.Primary)
      );

      return { embeds: [buildPromotionPanelEmbed()], components: [row], allowedMentions: { parse: [] } };
    }
  });
  if (promotion.message) panels.promotionMessageId = promotion.message.id;

  await setGuildConfig(guild.id, { panels });
}

module.exports = { ensurePanels };
