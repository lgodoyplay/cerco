const { ensurePanels } = require('./panels');
module.exports = { ensurePanels };
