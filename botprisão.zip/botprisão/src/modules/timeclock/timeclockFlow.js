const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  PermissionsBitField,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  MessageFlags
} =
  require('discord.js');

const { baseEmbed } = require('../../core/embeds/baseEmbed');
const { logger } = require('../../lib/logger');
const { getLocalDb, withWrite } = require('../../database/localDb');

const TIME_CLOCK_PANEL_CHANNEL_ID = '1511171923608997970';
const TIME_CLOCK_LOG_CHANNEL_ID = '1511172809819160636';

const BLOCK_MINUTES = 40;
const BLOCK_VALUE = 20000;
const AUTO_CLOSE_MINUTES = 180;

function nowMs() {
  return Date.now();
}

function minutes(ms) {
  return Math.floor(ms / (60 * 1000));
}

function blocks(ms) {
  return Math.floor(ms / (BLOCK_MINUTES * 60 * 1000));
}

function money(value) {
  try {
    return Number(value || 0).toLocaleString('pt-BR');
  } catch {
    return String(value || 0);
  }
}

function fmtDuration(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function extractRecordId(customId, prefix) {
  const id = String(customId || '');
  if (!id.startsWith(prefix)) return null;
  const rest = id.slice(prefix.length);
  return rest ? rest : null;
}

function msUntilNextBlock(elapsedMs) {
  const blockMs = BLOCK_MINUTES * 60 * 1000;
  const mod = elapsedMs % blockMs;
  return blockMs - mod;
}

function ensureStore(db) {
  if (!db.timeclocks || typeof db.timeclocks !== 'object') db.timeclocks = {};
  return db.timeclocks;
}

function findOpenByUser(db, guildId, userId) {
  const store = ensureStore(db);
  for (const r of Object.values(store)) {
    if (!r) continue;
    if (String(r.guild_id) !== String(guildId)) continue;
    if (String(r.user_id) !== String(userId)) continue;
    if (String(r.status) === 'OPEN') return r;
  }
  return null;
}

function buildPanelMessage() {
  const embed = baseEmbed({
    title: '🕒 Bate Ponto (Investigação)',
    description:
      'Clique em **Bater Ponto** para iniciar seu serviço.\n' +
      'Clique em **Fechar Serviço** para encerrar e enviar para conferência/pagamento.\n\n' +
      `Regras:\n• A cada ${BLOCK_MINUTES} minutos: +${money(BLOCK_VALUE)}\n• Auto-fecha em ${AUTO_CLOSE_MINUTES / 60}h`
  });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('pc:timeclock:punch').setLabel('Bater Ponto').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('pc:timeclock:close').setLabel('Fechar Serviço').setStyle(ButtonStyle.Danger)
  );

  return { embeds: [embed], components: [row], allowedMentions: { parse: [] } };
}

function buildUserControls(hasOpen) {
  if (hasOpen) {
    return [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('pc:timeclock:punch').setLabel('Ponto em andamento').setStyle(ButtonStyle.Secondary).setDisabled(true),
        new ButtonBuilder().setCustomId('pc:timeclock:close').setLabel('Fechar Serviço').setStyle(ButtonStyle.Danger)
      )
    ];
  }
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('pc:timeclock:punch').setLabel('Bater Ponto').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('pc:timeclock:close').setLabel('Fechar Serviço').setStyle(ButtonStyle.Danger).setDisabled(true)
    )
  ];
}

function buildUserStatusEmbed(record) {
  const openedAt = new Date(record.opened_at);
  const elapsedMs = nowMs() - openedAt.getTime();
  const totalBlocks = blocks(elapsedMs);
  const amount = totalBlocks * BLOCK_VALUE;
  const nextInMs = msUntilNextBlock(elapsedMs);

  const embed = baseEmbed({
    title: '🕒 Ponto em andamento',
    description: `Oficial: <@${record.user_id}>`,
    color: 0x2b2d31
  });

  embed.addFields(
    { name: '🟩 Início', value: `<t:${Math.floor(openedAt.getTime() / 1000)}:F>`, inline: true },
    { name: '⏱️ Tempo', value: fmtDuration(elapsedMs), inline: true },
    { name: `⏳ Próximo bloco`, value: `${minutes(nextInMs)} min`, inline: true }
  );

  embed.addFields(
    { name: `💵 Blocos (${BLOCK_MINUTES}min)`, value: String(totalBlocks), inline: true },
    { name: '💰 Total acumulado', value: `${money(amount)} reais`, inline: true },
    { name: '📌 Motivo', value: record.open_reason || '—', inline: false }
  );

  return embed;
}

function buildLogEmbed(record) {
  const openedAt = new Date(record.opened_at);
  const closedAt = record.closed_at ? new Date(record.closed_at) : null;

  const elapsedMs = (closedAt ? closedAt.getTime() : nowMs()) - openedAt.getTime();
  const totalBlocks = blocks(elapsedMs);
  const amount = totalBlocks * BLOCK_VALUE;

  const embed = baseEmbed({
    title: '📋 Fechamento de Ponto (Investigação)',
    description: `Oficial: <@${record.user_id}>`,
    color: 0x2b2d31
  });

  embed.addFields(
    { name: '🟩 Início', value: `<t:${Math.floor(openedAt.getTime() / 1000)}:F>`, inline: true },
    { name: '🟥 Fim', value: closedAt ? `<t:${Math.floor(closedAt.getTime() / 1000)}:F>` : '—', inline: true },
    { name: '⏱️ Tempo', value: fmtDuration(elapsedMs), inline: true }
  );

  embed.addFields(
    { name: '📌 Motivo do ponto', value: record.open_reason || '—', inline: false },
    { name: '📝 Resumo do trabalho', value: record.close_summary || '—', inline: false }
  );

  embed.addFields(
    { name: `💵 Blocos (${BLOCK_MINUTES}min)`, value: String(totalBlocks), inline: true },
    { name: '💰 Valor a receber', value: `${money(amount)} reais`, inline: true },
    { name: '📍 Status', value: String(record.status || '—'), inline: true }
  );

  if (record.payment_status && record.payment_status !== 'PENDING') {
    embed.addFields({
      name: '✅ Pagamento',
      value:
        `Status: **${record.payment_status}**\n` +
        (record.payment_by ? `Responsável: <@${record.payment_by}>\n` : '') +
        (record.payment_at ? `Data: <t:${Math.floor(new Date(record.payment_at).getTime() / 1000)}:F>\n` : '') +
        (record.payment_reason ? `Motivo: ${record.payment_reason}` : ''),
      inline: false
    });
  }

  return { embed, amount, totalBlocks, elapsedMs };
}

async function upsertRecord(record) {
  await withWrite(async (d) => {
    const store = ensureStore(d);
    store[String(record.id)] = record;
  });
}

async function markPayment(recordId, patch) {
  const id = String(recordId);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d);
    const current = store[id] ?? null;
    if (!current) return;
    updated = { ...current, ...patch };
    store[id] = updated;
  });
  return updated;
}

async function safeDmUser(client, userId, content) {
  try {
    const u = await client.users.fetch(String(userId));
    await u.send(String(content)).catch(() => {});
  } catch {}
}

async function closeAndLog(client, record, { closedAtIso, status, closeSummary }) {
  const closedAt = closedAtIso || new Date().toISOString();
  const next = {
    ...record,
    status,
    closed_at: closedAt,
    close_summary: closeSummary || record.close_summary || null
  };

  const openedAt = new Date(next.opened_at);
  const elapsedMs = new Date(closedAt).getTime() - openedAt.getTime();
  const totalBlocks = blocks(elapsedMs);
  next.total_blocks = totalBlocks;
  next.total_amount = totalBlocks * BLOCK_VALUE;

  await upsertRecord(next);

  const guild = client.guilds.cache.get(String(next.guild_id)) || null;
  const channel = guild?.channels?.cache?.get(TIME_CLOCK_LOG_CHANNEL_ID) || null;
  if (channel && channel.type === ChannelType.GuildText) {
    const { embed } = buildLogEmbed(next);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`pc:timeclock:paid:${next.id}`).setLabel('Valor pago').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`pc:timeclock:notpaid:${next.id}`).setLabel('Não pagamento').setStyle(ButtonStyle.Danger)
    );
    const sent = await channel.send({ embeds: [embed], components: [row], allowedMentions: { parse: [] } }).catch(() => null);
    if (sent) {
      await upsertRecord({ ...next, log_channel_id: channel.id, log_message_id: sent.id });
    }
  }

  return next;
}

async function handleTimeclockButton(client, interaction) {
  if (interaction.customId === 'pc:timeclock:punch') {
    const db = getLocalDb();
    const open = findOpenByUser(db, interaction.guildId, interaction.user.id);
    if (open) {
      const embed = buildUserStatusEmbed(open);
      return await interaction.reply({ embeds: [embed], components: buildUserControls(true), flags: MessageFlags.Ephemeral });
    }

    const modal = new ModalBuilder().setCustomId('pc:timeclock:punchModal').setTitle('Bater Ponto');
    const reason = new TextInputBuilder()
      .setCustomId('reason')
      .setLabel('Motivo do ponto (investigação/serviço)')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(600);
    modal.addComponents(new ActionRowBuilder().addComponents(reason));
    return await interaction.showModal(modal);
  }

  if (interaction.customId === 'pc:timeclock:close') {
    const db = getLocalDb();
    const open = findOpenByUser(db, interaction.guildId, interaction.user.id);
    if (!open) {
      return await interaction.reply({
        content: 'Você não tem ponto aberto.',
        components: buildUserControls(false),
        flags: MessageFlags.Ephemeral
      });
    }

    const modal = new ModalBuilder().setCustomId(`pc:timeclock:closeModal:${open.id}`).setTitle('Fechar Serviço');
    const summary = new TextInputBuilder()
      .setCustomId('summary')
      .setLabel('Resumo do trabalho feito')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1200);
    modal.addComponents(new ActionRowBuilder().addComponents(summary));
    return await interaction.showModal(modal);
  }

  if (interaction.customId.startsWith('pc:timeclock:paid:')) {
    if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
      return await interaction.reply({ content: 'Apenas administradores podem marcar pagamento.', flags: MessageFlags.Ephemeral });
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const recordId = extractRecordId(interaction.customId, 'pc:timeclock:paid:');
    if (!recordId) return await interaction.editReply('Registro inválido.');
    const db = getLocalDb();
    const store = ensureStore(db);
    const record = store[String(recordId)] ?? null;
    if (!record) return await interaction.editReply('Registro não encontrado.');

    const updated = await markPayment(recordId, {
      payment_status: 'PAID',
      payment_by: interaction.user.id,
      payment_at: new Date().toISOString(),
      payment_reason: null
    });

    if (interaction.message?.editable && updated) {
      const { embed, amount } = buildLogEmbed(updated);
      await interaction.message.edit({ embeds: [embed], components: [] }).catch(() => {});
      await safeDmUser(
        client,
        updated.user_id,
        `Pagamento confirmado.\nVocê recebeu **${money(amount)} reais** pelo serviço de investigação.\nRegistro: ${interaction.message.url}`
      );
    }

    return await interaction.editReply('Pagamento marcado como PAGO e usuário notificado na DM.');
  }

  if (interaction.customId.startsWith('pc:timeclock:notpaid:')) {
    if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
      return await interaction.reply({ content: 'Apenas administradores podem marcar não pagamento.', flags: MessageFlags.Ephemeral });
    }

    const recordId = extractRecordId(interaction.customId, 'pc:timeclock:notpaid:');
    if (!recordId) return await interaction.reply({ content: 'Registro inválido.', flags: MessageFlags.Ephemeral });
    client.pendingTimeclockDeny = client.pendingTimeclockDeny || new Map();
    client.pendingTimeclockDeny.set(String(recordId), {
      channelId: interaction.channelId,
      messageId: interaction.message?.id || null
    });

    const modal = new ModalBuilder().setCustomId(`pc:timeclock:notpaidModal:${recordId}`).setTitle('Não Pagamento');
    const reason = new TextInputBuilder()
      .setCustomId('reason')
      .setLabel('Motivo do não pagamento')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(900);
    modal.addComponents(new ActionRowBuilder().addComponents(reason));
    return await interaction.showModal(modal);
  }
}

async function handleTimeclockModal(client, interaction) {
  if (interaction.customId === 'pc:timeclock:punchModal') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const db = getLocalDb();
    const open = findOpenByUser(db, interaction.guildId, interaction.user.id);
    if (open) {
      const embed = buildUserStatusEmbed(open);
      return await interaction.editReply({ embeds: [embed], components: buildUserControls(true) });
    }

    const id = `${interaction.guildId}:${interaction.user.id}:${nowMs()}`;
    const openedAt = new Date().toISOString();
    const reason = interaction.fields.getTextInputValue('reason').trim();

    const record = {
      id,
      guild_id: interaction.guildId,
      user_id: interaction.user.id,
      status: 'OPEN',
      opened_at: openedAt,
      open_reason: reason,
      close_summary: null,
      closed_at: null,
      total_blocks: 0,
      total_amount: 0,
      last_block_count: 0,
      last_reward_at: null,
      log_channel_id: null,
      log_message_id: null,
      payment_status: 'PENDING',
      payment_by: null,
      payment_at: null,
      payment_reason: null
    };

    await upsertRecord(record);
    await safeDmUser(client, interaction.user.id, `Ponto aberto com sucesso.\nMotivo: ${reason}`);

    const embed = buildUserStatusEmbed(record);
    return await interaction.editReply({ content: 'Ponto batido com sucesso.', embeds: [embed], components: buildUserControls(true) });
  }

  if (interaction.customId.startsWith('pc:timeclock:closeModal:')) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const recordId = extractRecordId(interaction.customId, 'pc:timeclock:closeModal:');
    if (!recordId) return await interaction.editReply('Registro inválido.');
    const db = getLocalDb();
    const store = ensureStore(db);
    const record = store[String(recordId)] ?? null;
    if (!record) return await interaction.editReply('Registro não encontrado.');
    if (String(record.user_id) !== String(interaction.user.id)) {
      return await interaction.editReply('Apenas o autor pode fechar o próprio ponto.');
    }
    if (String(record.status) !== 'OPEN') return await interaction.editReply('Esse ponto já está fechado.');

    const summary = interaction.fields.getTextInputValue('summary').trim();
    const closed = await closeAndLog(client, record, {
      closedAtIso: new Date().toISOString(),
      status: 'CLOSED',
      closeSummary: summary
    });

    await safeDmUser(
      client,
      closed.user_id,
      `Seu ponto foi fechado.\nTempo: ${fmtDuration(new Date(closed.closed_at).getTime() - new Date(closed.opened_at).getTime())}\nValor: ${money(
        closed.total_amount
      )} reais`
    );

    const { embed } = buildLogEmbed(closed);
    return await interaction.editReply({ content: 'Ponto fechado e enviado para o canal de pagamento.', embeds: [embed] });
  }

  if (interaction.customId.startsWith('pc:timeclock:notpaidModal:')) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) {
      return await interaction.editReply('Apenas administradores podem marcar não pagamento.');
    }

    const recordId = extractRecordId(interaction.customId, 'pc:timeclock:notpaidModal:');
    if (!recordId) return await interaction.editReply('Registro inválido.');
    const reason = interaction.fields.getTextInputValue('reason').trim();

    const db = getLocalDb();
    const store = ensureStore(db);
    const record = store[String(recordId)] ?? null;
    if (!record) return await interaction.editReply('Registro não encontrado.');

    const updated = await markPayment(recordId, {
      payment_status: 'NOT_PAID',
      payment_by: interaction.user.id,
      payment_at: new Date().toISOString(),
      payment_reason: reason
    });

    const pending = client.pendingTimeclockDeny?.get(String(recordId)) ?? null;
    client.pendingTimeclockDeny?.delete(String(recordId));

    if (pending?.channelId && pending?.messageId) {
      const ch = interaction.guild.channels.cache.get(String(pending.channelId)) || null;
      const msg = ch && ch.type === ChannelType.GuildText ? await ch.messages.fetch(String(pending.messageId)).catch(() => null) : null;
      if (msg && msg.editable && updated) {
        const { embed } = buildLogEmbed(updated);
        await msg.edit({ embeds: [embed], components: [] }).catch(() => {});
      }
    }

    await safeDmUser(
      client,
      updated?.user_id || record.user_id,
      `Pagamento NÃO aprovado.\nMotivo: ${reason}\nRegistro: ${pending?.messageId ? `https://discord.com/channels/${interaction.guildId}/${pending.channelId}/${pending.messageId}` : '—'}`
    );

    return await interaction.editReply('Não pagamento registrado e usuário notificado na DM.');
  }
}

async function tickTimeclocks(client) {
  const db = getLocalDb();
  const store = ensureStore(db);
  const open = Object.values(store).filter((r) => r && String(r.status) === 'OPEN');
  if (!open.length) return;

  const now = nowMs();

  for (const r of open) {
    const openedAtMs = new Date(r.opened_at).getTime();
    if (!Number.isFinite(openedAtMs)) continue;

    const elapsedMs = now - openedAtMs;
    const elapsedMin = minutes(elapsedMs);

    if (elapsedMin >= AUTO_CLOSE_MINUTES) {
      const closed = await closeAndLog(client, r, {
        closedAtIso: new Date().toISOString(),
        status: 'AUTO_CLOSED',
        closeSummary: r.close_summary || 'Fechado automaticamente após 3h.'
      });

      await safeDmUser(
        client,
        closed.user_id,
        `Seu ponto foi encerrado automaticamente após ${AUTO_CLOSE_MINUTES / 60}h.\nValor: ${money(closed.total_amount)} reais`
      );
      continue;
    }

    const currentBlocks = blocks(elapsedMs);
    const lastBlocks = Number(r.last_block_count || 0);
    if (currentBlocks > lastBlocks) {
      const gained = (currentBlocks - lastBlocks) * BLOCK_VALUE;
      const next = {
        ...r,
        last_block_count: currentBlocks,
        total_blocks: currentBlocks,
        total_amount: currentBlocks * BLOCK_VALUE,
        last_reward_at: new Date().toISOString()
      };
      await upsertRecord(next);
      await safeDmUser(
        client,
        next.user_id,
        `Ponto em andamento: ${fmtDuration(elapsedMs)}.\nBlocos (${BLOCK_MINUTES}min): ${currentBlocks}\nVocê ganhou **${money(
          gained
        )} reais**.\nTotal acumulado: **${money(next.total_amount)} reais**.`
      );
    }
  }
}

function startTimeclockScheduler(client) {
  if (client.timeclockInterval) return;
  client.timeclockInterval = setInterval(() => {
    tickTimeclocks(client).catch((err) => logger.error({ err }, 'Falha no scheduler de timeclock'));
  }, 60 * 1000);
}

module.exports = {
  TIME_CLOCK_PANEL_CHANNEL_ID,
  TIME_CLOCK_LOG_CHANNEL_ID,
  buildPanelMessage,
  handleTimeclockButton,
  handleTimeclockModal,
  startTimeclockScheduler
};
