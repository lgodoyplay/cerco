const { ensurePanels } = require('../modules/setup/panels');
const { startTimeclockScheduler } = require('../modules/timeclock/timeclockFlow');
const { logger } = require('../lib/logger');

async function startup(client) {
  logger.info({ user: client.user?.tag }, 'Bot online');

  client.commandIds = new Map();

  await client.application?.fetch?.().catch(() => {});

  const global = await client.application?.commands.fetch().catch(() => null);
  if (global) {
    for (const cmd of global.values()) {
      if (cmd?.name && cmd?.id) client.commandIds.set(String(cmd.name), String(cmd.id));
    }
  }

  for (const guild of client.guilds.cache.values()) {
    try {
      const { getOrCreateGuildConfig } = require('../services/guildConfig');
      const config = await getOrCreateGuildConfig(guild.id);
      await ensurePanels(client, guild, config, { clearBeforeSend: true, forceResend: true });

      const guildCmds = await guild.commands.fetch().catch(() => null);
      if (guildCmds) {
        for (const cmd of guildCmds.values()) {
          if (cmd?.name && cmd?.id) client.commandIds.set(String(cmd.name), String(cmd.id));
        }
      }
    } catch (err) {
      logger.error({ err, guildId: guild.id }, 'Falha ao garantir painéis');
    }
  }

  startTimeclockScheduler(client);
}

module.exports = { startup };
