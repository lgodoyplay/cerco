const { logger } = require('../lib/logger');
const { getLocalDb, withWrite } = require('../database/localDb');

const BLOCK_MINUTES = 40;
const BLOCK_VALUE = 20000;
const AUTO_CLOSE_MINUTES = 180;
const TIME_CLOCK_LOG_CHANNEL_ID = '1511172809819160636';

function nowMs() {
  return Date.now();
}

function minutes(ms) {
  return Math.floor(ms / (60 * 1000));
}

function blocks(ms) {
  return Math.floor(ms / (BLOCK_MINUTES * 60 * 1000));
}

function money(value) {
  try {
    return Number(value || 0).toLocaleString('pt-BR');
  } catch {
    return String(value || 0);
  }
}

function fmtDuration(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function ensureStore(db) {
  if (!db.timeclocks || typeof db.timeclocks !== 'object') db.timeclocks = {};
  return db.timeclocks;
}

function findOpenByUser(db, guildId, userId) {
  const store = ensureStore(db);
  for (const r of Object.values(store)) {
    if (!r) continue;
    if (String(r.guild_id) !== String(guildId)) continue;
    if (String(r.user_id) !== String(userId)) continue;
    if (String(r.status) === 'OPEN') return r;
  }
  return null;
}

async function upsertRecord(record) {
  await withWrite(async (d) => {
    const store = ensureStore(d);
    store[String(record.id)] = record;
  });
}

async function markPayment(recordId, patch) {
  const id = String(recordId);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d);
    const current = store[id] ?? null;
    if (!current) return;
    updated = { ...current, ...patch };
    store[id] = updated;
  });
  return updated;
}

async function safeDmUser(client, userId, content) {
  try {
    const u = await client.users.fetch(String(userId));
    await u.send(String(content)).catch(() => {});
  } catch {}
}

async function closeAndLog(client, record, { closedAtIso, status, closeSummary }) {
  const closedAt = closedAtIso || new Date().toISOString();
  const next = {
    ...record,
    status,
    closed_at: closedAt,
    close_summary: closeSummary || record.close_summary || null
  };

  const openedAt = new Date(next.opened_at);
  const elapsedMs = new Date(closedAt).getTime() - openedAt.getTime();
  const totalBlocks = blocks(elapsedMs);
  next.total_blocks = totalBlocks;
  next.total_amount = totalBlocks * BLOCK_VALUE;

  await upsertRecord(next);

  const guild = client.guilds.cache.get(String(next.guild_id)) || null;
  const channel = guild?.channels?.cache?.get(TIME_CLOCK_LOG_CHANNEL_ID) || null;
  if (channel && channel.type === 0) {
    const { embed } = buildLogEmbed(next);
    const { ActionRowBuilder, ButtonBuilder } = require('discord.js');
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`pc:timeclock:paid:${next.id}`).setLabel('Valor pago').setStyle(5),
      new ButtonBuilder().setCustomId(`pc:timeclock:notpaid:${next.id}`).setLabel('Não pagamento').setStyle(4)
    );
    const sent = await channel.send({ embeds: [embed], components: [row], allowedMentions: { parse: [] } }).catch(() => null);
    if (sent) {
      await upsertRecord({ ...next, log_channel_id: channel.id, log_message_id: sent.id });
    }
  }

  return next;
}

function buildLogEmbed(record) {
  const openedAt = new Date(record.opened_at);
  const closedAt = record.closed_at ? new Date(record.closed_at) : null;
  const elapsedMs = (closedAt ? closedAt.getTime() : nowMs()) - openedAt.getTime();
  const totalBlocks = blocks(elapsedMs);
  const amount = totalBlocks * BLOCK_VALUE;

  const { EmbedBuilder } = require('discord.js');
  const embed = new EmbedBuilder()
    .setColor(0x2b2d31)
    .setTitle('Fechamento de Ponto (Investigação)')
    .setDescription(`Oficial: <@${record.user_id}>`);

  embed.addFields(
    { name: '🟢 Início', value: `<t:${Math.floor(openedAt.getTime() / 1000)}:F>`, inline: true },
    { name: '🔴 Fim', value: closedAt ? `<t:${Math.floor(closedAt.getTime() / 1000)}:F>` : '—', inline: true },
    { name: '⏱️ Tempo', value: fmtDuration(elapsedMs), inline: true }
  );

  embed.addFields(
    { name: '📋 Motivo do ponto', value: record.open_reason || '—', inline: false },
    { name: '📝 Resumo do trabalho', value: record.close_summary || '—', inline: false }
  );

  embed.addFields(
    { name: `📊 Blocos (${BLOCK_MINUTES}min)`, value: String(totalBlocks), inline: true },
    { name: '💰 Valor a receber', value: `${money(amount)} reais`, inline: true },
    { name: '📌 Status', value: String(record.status || '—'), inline: true }
  );

  if (record.payment_status && record.payment_status !== 'PENDING') {
    embed.addFields({
      name: '✅ Pagamento',
      value:
        `Status: **${record.payment_status}**
` +
        (record.payment_by ? `Responsável: <@${record.payment_by}>
` : '') +
        (record.payment_at ? `Data: <t:${Math.floor(new Date(record.payment_at).getTime() / 1000)}:F>
` : '') +
        (record.payment_reason ? `Motivo: ${record.payment_reason}` : ''),
      inline: false
    });
  }

  return { embed, amount, totalBlocks, elapsedMs };
}

async function tickTimeclocks(client) {
  const db = getLocalDb();
  const store = ensureStore(db);
  const open = Object.values(store).filter((r) => r && String(r.status) === 'OPEN');
  if (!open.length) return;

  const now = nowMs();

  for (const r of open) {
    const openedAtMs = new Date(r.opened_at).getTime();
    if (!Number.isFinite(openedAtMs)) continue;

    const elapsedMs = now - openedAtMs;
    const elapsedMin = minutes(elapsedMs);

    if (elapsedMin >= AUTO_CLOSE_MINUTES) {
      const closed = await closeAndLog(client, r, {
        closedAtIso: new Date().toISOString(),
        status: 'AUTO_CLOSED',
        closeSummary: r.close_summary || 'Fechado automaticamente após 3h.'
      });

      await safeDmUser(
        client,
        closed.user_id,
        `Seu ponto foi encerrado automaticamente após ${AUTO_CLOSE_MINUTES / 60}h.\nValor: ${money(closed.total_amount)} reais`
      );
      continue;
    }

    const currentBlocks = blocks(elapsedMs);
    const lastBlocks = Number(r.last_block_count || 0);
    if (currentBlocks > lastBlocks) {
      const gained = (currentBlocks - lastBlocks) * BLOCK_VALUE;
      const next = {
        ...r,
        last_block_count: currentBlocks,
        total_blocks: currentBlocks,
        total_amount: currentBlocks * BLOCK_VALUE,
        last_reward_at: new Date().toISOString()
      };
      await upsertRecord(next);
      await safeDmUser(
        client,
        next.user_id,
        `Ponto em andamento: ${fmtDuration(elapsedMs)}.\nBlocos (${BLOCK_MINUTES}min): ${currentBlocks}\nVocê ganhou **${money(gained)} reais**.\nTotal acumulado: **${money(next.total_amount)} reais**.`
      );
    }
  }
}

function startTimeclockScheduler(client) {
  if (client.timeclockInterval) return;
  client.timeclockInterval = setInterval(() => {
    tickTimeclocks(client).catch((err) => logger.error({ err }, 'Falha no scheduler de timeclock'));
  }, 60 * 1000);
}

module.exports = { startTimeclockScheduler, tickTimeclocks };
