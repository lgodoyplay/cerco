const { buildClient } = require('../app/client');
const { connectDatabase } = require('../database/supabaseClient');
const { logger } = require('../lib/logger');

async function bootstrap() {
  if (!process.env.DISCORD_TOKEN) throw new Error('DISCORD_TOKEN não configurado no .env');

  await connectDatabase();

  const client = await buildClient();

  process.on('unhandledRejection', (reason) => {
    logger.error({ err: reason }, 'Unhandled Rejection');
  });
  process.on('uncaughtException', (err) => {
    logger.error({ err }, 'Uncaught Exception');
  });
  process.on('warning', (warning) => {
    logger.warn({ warning }, 'Process Warning');
  });

  await client.login(process.env.DISCORD_TOKEN);
}

module.exports = { bootstrap };