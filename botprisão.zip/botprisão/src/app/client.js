const { Client, Collection, GatewayIntentBits, Partials } = require('discord.js');
const { loadCommands } = require('../lib/handlers/commands');
const { registerEvents } = require('../lib/handlers/events');
const { registerInteractionRouter } = require('../lib/handlers/interactions');
const { logger } = require('../lib/logger');

function getIntentSettings(env = process.env) {
  const enableMembers = String(env.ENABLE_GUILD_MEMBERS_INTENT ?? 'true').toLowerCase() === 'true';
  const enableMessageContent = String(env.ENABLE_MESSAGE_CONTENT_INTENT ?? 'true').toLowerCase() === 'true';
  return { enableMembers, enableMessageContent };
}

async function buildClient() {
  const { enableMembers, enableMessageContent } = getIntentSettings();
  const intents = [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages];

  if (enableMembers) intents.push(GatewayIntentBits.GuildMembers);
  if (enableMessageContent) intents.push(GatewayIntentBits.MessageContent);

  if (!enableMembers) {
    logger.warn('ENABLE_GUILD_MEMBERS_INTENT=false: auto-cargo, nickname e verificação podem não funcionar corretamente.');
  }
  if (!enableMessageContent) {
    logger.warn('ENABLE_MESSAGE_CONTENT_INTENT=false: transcrição de tickets pode ficar sem conteúdo.');
  }

  const client = new Client({
    intents,
    partials: [Partials.Channel, Partials.Message, Partials.GuildMember],
    allowedMentions: { parse: [], repliedUser: false }
  });

  client.commands = new Collection();
  client.cooldowns = new Collection();

  await loadCommands(client);
  registerEvents(client);
  registerInteractionRouter(client);

  return client;
}

module.exports = { buildClient, getIntentSettings };