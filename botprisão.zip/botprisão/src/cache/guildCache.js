class GuildCache {
  constructor() {
    this.cache = new Map();
  }

  get(guildId) {
    return this.cache.get(String(guildId)) ?? null;
  }

  set(guildId, config) {
    this.cache.set(String(guildId), config);
  }

  delete(guildId) {
    this.cache.delete(String(guildId));
  }

  has(guildId) {
    return this.cache.has(String(guildId));
  }

  clear() {
    this.cache.clear();
  }

  size() {
    return this.cache.size;
  }
}

const guildCache = new GuildCache();

module.exports = { GuildCache, guildCache };