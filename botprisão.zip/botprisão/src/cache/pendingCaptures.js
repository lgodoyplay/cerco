class PendingCaptures {
  constructor() {
    this.cache = new Map();
  }

  get(key) {
    return this.cache.get(String(key)) ?? null;
  }

  set(key, capture) {
    this.cache.set(String(key), capture);
  }

  delete(key) {
    this.cache.delete(String(key));
  }

  has(key) {
    return this.cache.has(String(key));
  }

  keys() {
    return [...this.cache.keys()];
  }

  clear() {
    this.cache.clear();
  }
}

const pendingCaptures = new PendingCaptures();

module.exports = { PendingCaptures, pendingCaptures };