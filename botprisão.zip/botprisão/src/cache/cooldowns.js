class CooldownCache {
  constructor() {
    this.cache = new Map();
  }

  get(userId) {
    return this.cache.get(String(userId)) ?? 0;
  }

  set(userId, expiresAt) {
    this.cache.set(String(userId), expiresAt);
  }

  delete(userId) {
    this.cache.delete(String(userId));
  }

  has(userId) {
    return this.cache.has(String(userId));
  }

  clear() {
    this.cache.clear();
  }
}

const cooldowns = new CooldownCache();

module.exports = { CooldownCache, cooldowns };