class TicketCache {
  constructor() {
    this.cache = new Map();
  }

  get(channelId) {
    return this.cache.get(String(channelId)) ?? null;
  }

  set(channelId, ticket) {
    this.cache.set(String(channelId), ticket);
  }

  delete(channelId) {
    this.cache.delete(String(channelId));
  }

  has(channelId) {
    return this.cache.has(String(channelId));
  }

  clear() {
    this.cache.clear();
  }
}

const ticketCache = new TicketCache();

module.exports = { TicketCache, ticketCache };