class InvestigationCache {
  constructor() {
    this.cache = new Map();
  }

  get(channelId) {
    return this.cache.get(String(channelId)) ?? null;
  }

  set(channelId, investigation) {
    this.cache.set(String(channelId), investigation);
  }

  delete(channelId) {
    this.cache.delete(String(channelId));
  }

  has(channelId) {
    return this.cache.has(String(channelId));
  }

  clear() {
    this.cache.clear();
  }
}

const investigationCache = new InvestigationCache();

module.exports = { InvestigationCache, investigationCache };