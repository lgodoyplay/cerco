const { logger } = require('../lib/logger');
const { getOrCreateGuildConfig } = require('../services/guildConfig');
const { ensurePanels } = require('../modules/setup/panels');
const { startTimeclockScheduler } = require('../modules/timeclock/timeclockFlow');
const { EmbedBuilder, ChannelType } = require('discord.js');

const SPAM_CHANNEL_ID = '1531081341079261455';

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    logger.info({ user: client.user?.tag }, 'Bot online');

    client.commandIds = new Map();

    await client.application?.fetch?.().catch(() => {});

    const global = await client.application?.commands.fetch().catch(() => null);
    if (global) {
      for (const cmd of global.values()) {
        if (cmd?.name && cmd?.id) client.commandIds.set(String(cmd.name), String(cmd.id));
      }
    }

    for (const guild of client.guilds.cache.values()) {
      try {
        const config = await getOrCreateGuildConfig(guild.id);
        await ensurePanels(client, guild, config, { clearBeforeSend: true, forceResend: true });

        const guildCmds = await guild.commands.fetch().catch(() => null);
        if (guildCmds) {
          for (const cmd of guildCmds.values()) {
            if (cmd?.name && cmd?.id) client.commandIds.set(String(cmd.name), String(cmd.id));
          }
        }
      } catch (err) {
        logger.error({ err, guildId: guild.id }, 'Falha ao garantir painéis');
      }
    }

    const spamChannel = client.channels.cache.get(SPAM_CHANNEL_ID);
    if (spamChannel && spamChannel.type === ChannelType.GuildText) {
      const spamEmbed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('⚠️ Canal de Spam')
        .setDescription('Este canal é exclusivo para spam. **Não é permitido enviar mensagens** neste canal.\n\nQualquer mensagem enviada aqui resultará em **expulsão** do servidor.');

      await spamChannel.send({ embeds: [spamEmbed] }).catch(() => {});
    }

    startTimeclockScheduler(client);
  }
};
