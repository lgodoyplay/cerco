const { logger } = require('../lib/logger');
const { getOrCreateGuildConfig } = require('../services/guildConfig');
const { PermissionFlagsBits } = require('discord.js');

const SPAM_CHANNEL_ID = '1531081341079261455';

module.exports = {
  name: 'messageCreate',
  async execute(client, message) {
    try {
      if (message.channel.id !== SPAM_CHANNEL_ID) return;
      if (message.author.bot) return;

      const guild = message.guild;
      if (!guild) return;

      const config = await getOrCreateGuildConfig(guild.id);
      const botMember = guild.members.me;
      const canBan = botMember && botMember.permissions.has(PermissionFlagsBits.BanMembers);

      if (canBan) {
        await message.delete().catch(() => {});
        await guild.members.ban(message.author.id, { reason: 'Enviou mensagem no canal de spam' }).catch((err) => {
          logger.error({ err, userId: message.author.id }, 'Falha ao banir usuário do canal de spam');
        });
      } else {
        logger.warn({ userId: message.author.id, guildId: guild.id }, 'Bot sem permissão de ban para canal de spam');
      }
    } catch (err) {
      logger.error({ err }, 'Erro ao processar mensagem no canal de spam');
    }
  }
};
