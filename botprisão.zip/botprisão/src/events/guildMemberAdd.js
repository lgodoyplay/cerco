const { logger } = require('../lib/logger');
const { getOrCreateGuildConfig } = require('../services/guildConfig');

module.exports = {
  name: 'guildMemberAdd',
  async execute(client, member) {
    try {
      const config = await getOrCreateGuildConfig(member.guild.id);
      const roleId = config.roles.autoRoleOnJoinId;

      if (roleId && member.guild.roles.cache.has(roleId)) {
        await member.roles.add(roleId).catch(() => {});
      }
    } catch (err) {
      logger.error({ err, guildId: member.guild.id, userId: member.user?.id }, 'Falha no auto-cargo');
    }
  }
};

