module.exports = {
  name: 'interactionCreate',
  async execute(client, interaction) {
    if (typeof client.handleInteraction !== 'function') return;
    await client.handleInteraction(interaction);
  }
};

