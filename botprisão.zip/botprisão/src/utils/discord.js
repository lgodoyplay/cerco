function buildDownloadRows(items) {
  const rows = [];
  const list = Array.isArray(items) ? items.filter((i) => i?.url) : [];
  for (let i = 0; i < list.length; i += 5) {
    const slice = list.slice(i, i + 5);
    const row = {
      components: slice.map((it) => ({
        style: 5,
        label: String(it.label || 'Arquivo').slice(0, 80),
        url: it.url
      }))
    };
    rows.push(row);
  }
  return rows.slice(0, 5);
}

module.exports = { buildDownloadRows };