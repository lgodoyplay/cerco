function minutes(ms) {
  return Math.floor(ms / (60 * 1000));
}

function hours(ms) {
  return Math.floor(ms / (60 * 60 * 1000));
}

function msUntilNextBlock(elapsedMs, blockMinutes) {
  const blockMs = blockMinutes * 60 * 1000;
  const mod = elapsedMs % blockMs;
  return blockMs - mod;
}

function nowIso() {
  return new Date().toISOString();
}

function nowTimestamp() {
  return Math.floor(Date.now() / 1000);
}

module.exports = { minutes, hours, msUntilNextBlock, nowIso, nowTimestamp };