function hasPermission(member, permission) {
  if (!member) return false;
  if (member.permissions.has(permission)) return true;
  return false;
}

function hasAnyRole(member, roleIds) {
  if (!member) return false;
  const ids = Array.isArray(roleIds) ? roleIds : [roleIds];
  return ids.some((id) => id && member.roles.cache.has(id));
}

function isAdmin(member) {
  if (!member) return false;
  return member.permissions.has('Administrator');
}

module.exports = { hasPermission, hasAnyRole, isAdmin };