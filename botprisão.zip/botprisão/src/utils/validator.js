function validateEnv(requiredVars) {
  const missing = [];
  for (const varName of requiredVars) {
    if (!process.env[varName]) {
      missing.push(varName);
    }
  }
  if (missing.length > 0) {
    throw new Error(`Variáveis de ambiente ausentes: ${missing.join(', ')}`);
  }
  return true;
}

function validateString(value, fieldName, maxLength) {
  if (typeof value !== 'string') {
    throw new TypeError(`${fieldName} deve ser uma string`);
  }
  if (maxLength && value.length > maxLength) {
    throw new RangeError(`${fieldName} excede o tamanho máximo de ${maxLength} caracteres`);
  }
  return value.trim();
}

function validateNumber(value, fieldName, min, max) {
  const num = Number(value);
  if (isNaN(num)) {
    throw new TypeError(`${fieldName} deve ser um número`);
  }
  if (min !== undefined && num < min) {
    throw new RangeError(`${fieldName} deve ser no mínimo ${min}`);
  }
  if (max !== undefined && num > max) {
    throw new RangeError(`${fieldName} deve ser no máximo ${max}`);
  }
  return num;
}

module.exports = { validateEnv, validateString, validateNumber };