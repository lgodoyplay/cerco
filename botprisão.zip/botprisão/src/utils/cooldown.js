function isOnCooldown(userId, ms, cooldownMap) {
  const now = Date.now();
  const until = cooldownMap.get(userId) ?? 0;
  if (until > now) return true;
  cooldownMap.set(userId, now + ms);
  return false;
}

function clearCooldown(userId, cooldownMap) {
  cooldownMap.delete(userId);
}

function getCooldownRemaining(userId, ms, cooldownMap) {
  const until = cooldownMap.get(userId) ?? 0;
  const now = Date.now();
  if (until <= now) return 0;
  return Math.ceil((until - now) / 1000);
}

module.exports = { isOnCooldown, clearCooldown, getCooldownRemaining };