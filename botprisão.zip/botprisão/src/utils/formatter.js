function formatNumber(num, locale = 'pt-BR') {
  try {
    return Number(num || 0).toLocaleString(locale);
  } catch {
    return String(num || 0);
  }
}

function formatDuration(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function formatTimestamp(date) {
  return `<t:${Math.floor(new Date(date).getTime() / 1000)}:F>`;
}

function truncate(text, maxLength = 1024) {
  const str = String(text || '');
  if (str.length <= maxLength) return str;
  return str.slice(0, maxLength - 3) + '...';
}

module.exports = { formatNumber, formatDuration, formatTimestamp, truncate };