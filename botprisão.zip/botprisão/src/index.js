require('dotenv').config();
const { bootstrap } = require('./app/bootstrap');

bootstrap().catch((err) => {
  const { logger } = require('./lib/logger');
  logger.error({ err }, 'Falha ao inicializar o bot');
  process.exitCode = 1;
});