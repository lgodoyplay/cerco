const { DEFAULT_GUILD_CONFIG } = require('../config/defaults');
const { getLocalDb, withWrite } = require('../database/localDb');

function mergeDeepDefaults(current, defaults) {
  const out = { ...(current || {}) };
  for (const [k, v] of Object.entries(defaults || {})) {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      out[k] = mergeDeepDefaults(out[k], v);
    } else if (out[k] === undefined) {
      out[k] = v;
    }
  }
  return out;
}

async function getOrCreateGuildConfig(guildId) {
  const db = getLocalDb();
  const existing = db.guild_configs[String(guildId)] ?? null;
  if (existing) {
    const merged = {
      guildId: String(guildId),
      roles: mergeDeepDefaults(existing.roles, DEFAULT_GUILD_CONFIG.roles),
      channels: mergeDeepDefaults(existing.channels, DEFAULT_GUILD_CONFIG.channels),
      panels: mergeDeepDefaults(existing.panels, DEFAULT_GUILD_CONFIG.panels)
    };

    const needsPersist =
      JSON.stringify(existing.roles) !== JSON.stringify(merged.roles) ||
      JSON.stringify(existing.channels) !== JSON.stringify(merged.channels) ||
      JSON.stringify(existing.panels) !== JSON.stringify(merged.panels);

    if (needsPersist) {
      await withWrite(async (d) => {
        d.guild_configs[String(guildId)] = merged;
      });
    }

    return merged;
  }

  const created = {
    guildId: String(guildId),
    roles: DEFAULT_GUILD_CONFIG.roles,
    channels: DEFAULT_GUILD_CONFIG.channels,
    panels: DEFAULT_GUILD_CONFIG.panels
  };

  await withWrite(async (d) => {
    d.guild_configs[String(guildId)] = created;
  });

  return created;
}

async function updateGuildPanels(guildId, panels) {
  const id = String(guildId);
  await getOrCreateGuildConfig(id);
  await withWrite(async (d) => {
    const current = d.guild_configs[id];
    d.guild_configs[id] = { ...current, panels };
  });
}

async function setGuildConfig(guildId, update) {
  const id = String(guildId);
  await getOrCreateGuildConfig(id);

  let merged = null;
  await withWrite(async (d) => {
    const current = d.guild_configs[id];
    merged = {
      guildId: id,
      roles: update.roles ?? current.roles,
      channels: update.channels ?? current.channels,
      panels: update.panels ?? current.panels
    };
    d.guild_configs[id] = merged;
  });

  return merged;
}

module.exports = { getOrCreateGuildConfig, setGuildConfig, updateGuildPanels };
