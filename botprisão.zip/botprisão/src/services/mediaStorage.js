function safeFileName(name) {
  return String(name || 'arquivo')
    .replace(/[^\w.\-() ]+/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 120);
}

function guessContentGroup(contentType, fileName) {
  const ct = String(contentType || '').toLowerCase();
  if (ct.startsWith('image/')) return 'image';
  if (ct.startsWith('video/')) return 'video';
  if (ct.startsWith('audio/')) return 'audio';
  if (ct.includes('pdf')) return 'pdf';
  const n = String(fileName || '').toLowerCase();
  if (n.endsWith('.png') || n.endsWith('.jpg') || n.endsWith('.jpeg') || n.endsWith('.gif') || n.endsWith('.webp')) return 'image';
  if (n.endsWith('.mp4') || n.endsWith('.webm') || n.endsWith('.mov')) return 'video';
  if (n.endsWith('.mp3') || n.endsWith('.wav')) return 'audio';
  if (n.endsWith('.pdf')) return 'pdf';
  return 'other';
}

function assertAllowedUpload({ contentType, fileName }) {
  const group = guessContentGroup(contentType, fileName);
  if (group === 'image' || group === 'video' || group === 'audio' || group === 'pdf') return;
  throw new Error('UNSUPPORTED_MEDIA_TYPE');
}

async function uploadDiscordAttachment({ kind, guildId, userId, recordId, attachment, tag }) {
  assertAllowedUpload({ contentType: attachment?.contentType, fileName: attachment?.name });
  const url = attachment?.url ? String(attachment.url) : '';
  if (!url) throw new Error('ATTACHMENT_INVALID');
  const name = attachment?.name ? String(attachment.name) : safeFileName(tag || 'arquivo');
  const contentType = attachment?.contentType || 'application/octet-stream';

  return {
    url,
    path: null,
    bucket: 'discord',
    name,
    contentType,
    size: attachment?.size ?? null
  };
}

module.exports = { uploadDiscordAttachment, assertAllowedUpload, guessContentGroup };
