const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, MessageFlags } = require('discord.js');
const { BRAND } = require('../config/constants');
const { baseEmbed } = require('../core/embeds/baseEmbed');
const { logger } = require('../lib/logger');
const { getOrCreateGuildConfig } = require('../services/guildConfig');
const { uploadDiscordAttachment, guessContentGroup } = require('../services/mediaStorage');
const { createWantedRecord, updateWantedRecord } = require('../database/repositories/wantedRepository');

function normalizeUrl(url) {
  return String(url || '').trim();
}

function isImageAttachment(att) {
  return guessContentGroup(att?.contentType, att?.name) === 'image';
}

function buildDownloadRows(items) {
  const rows = [];
  const list = Array.isArray(items) ? items.filter((i) => i?.url) : [];
  for (let i = 0; i < list.length; i += 5) {
    const slice = list.slice(i, i + 5);
    const row = new ActionRowBuilder().addComponents(
      ...slice.map((it) => new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel(it.label).setURL(it.url))
    );
    rows.push(row);
  }
  return rows.slice(0, 5);
}

function canUseWanted(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  const allowed = new Set([config.roles?.corpRoleId, config.roles?.integration?.policeRoleId, ...(config.roles?.policeRoleIds ?? [])]);
  return [...allowed].some((roleId) => roleId && member.roles.cache.has(roleId));
}

function makeImageEmbed({ title, description, url }) {
  const e = baseEmbed({ title, description, color: BRAND.colors.GRAY_DARK });
  e.setImage(normalizeUrl(url));
  return e;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('procurado')
    .setDescription('Registra um procurado com uploads nativos do Discord.')
    .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages)
    .addStringOption((o) => o.setName('nome').setDescription('Nome do procurado').setRequired(true).setMaxLength(50))
    .addStringOption((o) => o.setName('passaporte').setDescription('Passaporte do procurado').setRequired(true).setMaxLength(20))
    .addStringOption((o) => o.setName('motivo').setDescription('Motivo').setRequired(true).setMaxLength(900))
    .addStringOption((o) => o.setName('risco').setDescription('Nível de risco').setRequired(true).setMaxLength(30))
    .addAttachmentOption((o) => o.setName('foto_suspeito').setDescription('Foto principal do suspeito (obrigatória)').setRequired(true))
    .addAttachmentOption((o) => o.setName('prova_1').setDescription('Prova 1 (obrigatória)').setRequired(true))
    .addStringOption((o) => o.setName('local').setDescription('Última localização (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('organizacao').setDescription('Organização/Facção (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('observacoes').setDescription('Observações (opcional)').setRequired(false).setMaxLength(900))
    .addAttachmentOption((o) => o.setName('prova_2').setDescription('Prova 2 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('prova_3').setDescription('Prova 3 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('prova_4').setDescription('Prova 4 (opcional)').setRequired(false)),
  cooldownMs: 5000,
  async execute(client, interaction) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const config = await getOrCreateGuildConfig(interaction.guild.id);
      const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
      if (!canUseWanted(config, member)) {
        return await interaction.editReply('Você não tem permissão para registrar procurados.');
      }

      const wantedName = interaction.options.getString('nome', true).trim();
      const wantedId = interaction.options.getString('passaporte', true).trim();
      const motivo = interaction.options.getString('motivo', true).trim();
      const risco = interaction.options.getString('risco', true).trim();
      const local = interaction.options.getString('local')?.trim() || null;
      const org = interaction.options.getString('organizacao')?.trim() || null;
      const observacoes = interaction.options.getString('observacoes')?.trim() || null;

      const fotoPrincipal = interaction.options.getAttachment('foto_suspeito', true);
      const prova1 = interaction.options.getAttachment('prova_1', true);
      const prova2 = interaction.options.getAttachment('prova_2', false);
      const prova3 = interaction.options.getAttachment('prova_3', false);
      const prova4 = interaction.options.getAttachment('prova_4', false);

      const all = [fotoPrincipal, prova1, prova2, prova3, prova4].filter(Boolean);
      if (all.some((a) => !isImageAttachment(a))) {
        return await interaction.editReply('Envie apenas imagens (PNG/JPG/WEBP/GIF) nas opções de foto/provas.');
      }

      const record = await createWantedRecord({
        guildId: interaction.guild.id,
        authorId: interaction.user.id,
        wantedName,
        wantedId,
        reason: `Motivo: ${motivo}\nRisco: ${risco}`,
        links:
          [local ? `Última localização: ${local}` : null, org ? `Organização/Facção: ${org}` : null, observacoes ? `Observações: ${observacoes}` : null]
            .filter(Boolean)
            .join('\n') || null
      });

      const logChannel = interaction.guild.channels.cache.get(config.channels.wantedLogChannelId);
      if (!logChannel || logChannel.type !== ChannelType.GuildText) {
        return await interaction.editReply('Canal de logs de procurados não configurado ou inválido.');
      }

      const uFoto = await uploadDiscordAttachment({
        kind: 'procurados',
        guildId: interaction.guild.id,
        userId: interaction.user.id,
        recordId: record.id,
        attachment: fotoPrincipal,
        tag: 'foto-principal'
      });
      const uProva1 = await uploadDiscordAttachment({
        kind: 'procurados',
        guildId: interaction.guild.id,
        userId: interaction.user.id,
        recordId: record.id,
        attachment: prova1,
        tag: 'prova-1'
      });
      const uProva2 = prova2
        ? await uploadDiscordAttachment({
            kind: 'procurados',
            guildId: interaction.guild.id,
            userId: interaction.user.id,
            recordId: record.id,
            attachment: prova2,
            tag: 'prova-2'
          })
        : null;
      const uProva3 = prova3
        ? await uploadDiscordAttachment({
            kind: 'procurados',
            guildId: interaction.guild.id,
            userId: interaction.user.id,
            recordId: record.id,
            attachment: prova3,
            tag: 'prova-3'
          })
        : null;
      const uProva4 = prova4
        ? await uploadDiscordAttachment({
            kind: 'procurados',
            guildId: interaction.guild.id,
            userId: interaction.user.id,
            recordId: record.id,
            attachment: prova4,
            tag: 'prova-4'
          })
        : null;

      if (!uFoto?.url || !uProva1?.url) {
        return await interaction.editReply('Falha ao processar as mídias. Reenvie as imagens e tente novamente.');
      }

      const proofs = [
        { url: uProva1.url, name: prova1.name || 'prova-1' },
        { url: uFoto.url, name: fotoPrincipal.name || 'foto-principal' },
        uProva2?.url ? { url: uProva2.url, name: prova2?.name || 'prova-2' } : null,
        uProva3?.url ? { url: uProva3.url, name: prova3?.name || 'prova-3' } : null,
        uProva4?.url ? { url: uProva4.url, name: prova4?.name || 'prova-4' } : null
      ].filter(Boolean);
      await updateWantedRecord(record.id, { proofs }).catch(() => {});

      const embedMain = baseEmbed({
        title: '🚨 REGISTRO DE PROCURADO',
        description: 'Sistema criminal • Catálogo investigativo',
        color: BRAND.colors.GRAY_DARK
      });

      embedMain.setThumbnail(uFoto.url);
      embedMain.setImage(uProva1.url);

      embedMain.addFields(
        {
          name: '👤 INFORMAÇÕES DO PROCURADO',
          value:
            `📌 Nome: **${record.wanted_name}**\n` +
            `🆔 Passaporte: **${record.wanted_id}**\n` +
            `⚠️ Motivo: **${motivo}**\n` +
            `🚩 Nível de risco: **${risco}**\n` +
            `📍 Última localização: **${local || '—'}**\n` +
            `🏴 Organização/Facção: **${org || '—'}**\n` +
            `📝 Observações: **${observacoes || '—'}**`,
          inline: false
        },
        {
          name: '👮 RESPONSÁVEL',
          value:
            `👤 Oficial: <@${record.author_id}>\n` +
            `📅 Data/Hora: <t:${Math.floor(new Date(record.created_at).getTime() / 1000)}:F>\n` +
            `📍 Status: **ATIVO**`,
          inline: false
        }
      );

      const linksLines = [];
      if (local) linksLines.push(`📍 Última localização: ${local}`);
      if (org) linksLines.push(`🏴 Organização/Facção: ${org}`);
      if (observacoes) linksLines.push(`📝 Observações: ${observacoes}`);
      if (linksLines.length) {
        embedMain.addFields({ name: '🔗 Informações', value: linksLines.join('\n'), inline: false });
      }

      const embeds = [embedMain];

      const captureRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`pc:wanted:captured:${record.id}`).setLabel('JÁ FOI PRESO').setStyle(ButtonStyle.Danger)
      );

      const downloadRows = buildDownloadRows([
        uProva2?.url ? { label: 'Baixar Prova 2', url: uProva2.url } : null,
        uProva3?.url ? { label: 'Baixar Prova 3', url: uProva3.url } : null
      ]);

      const sent = await logChannel
        .send({ embeds, components: [captureRow, ...downloadRows], allowedMentions: { parse: [] } })
        .catch(() => null);
      if (!sent) return await interaction.editReply('Procurado registrado, mas falhou ao enviar as embeds no canal de logs.');
      return await interaction.editReply(`Procurado registrado com sucesso: ${sent.url}`);
    } catch (err) {
      const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      logger.error(
        {
          err,
          command: 'procurado',
          guildId: interaction.guild?.id || null,
          userId: interaction.user?.id || null,
          errorId
        },
        'Falha no /procurado'
      );
      const msg = String(err?.message || '').toLowerCase();
      if (String(err?.message || '') === 'UNSUPPORTED_MEDIA_TYPE') {
        return await interaction.editReply(
          `Tipo de arquivo não suportado. Envie apenas imagens/vídeos/áudios/PDFs. (erro: ${errorId})`
        );
      }
      if (msg.includes('attachment_invalid')) {
        return await interaction.editReply(`Anexo inválido. Reenvie as imagens e tente novamente. (erro: ${errorId})`);
      }
      return await interaction.editReply(`Falha ao registrar o procurado. (erro: ${errorId})`);
    }
  }
};
