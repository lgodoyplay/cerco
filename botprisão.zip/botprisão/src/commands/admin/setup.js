const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { getOrCreateGuildConfig, setGuildConfig } = require('../../services/guildConfig');
const { ensurePanels } = require('../../modules/setup/panels');
const { DEFAULT_GUILD_CONFIG } = require('../../config/defaults');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Configura e inicializa os painéis do sistema no servidor.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addBooleanOption((opt) =>
      opt.setName('resetar_paineis').setDescription('Reenvia os painéis mesmo se já existirem.').setRequired(false)
    )
    .addBooleanOption((opt) =>
      opt
        .setName('limpar_canais')
        .setDescription('Limpa os canais dos painéis antes de enviar as embeds novamente.')
        .setRequired(false)
    ),
  cooldownMs: 5000,
  async execute(client, interaction) {
    const resetPanels = interaction.options.getBoolean('resetar_paineis') ?? false;
    const clearChannels = interaction.options.getBoolean('limpar_canais') ?? false;

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const config = await getOrCreateGuildConfig(interaction.guild.id);

    if (!config.roles || !config.channels) {
      await setGuildConfig(interaction.guild.id, {
        roles: DEFAULT_GUILD_CONFIG.roles,
        channels: DEFAULT_GUILD_CONFIG.channels,
        panels: DEFAULT_GUILD_CONFIG.panels
      });
    }

    const nextConfig = await getOrCreateGuildConfig(interaction.guild.id);

    if (resetPanels) {
      await setGuildConfig(interaction.guild.id, {
        panels: {
          verificationMessageId: null,
          investigationMessageId: null,
          boMessageId: null,
          prisonMessageId: null,
          wantedMessageId: null,
          coursesMessageId: null,
          noticesMessageId: null,
          exonerationMessageId: null,
          corregedoriaMessageId: null
        }
      });
    }

    const refreshed = await getOrCreateGuildConfig(interaction.guild.id);
    await ensurePanels(client, interaction.guild, refreshed, { clearBeforeSend: clearChannels, forceResend: resetPanels || clearChannels });

    await interaction.editReply('Setup concluído. Painéis iniciais garantidos nos canais configurados.');
  }
};
