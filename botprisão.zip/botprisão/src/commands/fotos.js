const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, MessageFlags } = require('discord.js');
const { BRAND } = require('../config/constants');
const { baseEmbed } = require('../core/embeds/baseEmbed');
const { logger } = require('../lib/logger');
const { getOrCreateGuildConfig } = require('../services/guildConfig');
const { uploadDiscordAttachment, guessContentGroup } = require('../services/mediaStorage');
const { getOpenInvestigationByChannel, createInvestigation, createEvidence, updateEvidence, updateInvestigation } = require('../database/repositories/investigationRepository');

function normalizeUrl(url) {
  return String(url || '').trim();
}

function cleanLabel(text) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  return s.length > 80 ? s.slice(0, 80) : s;
}

function buildDownloadRows(items) {
  const rows = [];
  const list = Array.isArray(items) ? items.filter((i) => i?.url) : [];
  for (let i = 0; i < list.length; i += 5) {
    const slice = list.slice(i, i + 5);
    const row = new ActionRowBuilder().addComponents(
      ...slice.map((it) => new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel(String(it.label || 'Arquivo').slice(0, 80)).setURL(it.url))
    );
    rows.push(row);
  }
  return rows.slice(0, 5);
}

function makeImageEmbed({ title, description, url }) {
  const e = baseEmbed({ title, description, color: BRAND.colors.GRAY_DARK });
  e.setImage(normalizeUrl(url));
  return e;
}

function canUseInvestigations({ config, member, memberPermissions }) {
  if (memberPermissions?.has?.(PermissionFlagsBits.Administrator)) return true;
  const roleId = config.roles?.investigativeRoleId;
  return Boolean(roleId && member?.roles?.cache?.has?.(roleId));
}

function isImage(att) {
  return guessContentGroup(att?.contentType, att?.name) === 'image';
}

function isVideo(att) {
  return guessContentGroup(att?.contentType, att?.name) === 'video';
}

function isAudio(att) {
  return guessContentGroup(att?.contentType, att?.name) === 'audio';
}

function firstImageUrl(list) {
  const first = Array.isArray(list) ? list.find((a) => isImage(a)) : null;
  return first?.url ? normalizeUrl(first.url) : null;
}

function defaultBaseTitle(category) {
  if (category === 'bau') return 'BAÚ — localização do baú';
  if (category === 'armados') return 'ARMADOS — pessoas armadas';
  if (category === 'rosto00') return 'ROSTO 00';
  if (category === 'rosto01') return 'ROSTO 01';
  if (category === 'rosto02') return 'ROSTO 02';
  if (category === 'gerente') return 'GERENTE';
  if (category === 'gerente2') return 'GERENTE 2';
  if (category === 'mapa') return 'MAPA — localização';
  if (category === 'outra') return 'OUTRA PROVA';
  return 'Mídias da investigação';
}

function defaultItemLabel({ category, group, index }) {
  const base = defaultBaseTitle(category);
  const idx = Number(index) || 1;
  if (group === 'image') return cleanLabel(`${base} • Foto ${idx}`);
  if (group === 'video') return cleanLabel(`${base} • Vídeo ${idx}`);
  if (group === 'audio') return cleanLabel(`${base} • Gravação ${idx}`);
  return cleanLabel(`${base} • Arquivo ${idx}`);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('fotos')
    .setDescription('Envia mídias (fotos/vídeos/gravações) para a investigação aberta neste canal.')
    .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages)
    .addAttachmentOption((o) => o.setName('foto_1').setDescription('Foto 1 (obrigatória)').setRequired(true))
    .addAttachmentOption((o) => o.setName('foto_2').setDescription('Foto 2 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('foto_3').setDescription('Foto 3 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('foto_4').setDescription('Foto 4 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('foto_5').setDescription('Foto 5 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('video_1').setDescription('Vídeo 1 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('video_2').setDescription('Vídeo 2 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('gravacao_1').setDescription('Gravação 1 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('gravacao_2').setDescription('Gravação 2 (opcional)').setRequired(false))
    .addStringOption((o) =>
      o
        .setName('categoria')
        .setDescription('Categoria (para checklist de encerramento)')
        .setRequired(false)
        .addChoices(
          { name: 'BAÚ (localização)', value: 'bau' },
          { name: 'ARMADOS (facção)', value: 'armados' },
          { name: 'ROSTO 00', value: 'rosto00' },
          { name: 'ROSTO 01', value: 'rosto01' },
          { name: 'ROSTO 02 (opcional)', value: 'rosto02' },
          { name: 'GERENTE', value: 'gerente' },
          { name: 'GERENTE 2 (opcional)', value: 'gerente2' },
          { name: 'MAPA (localização)', value: 'mapa' },
          { name: 'OUTRA PROVA', value: 'outra' }
        )
    )
    .addStringOption((o) =>
      o
        .setName('nome')
        .setDescription('Título geral (opcional). Se vazio, o bot usa um nome padrão da categoria.')
        .setRequired(false)
        .setMaxLength(60)
    )
    .addStringOption((o) =>
      o
        .setName('identificacao')
        .setDescription('Nome e passaporte (use quando for ARMADOS / ROSTOS / GERENTES)')
        .setRequired(false)
        .setMaxLength(600)
    )
    .addStringOption((o) => o.setName('nome_foto_1').setDescription('Nome da foto 1 (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('nome_foto_2').setDescription('Nome da foto 2 (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('nome_foto_3').setDescription('Nome da foto 3 (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('nome_foto_4').setDescription('Nome da foto 4 (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('nome_foto_5').setDescription('Nome da foto 5 (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('nome_video_1').setDescription('Nome do vídeo 1 (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('nome_video_2').setDescription('Nome do vídeo 2 (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('nome_gravacao_1').setDescription('Nome da gravação 1 (opcional)').setRequired(false).setMaxLength(60))
    .addStringOption((o) => o.setName('nome_gravacao_2').setDescription('Nome da gravação 2 (opcional)').setRequired(false).setMaxLength(60)),
  cooldownMs: 3500,
  async execute(client, interaction) {
    const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const config = await getOrCreateGuildConfig(interaction.guild.id);
      const member = interaction.member ?? null;
      if (!canUseInvestigations({ config, member, memberPermissions: interaction.memberPermissions })) {
        return await interaction.editReply('Apenas membros do Investigativo podem usar este comando.');
      }

      const channel = interaction.channel;
      if (!channel || channel.type !== ChannelType.GuildText) {
        return await interaction.editReply('Canal inválido.');
      }

      let inv = await getOpenInvestigationByChannel(interaction.channelId);
      if (!inv) {
        inv = await createInvestigation({
          guildId: interaction.guild.id,
          channelId: interaction.channelId,
          creatorId: interaction.user.id,
          name: `Investigação • ${channel.name}`,
          reason: 'Auto-criada ao usar /fotos neste canal.'
        });
      }

      const fotos = [
        interaction.options.getAttachment('foto_1', true),
        interaction.options.getAttachment('foto_2', false),
        interaction.options.getAttachment('foto_3', false),
        interaction.options.getAttachment('foto_4', false),
        interaction.options.getAttachment('foto_5', false)
      ].filter(Boolean);

      const videos = [interaction.options.getAttachment('video_1', false), interaction.options.getAttachment('video_2', false)].filter(Boolean);
      const audios = [
        interaction.options.getAttachment('gravacao_1', false),
        interaction.options.getAttachment('gravacao_2', false)
      ].filter(Boolean);

      if (!fotos.every(isImage)) return await interaction.editReply('Envie apenas imagens (PNG/JPG/WEBP/GIF) nos campos de foto.');
      if (!videos.every(isVideo)) return await interaction.editReply('Envie apenas vídeos nos campos de vídeo.');
      if (!audios.every(isAudio)) return await interaction.editReply('Envie apenas áudios nos campos de gravação.');

      const category = interaction.options.getString('categoria', false) || null;
      const evidenceName = (interaction.options.getString('nome', false)?.trim() || defaultBaseTitle(category)).slice(0, 60);
      const identification = interaction.options.getString('identificacao', false)?.trim() || '';

      const requiresIdentity = new Set(['armados', 'rosto00', 'rosto01', 'rosto02', 'gerente', 'gerente2']);
      if (category && requiresIdentity.has(category) && !identification) {
        return await interaction.editReply('Para essa categoria, informe também **identificacao** (Nome e Passaporte).');
      }

      const limits = {
        bau: 3,
        armados: 4,
        rosto00: 1,
        rosto01: 1,
        rosto02: 1,
        gerente: 1,
        gerente2: 1,
        mapa: 1
      };

      const maxPhotos = category && limits[category] ? limits[category] : null;
      if (maxPhotos && fotos.length > maxPhotos) {
        return await interaction.editReply(`Para essa categoria, envie no máximo **${maxPhotos}** foto(s).`);
      }

      const nameFoto = [
        interaction.options.getString('nome_foto_1', false),
        interaction.options.getString('nome_foto_2', false),
        interaction.options.getString('nome_foto_3', false),
        interaction.options.getString('nome_foto_4', false),
        interaction.options.getString('nome_foto_5', false)
      ].map((s) => (s ? cleanLabel(s) : null));

      const nameVideo = [
        interaction.options.getString('nome_video_1', false),
        interaction.options.getString('nome_video_2', false)
      ].map((s) => (s ? cleanLabel(s) : null));

      const nameAudio = [
        interaction.options.getString('nome_gravacao_1', false),
        interaction.options.getString('nome_gravacao_2', false)
      ].map((s) => (s ? cleanLabel(s) : null));

      const evidence = await createEvidence({
        guildId: interaction.guild.id,
        investigationId: inv.id,
        channelId: interaction.channelId,
        authorId: interaction.user.id,
        personName: inv.name || 'Investigação',
        personId: String(inv.id),
        description:
          (category ? `REQ:${category} | ` : '') +
          evidenceName +
          (identification ? `\nIdentificação:\n${identification}` : ''),
        links: null
      });

      const uploaded = [];
      for (let i = 0; i < fotos.length; i++) {
        const a = fotos[i];
        const label = nameFoto[i] || defaultItemLabel({ category, group: 'image', index: i + 1 });
        const up = await uploadDiscordAttachment({
          kind: 'investigacoes',
          guildId: interaction.guild.id,
          userId: interaction.user.id,
          recordId: evidence.id,
          attachment: a,
          tag: `foto-${i + 1}`
        });
        uploaded.push({
          url: up.url,
          name: a.name || up.name,
          label,
          contentType: up.contentType || a.contentType || null,
          size: a.size ?? null
        });
      }
      for (let i = 0; i < videos.length; i++) {
        const a = videos[i];
        const label = nameVideo[i] || defaultItemLabel({ category, group: 'video', index: i + 1 });
        const up = await uploadDiscordAttachment({
          kind: 'investigacoes',
          guildId: interaction.guild.id,
          userId: interaction.user.id,
          recordId: evidence.id,
          attachment: a,
          tag: `video-${i + 1}`
        });
        uploaded.push({
          url: up.url,
          name: a.name || up.name,
          label,
          contentType: up.contentType || a.contentType || null,
          size: a.size ?? null
        });
      }
      for (let i = 0; i < audios.length; i++) {
        const a = audios[i];
        const label = nameAudio[i] || defaultItemLabel({ category, group: 'audio', index: i + 1 });
        const up = await uploadDiscordAttachment({
          kind: 'investigacoes',
          guildId: interaction.guild.id,
          userId: interaction.user.id,
          recordId: evidence.id,
          attachment: a,
          tag: `audio-${i + 1}`
        });
        uploaded.push({
          url: up.url,
          name: a.name || up.name,
          label,
          contentType: up.contentType || a.contentType || null,
          size: a.size ?? null
        });
      }

      await updateEvidence(evidence.id, { attachments: uploaded }).catch(() => {});

      const embedMain = baseEmbed({
        title: `📎 ${evidenceName}`,
        description: `Investigação: **${inv.name || '—'}**\nAutor: <@${interaction.user.id}>`,
        color: BRAND.colors.GRAY_DARK
      });

      const preview = firstImageUrl(uploaded);
      if (preview) {
        embedMain.setThumbnail(preview);
      }

      embedMain.addFields(
        { name: '📷 Fotos', value: String(fotos.length), inline: true },
        { name: '🎥 Vídeos', value: String(videos.length), inline: true },
        { name: '🎙️ Gravações', value: String(audios.length), inline: true }
      );

      const list = uploaded.map((a) => `• [${a.label || a.name}](${a.url})`).join('\n');
      if (list) embedMain.addFields({ name: '🔗 Arquivos', value: list.slice(0, 1024), inline: false });

      const embeds = [embedMain];
      const imgs = uploaded.filter((a) => isImage(a));
      for (let i = 0; i < Math.min(imgs.length, 9); i++) {
        const img = imgs[i];
        if (!img?.url) continue;
        embeds.push(
          makeImageEmbed({
            title: `📷 ${img.label || `Foto ${i + 1}`}`,
            description: `Investigação: **${inv.name || '—'}**`,
            url: img.url
          })
        );
      }

      const downloadRows = buildDownloadRows(uploaded.map((a) => ({ label: a.label || a.name, url: a.url })));
      const sent = await channel.send({ embeds, components: downloadRows, allowedMentions: { parse: [] } }).catch(() => null);
      if (!sent) return await interaction.editReply(`Mídias salvas, mas falhou ao enviar a embed no canal. (erro: ${errorId})`);

      if (category && category !== 'outra') {
        await updateInvestigation(inv.id, { updated_at: new Date().toISOString() }).catch(() => {});
      }

      return await interaction.editReply(`Mídias registradas com sucesso: ${sent.url}`);
    } catch (err) {
      logger.error(
        { err, command: 'fotos', guildId: interaction.guild?.id || null, userId: interaction.user?.id || null, errorId },
        'Falha no /fotos'
      );
      return await interaction.editReply(`Falha ao registrar as mídias. (erro: ${errorId})`);
    }
  }
};
