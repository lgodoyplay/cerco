const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { BRAND } = require('../config/constants');
const { baseEmbed } = require('../core/embeds/baseEmbed');
const { logger } = require('../lib/logger');
const { getOrCreateGuildConfig } = require('../services/guildConfig');
const { uploadDiscordAttachment, guessContentGroup } = require('../services/mediaStorage');
const { createPrisonRecord, updatePrisonRecord } = require('../database/repositories/prisonRepository');

function normalizeUrl(url) {
  return String(url || '').trim();
}

function isImageAttachment(att) {
  return guessContentGroup(att?.contentType, att?.name) === 'image';
}

function buildDownloadRows(items) {
  const rows = [];
  const list = Array.isArray(items) ? items.filter((i) => i?.url) : [];
  for (let i = 0; i < list.length; i += 5) {
    const slice = list.slice(i, i + 5);
    const row = new ActionRowBuilder().addComponents(
      ...slice.map((it) => new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel(it.label).setURL(it.url))
    );
    rows.push(row);
  }
  return rows.slice(0, 5);
}

function canUsePrison(config, member) {
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  const allowed = new Set([config.roles?.corpRoleId, config.roles?.integration?.policeRoleId, ...(config.roles?.policeRoleIds ?? [])]);
  return [...allowed].some((roleId) => roleId && member.roles.cache.has(roleId));
}

function formatPrisonReason({ motivo, tempo, multa, observacoes }) {
  const lines = [];
  lines.push(`Motivo: ${String(motivo || '').trim()}`);
  if (tempo) lines.push(`Tempo: ${String(tempo).trim()}`);
  if (multa) lines.push(`Multa: ${String(multa).trim()}`);
  if (observacoes) lines.push(`Observações: ${String(observacoes).trim()}`);
  return lines.join('\n');
}

async function finalizeWantedCaptureAfterPrison(client, guild, prisonRecord, prisonLogUrl) {
  const keyPrefix = `${guild.id}:`;
  const pending = client.pendingCaptures || new Map();
  const match = [...pending.entries()]
    .filter(([k]) => k.startsWith(keyPrefix))
    .map(([, v]) => v)
    .find((c) => c.officerId === prisonRecord.author_id && c.wantedId === prisonRecord.prisoner_id);

  if (!match) return;

  const config = await getOrCreateGuildConfig(guild.id);
  const wantedChannel = guild.channels.cache.get(config.channels.wantedLogChannelId);
  if (!wantedChannel || wantedChannel.type !== ChannelType.GuildText) return;

  const message = match.messageId ? await wantedChannel.messages.fetch(match.messageId).catch(() => null) : null;
  if (message) await message.delete().catch(() => {});

  const embed = baseEmbed({
    title: 'Procurado Capturado',
    description: 'Registro automático • Integração Procurados ↔ Prisões',
    color: BRAND.colors.GRAY_DARK
  });

  embed.addFields(
    {
      name: '📌 Procurado',
      value: `Passaporte: **${match.wantedId}**\nOficial responsável: <@${prisonRecord.author_id}>`,
      inline: false
    },
    {
      name: '✅ Status',
      value: `Status: **CAPTURADO/PRESO**\nData: **${match.date || '—'}**\nHorário: **${match.time || '—'}**`,
      inline: false
    }
  );

  if (match.by || match.notes) {
    embed.addFields({
      name: '📝 Detalhes da captura',
      value: `Preso por: **${match.by || '—'}**\nObservações: ${match.notes || '—'}`,
      inline: false
    });
  }

  if (prisonLogUrl) embed.addFields({ name: '🔎 Registro da prisão', value: `[Ver registro](${prisonLogUrl})`, inline: false });

  await wantedChannel.send({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => {});
  pending.delete(`${guild.id}:${match.recordId}`);
  client.pendingCaptures = pending;
}

function makeImageEmbed({ title, description, url }) {
  const e = baseEmbed({ title, description, color: BRAND.colors.GRAY_DARK });
  e.setImage(normalizeUrl(url));
  return e;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('prisao')
    .setDescription('Registra uma prisão com uploads nativos do Discord.')
    .setDefaultMemberPermissions(PermissionFlagsBits.SendMessages)
    .addStringOption((o) => o.setName('nome').setDescription('Nome do suspeito').setRequired(true).setMaxLength(50))
    .addStringOption((o) => o.setName('passaporte').setDescription('Passaporte').setRequired(true).setMaxLength(20))
    .addStringOption((o) => o.setName('motivo').setDescription('Motivo').setRequired(true).setMaxLength(900))
    .addStringOption((o) => o.setName('tempo').setDescription('Tempo de prisão').setRequired(true).setMaxLength(30))
    .addStringOption((o) => o.setName('multa').setDescription('Multa').setRequired(true).setMaxLength(30))
    .addStringOption((o) => o.setName('observacoes').setDescription('Observações').setRequired(true).setMaxLength(900))
    .addAttachmentOption((o) => o.setName('foto_suspeito').setDescription('Foto do suspeito (obrigatória)').setRequired(true))
    .addAttachmentOption((o) => o.setName('foto_mochila').setDescription('Foto da mochila (obrigatória)').setRequired(true))
    .addAttachmentOption((o) => o.setName('foto_tablet').setDescription('Foto do tablet de prisão (obrigatória)').setRequired(true))
    .addAttachmentOption((o) => o.setName('prova_1').setDescription('Prova 1 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('prova_2').setDescription('Prova 2 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('prova_3').setDescription('Prova 3 (opcional)').setRequired(false))
    .addAttachmentOption((o) => o.setName('prova_4').setDescription('Prova 4 (opcional)').setRequired(false)),
  cooldownMs: 5000,
  async execute(client, interaction) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const config = await getOrCreateGuildConfig(interaction.guild.id);
      const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
      if (!canUsePrison(config, member)) {
        return await interaction.editReply('Você não tem permissão para registrar uma prisão.');
      }

      const prisonerName = interaction.options.getString('nome', true).trim();
      const prisonerId = interaction.options.getString('passaporte', true).trim();
      const motivo = interaction.options.getString('motivo', true).trim();
      const tempo = interaction.options.getString('tempo', true).trim();
      const multa = interaction.options.getString('multa', true).trim();
      const obs = interaction.options.getString('observacoes', true).trim();

      const fotoSuspeito = interaction.options.getAttachment('foto_suspeito', true);
      const fotoMochila = interaction.options.getAttachment('foto_mochila', true);
      const fotoTablet = interaction.options.getAttachment('foto_tablet', true);
      const provas = [
        interaction.options.getAttachment('prova_1', false),
        interaction.options.getAttachment('prova_2', false),
        interaction.options.getAttachment('prova_3', false),
        interaction.options.getAttachment('prova_4', false)
      ].filter(Boolean);

      const all = [fotoSuspeito, fotoMochila, fotoTablet, ...provas];
      if (all.some((a) => !isImageAttachment(a))) {
        return await interaction.editReply('Envie apenas imagens (PNG/JPG/WEBP/GIF) nas opções de fotos/provas.');
      }

      const record = await createPrisonRecord({
        guildId: interaction.guild.id,
        authorId: interaction.user.id,
        prisonerName,
        prisonerId,
        reason: formatPrisonReason({ motivo, tempo, multa, observacoes: obs })
      });

      const logChannel = interaction.guild.channels.cache.get(config.channels.prisonLogChannelId);
      if (!logChannel || logChannel.type !== ChannelType.GuildText) {
        return await interaction.editReply('Canal de logs de prisão não configurado ou inválido.');
      }

      const uSuspeito = await uploadDiscordAttachment({
        kind: 'prisoes',
        guildId: interaction.guild.id,
        userId: interaction.user.id,
        recordId: record.id,
        attachment: fotoSuspeito,
        tag: 'suspeito'
      });
      const uMochila = await uploadDiscordAttachment({
        kind: 'prisoes',
        guildId: interaction.guild.id,
        userId: interaction.user.id,
        recordId: record.id,
        attachment: fotoMochila,
        tag: 'mochila'
      });
      const uTablet = await uploadDiscordAttachment({
        kind: 'prisoes',
        guildId: interaction.guild.id,
        userId: interaction.user.id,
        recordId: record.id,
        attachment: fotoTablet,
        tag: 'tablet'
      });

      const uProvas = [];
      for (let i = 0; i < Math.min(provas.length, 4); i++) {
        uProvas.push(
          await uploadDiscordAttachment({
            kind: 'prisoes',
            guildId: interaction.guild.id,
            userId: interaction.user.id,
            recordId: record.id,
            attachment: provas[i],
            tag: `prova-${i + 1}`
          })
        );
      }

      if (!uSuspeito?.url || !uMochila?.url || !uTablet?.url) {
        return await interaction.editReply('Falha ao processar as mídias. Reenvie as imagens e tente novamente.');
      }

      const dbFiles = {
        rosto: { url: uSuspeito.url, name: fotoSuspeito.name || 'suspeito' },
        mochila: { url: uMochila.url, name: fotoMochila.name || 'mochila' },
        tablet: { url: uTablet.url, name: fotoTablet.name || 'tablet' },
        extras: uProvas.map((u, idx) => ({ url: u.url, name: provas[idx]?.name || `prova-${idx + 1}` })).filter((e) => e.url)
      };
      await updatePrisonRecord(record.id, { files: dbFiles }).catch(() => {});

      const embedMain = baseEmbed({
        title: '🚔 REGISTRO DE PRISÃO',
        description: 'Sistema policial • Registro oficial',
        color: BRAND.colors.GRAY_DARK
      });
      embedMain.setThumbnail(uSuspeito.url);
      embedMain.setImage(uSuspeito.url);
      embedMain.addFields(
        {
          name: '👤 INFORMAÇÕES DO PRESO',
          value:
            `📌 Nome: **${record.prisoner_name}**\n` +
            `🆔 Passaporte: **${record.prisoner_id}**\n` +
            `⚠️ Motivo: **${motivo}**\n` +
            `⏳ Tempo: **${tempo}**\n` +
            `💰 Multa: **${multa}**\n` +
            `📝 Observações: **${obs || '—'}**`,
          inline: false
        },
        {
          name: '👮 RESPONSÁVEL',
          value:
            `👤 Oficial: <@${record.author_id}>\n` +
            `📅 Data/Hora: <t:${Math.floor(new Date(record.created_at).getTime() / 1000)}:F>`,
          inline: false
        }
      );

      const embeds = [
        embedMain,
        makeImageEmbed({ title: '🎒 MOCHILA', description: `Passaporte: **${record.prisoner_id}**`, url: uMochila.url }),
        makeImageEmbed({ title: '📱 TABLET', description: `Passaporte: **${record.prisoner_id}**`, url: uTablet.url })
      ];

      for (let i = 0; i < uProvas.length; i++) {
        const u = uProvas[i];
        if (!u?.url) continue;
        embeds.push(makeImageEmbed({ title: `📎 PROVA ${i + 1}`, description: `Passaporte: **${record.prisoner_id}**`, url: u.url }));
      }

      const downloadRows = buildDownloadRows([
        { label: 'Suspeito', url: uSuspeito.url },
        { label: 'Mochila', url: uMochila.url },
        { label: 'Tablet', url: uTablet.url },
        ...uProvas.map((u, idx) => ({ label: `Prova ${idx + 1}`, url: u.url }))
      ]);

      const sent = await logChannel.send({ embeds, components: downloadRows, allowedMentions: { parse: [] } }).catch(() => null);
      await finalizeWantedCaptureAfterPrison(client, interaction.guild, record, sent?.url || null).catch(() => {});

      if (!sent) return await interaction.editReply('Prisão registrada, mas falhou ao enviar as embeds no canal de logs.');
      return await interaction.editReply(`Prisão registrada com sucesso: ${sent.url}`);
    } catch (err) {
      const errorId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      logger.error(
        {
          err,
          command: 'prisao',
          guildId: interaction.guild?.id || null,
          userId: interaction.user?.id || null,
          errorId
        },
        'Falha no /prisao'
      );
      const msg = String(err?.message || '').toLowerCase();
      if (String(err?.message || '') === 'UNSUPPORTED_MEDIA_TYPE') {
        return await interaction.editReply(
          `Tipo de arquivo não suportado. Envie apenas imagens/vídeos/áudios/PDFs. (erro: ${errorId})`
        );
      }
      if (msg.includes('attachment_invalid')) {
        return await interaction.editReply(`Anexo inválido. Reenvie as imagens e tente novamente. (erro: ${errorId})`);
      }
      return await interaction.editReply(`Falha ao registrar a prisão. (erro: ${errorId})`);
    }
  }
};
