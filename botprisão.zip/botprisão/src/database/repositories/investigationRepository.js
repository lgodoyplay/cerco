const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createInvestigation({ guildId, channelId, creatorId, name, reason }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    channel_id: asId(channelId),
    creator_id: asId(creatorId),
    name,
    reason,
    status: 'OPEN',
    closed_at: null,
    pdf: null,
    closure_checklist_message_id: null,
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'investigations');
    store[id] = record;
  });
  return record;
}

async function getOpenInvestigationByChannel(channelId) {
  const db = getLocalDb();
  const store = ensureStore(db, 'investigations');
  const cid = asId(channelId);
  for (const inv of Object.values(store)) {
    if (!inv) continue;
    if (String(inv.channel_id) === cid && String(inv.status) === 'OPEN') return inv;
  }
  return null;
}

async function getInvestigationById(id) {
  const db = getLocalDb();
  const store = ensureStore(db, 'investigations');
  return store[asId(id)] ?? null;
}

async function updateInvestigation(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'investigations');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

module.exports = { createInvestigation, getOpenInvestigationByChannel, getInvestigationById, updateInvestigation };