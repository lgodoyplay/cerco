const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createPromotionRequest({ guildId, requesterId, requestedRoleId, inGameName, passport, currentRank, reason, channelId, messageId }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    requester_id: asId(requesterId),
    requested_role_id: asId(requestedRoleId),
    in_game_name: inGameName,
    passport,
    current_rank: currentRank || null,
    reason,
    status: 'PENDING',
    reviewed_by: null,
    reviewed_at: null,
    channel_id: asId(channelId),
    message_id: asId(messageId),
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'promotion_requests');
    store[id] = record;
  });
  return record;
}

async function getPromotionRequestById(id) {
  const db = getLocalDb();
  const store = ensureStore(db, 'promotion_requests');
  return store[asId(id)] ?? null;
}

async function getPromotionRequestByMessageId(messageId) {
  const db = getLocalDb();
  const store = ensureStore(db, 'promotion_requests');
  const mid = asId(messageId);
  for (const r of Object.values(store)) {
    if (!r) continue;
    if (String(r.message_id) === mid) return r;
  }
  return null;
}

async function updatePromotionRequest(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'promotion_requests');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

module.exports = {
  createPromotionRequest,
  getPromotionRequestById,
  getPromotionRequestByMessageId,
  updatePromotionRequest
};