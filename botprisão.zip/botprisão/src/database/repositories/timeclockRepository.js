const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createTimeclockRecord({ guildId, userId, openReason }) {
  const id = `${asId(guildId)}:${asId(userId)}:${nowIso()}`;
  const record = {
    id,
    guild_id: asId(guildId),
    user_id: asId(userId),
    status: 'OPEN',
    opened_at: nowIso(),
    open_reason: openReason,
    close_summary: null,
    closed_at: null,
    total_blocks: 0,
    total_amount: 0,
    last_block_count: 0,
    last_reward_at: null,
    log_channel_id: null,
    log_message_id: null,
    payment_status: 'PENDING',
    payment_by: null,
    payment_at: null,
    payment_reason: null
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'timeclocks');
    store[id] = record;
  });
  return record;
}

async function getOpenTimeclockByUser(guildId, userId) {
  const db = getLocalDb();
  const store = ensureStore(db, 'timeclocks');
  const gid = asId(guildId);
  const uid = asId(userId);
  for (const r of Object.values(store)) {
    if (!r) continue;
    if (String(r.guild_id) !== gid) continue;
    if (String(r.user_id) !== uid) continue;
    if (String(r.status) === 'OPEN') return r;
  }
  return null;
}

async function updateTimeclock(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'timeclocks');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

module.exports = { createTimeclockRecord, getOpenTimeclockByUser, updateTimeclock };