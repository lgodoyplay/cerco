const { getLocalDb, withWrite } = require('../../database/localDb');

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function getOrCreateGuildConfig(guildId) {
  const db = getLocalDb();
  const id = asId(guildId);
  const existing = db.guild_configs?.[id] ?? null;
  if (existing) {
    return { guildId: id, ...existing };
  }
  return null;
}

async function setGuildConfig(guildId, config) {
  await withWrite(async (d) => {
    d.guild_configs[asId(guildId)] = config;
  });
}

async function updateGuildPanels(guildId, panels) {
  const id = asId(guildId);
  await withWrite(async (d) => {
    const current = d.guild_configs[id];
    d.guild_configs[id] = { ...current, panels };
  });
}

module.exports = { getOrCreateGuildConfig, setGuildConfig, updateGuildPanels };