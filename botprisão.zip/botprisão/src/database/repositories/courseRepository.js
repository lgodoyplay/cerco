const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createCourseRequest({ guildId, requesterId, roleId, inGameName, passport, availability, days, notes, channelId, messageId }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    requester_id: asId(requesterId),
    role_id: asId(roleId),
    in_game_name: inGameName,
    passport,
    availability,
    days: days || null,
    notes: notes || null,
    channel_id: asId(channelId),
    message_id: asId(messageId),
    status: 'PENDING',
    instructed_by: null,
    instructed_at: null,
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'course_requests');
    store[id] = record;
  });
  return record;
}

async function getCourseRequestByMessageId(messageId) {
  const db = getLocalDb();
  const store = ensureStore(db, 'course_requests');
  const mid = asId(messageId);
  for (const r of Object.values(store)) {
    if (!r) continue;
    if (String(r.message_id) === mid) return r;
  }
  return null;
}

async function markCourseRequestInstructed(messageId, { instructedBy }) {
  const existing = await getCourseRequestByMessageId(messageId);
  if (!existing) return null;
  const patch = { status: 'INSTRUCTED', instructed_by: asId(instructedBy), instructed_at: nowIso() };
  return await updateCourseRequest(existing.id, patch);
}

async function updateCourseRequest(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'course_requests');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

module.exports = { createCourseRequest, getCourseRequestByMessageId, markCourseRequestInstructed, updateCourseRequest };