const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createTicket({ guildId, channelId, openerId }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    channel_id: asId(channelId),
    opener_id: asId(openerId),
    status: 'OPEN',
    closed_by: null,
    closed_at: null,
    transcript: [],
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'tickets');
    store[id] = record;
  });
  return record;
}

async function getOpenTicketByChannel(channelId) {
  const db = getLocalDb();
  const store = ensureStore(db, 'tickets');
  const cid = asId(channelId);
  for (const t of Object.values(store)) {
    if (!t) continue;
    if (String(t.channel_id) === cid && String(t.status) === 'OPEN') return t;
  }
  return null;
}

async function closeTicketByChannel(channelId, { closedBy, transcript }) {
  const open = await getOpenTicketByChannel(channelId);
  if (!open) return null;
  const id = asId(open.id);
  const patch = {
    status: 'CLOSED',
    closed_by: asId(closedBy),
    closed_at: nowIso(),
    transcript
  };
  return await updateTicket(id, patch);
}

async function updateTicket(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'tickets');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

module.exports = { createTicket, getOpenTicketByChannel, closeTicketByChannel, updateTicket };