const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createEvidence({ guildId, investigationId, channelId, authorId, personName, personId, description, links }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    investigation_id: asId(investigationId),
    channel_id: asId(channelId),
    author_id: asId(authorId),
    person_name: personName,
    person_id: personId,
    description,
    links: links || null,
    attachments: [],
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'evidences');
    store[id] = record;
  });
  return record;
}

async function getEvidenceById(id) {
  const db = getLocalDb();
  const store = ensureStore(db, 'evidences');
  return store[asId(id)] ?? null;
}

async function updateEvidence(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'evidences');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

async function getEvidencesByInvestigationId(investigationId) {
  const db = getLocalDb();
  const store = ensureStore(db, 'evidences');
  const invId = asId(investigationId);
  const out = [];
  for (const ev of Object.values(store)) {
    if (!ev) continue;
    if (String(ev.investigation_id) !== invId) continue;
    out.push(ev);
  }
  out.sort((a, b) => String(a.created_at || '').localeCompare(String(b.created_at || '')));
  return out;
}

async function countEvidencesByInvestigationId(investigationId) {
  const db = getLocalDb();
  const store = ensureStore(db, 'evidences');
  const invId = asId(investigationId);
  let count = 0;
  for (const ev of Object.values(store)) {
    if (!ev) continue;
    if (String(ev.investigation_id) === invId) count++;
  }
  return count;
}

module.exports = { createEvidence, getEvidenceById, updateEvidence, getEvidencesByInvestigationId, countEvidencesByInvestigationId };