const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function upsertMemberProfile({ guildId, userId, inGameName, passport, verifiedAt, nickname }) {
  const id = `${asId(guildId)}:${asId(userId)}`;
  const record = {
    id,
    guild_id: asId(guildId),
    user_id: asId(userId),
    in_game_name: inGameName,
    passport,
    verified_at: verifiedAt,
    nickname
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'member_profiles');
    store[id] = record;
  });
  return record;
}

async function getMemberProfile(guildId, userId) {
  const db = getLocalDb();
  const store = ensureStore(db, 'member_profiles');
  return store[`${asId(guildId)}:${asId(userId)}`] ?? null;
}

module.exports = { upsertMemberProfile, getMemberProfile };