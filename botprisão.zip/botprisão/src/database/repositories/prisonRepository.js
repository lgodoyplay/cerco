const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createPrisonRecord({ guildId, authorId, prisonerName, prisonerId, reason }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    author_id: asId(authorId),
    prisoner_name: prisonerName,
    prisoner_id: prisonerId,
    reason,
    files: { mochila: null, rosto: null, tablet: null, extras: [] },
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'prison_records');
    store[id] = record;
  });
  return record;
}

async function getPrisonRecordById(id) {
  const db = getLocalDb();
  const store = ensureStore(db, 'prison_records');
  return store[asId(id)] ?? null;
}

async function updatePrisonRecord(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'prison_records');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

module.exports = { createPrisonRecord, getPrisonRecordById, updatePrisonRecord };