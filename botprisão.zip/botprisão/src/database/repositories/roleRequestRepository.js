const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createRoleSelectionRequest({ guildId, userId }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    user_id: asId(userId),
    selected_role_ids: [],
    status: 'PENDING',
    reviewed_by: null,
    reviewed_at: null,
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'role_requests');
    store[id] = record;
  });
  return record;
}

async function getRoleSelectionRequestById(id) {
  const db = getLocalDb();
  const store = ensureStore(db, 'role_requests');
  return store[asId(id)] ?? null;
}

async function updateRoleSelectionRequest(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'role_requests');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

module.exports = { createRoleSelectionRequest, getRoleSelectionRequestById, updateRoleSelectionRequest };