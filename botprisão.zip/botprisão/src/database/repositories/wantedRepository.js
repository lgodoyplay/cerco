const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createWantedRecord({ guildId, authorId, wantedName, wantedId, reason, links }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    author_id: asId(authorId),
    wanted_name: wantedName,
    wanted_id: asId(wantedId),
    reason,
    links: links || null,
    proofs: [],
    status: 'ACTIVE',
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'wanted_records');
    store[id] = record;
  });
  return record;
}

async function getWantedRecordById(id) {
  const db = getLocalDb();
  const store = ensureStore(db, 'wanted_records');
  return store[asId(id)] ?? null;
}

async function updateWantedRecord(id, patch) {
  const key = asId(id);
  let updated = null;
  await withWrite(async (d) => {
    const store = ensureStore(d, 'wanted_records');
    const current = store[key] ?? null;
    if (!current) {
      updated = null;
      return;
    }
    updated = { ...current, ...patch };
    store[key] = updated;
  });
  return updated;
}

module.exports = { createWantedRecord, getWantedRecordById, updateWantedRecord };