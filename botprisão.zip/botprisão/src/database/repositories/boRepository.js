const { randomUUID } = require('node:crypto');
const { getLocalDb, withWrite } = require('../../database/localDb');

function nowIso() {
  return new Date().toISOString();
}

function ensureStore(db, key) {
  if (!db[key] || typeof db[key] !== 'object') db[key] = {};
  return db[key];
}

function asId(id) {
  return String(id);
}

async function createBORecord({ guildId, authorId, requesterName, requesterId, occurred, links }) {
  const id = randomUUID();
  const record = {
    id,
    guild_id: asId(guildId),
    author_id: asId(authorId),
    requester_name: requesterName,
    requester_id: requesterId,
    occurred,
    links: links || null,
    created_at: nowIso()
  };
  await withWrite(async (d) => {
    const store = ensureStore(d, 'bo_records');
    store[id] = record;
  });
  return record;
}

async function getBORecordById(id) {
  const db = getLocalDb();
  const store = ensureStore(db, 'bo_records');
  return store[asId(id)] ?? null;
}

module.exports = { createBORecord, getBORecordById };