const { logger } = require('../lib/logger');
const { initLocalDb } = require('./localDb');

async function connectDatabase() {
  await initLocalDb();
  logger.info('Banco local inicializado');
}

module.exports = { connectDatabase };