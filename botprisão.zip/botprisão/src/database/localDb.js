const fs = require('node:fs/promises');
const path = require('node:path');

let state = null;
let writeQueue = Promise.resolve();

function dbFilePath() {
  return path.join(process.cwd(), 'data', 'pc_local_db.json');
}

async function ensureDir() {
  const dir = path.dirname(dbFilePath());
  await fs.mkdir(dir, { recursive: true });
}

async function loadFile() {
  await ensureDir();
  const file = dbFilePath();
  try {
    const raw = await fs.readFile(file, 'utf8');
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch (err) {
    if (err?.code === 'ENOENT') return null;
    throw err;
  }
}

async function persistFile(data) {
  await ensureDir();
  const file = dbFilePath();
  const tmp = `${file}.tmp`;
  const json = JSON.stringify(data, null, 2);
  await fs.writeFile(tmp, json, 'utf8');
  await fs.rm(file, { force: true }).catch(() => {});
  await fs.rename(tmp, file);
}

function defaultDb() {
  return {
    _meta: { version: 1, created_at: new Date().toISOString() },
    guild_configs: {},
    member_profiles: {},
    role_requests: {},
    investigations: {},
    evidences: {},
    bo_records: {},
    prison_records: {},
    wanted_records: {},
    timeclocks: {},
    tickets: {},
     course_requests: {},
     promotion_requests: {}
  };
}

async function initLocalDb() {
  if (state) return state;
  const loaded = await loadFile();
  state = loaded || defaultDb();
  if (!loaded) await persistFile(state);
  return state;
}

function getLocalDb() {
  if (!state) throw new Error('Local DB não inicializado.');
  return state;
}

async function withWrite(mutator) {
  writeQueue = writeQueue.then(async () => {
    const db = getLocalDb();
    await mutator(db);
    await persistFile(db);
  });
  return writeQueue;
}

module.exports = { initLocalDb, getLocalDb, withWrite };