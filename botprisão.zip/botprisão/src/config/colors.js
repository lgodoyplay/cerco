const COLORS = {
  BLUE: 0x0a4ea3,
  DARK: 0x0b0b0b,
  GRAY_DARK: 0x1f1f1f
};

module.exports = { COLORS };