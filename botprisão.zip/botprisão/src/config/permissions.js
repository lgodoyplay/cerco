const PERMISSIONS = {
  ADMINISTRATOR: 'Administrator',
  MANAGE_CHANNELS: 'ManageChannels',
  MANAGE_ROLES: 'ManageRoles',
  VIEW_CHANNEL: 'ViewChannel',
  SEND_MESSAGES: 'SendMessages',
  READ_MESSAGE_HISTORY: 'ReadMessageHistory'
};

module.exports = { PERMISSIONS };