const { COLORS } = require('./colors');
const { DEFAULT_GUILD_ROLES } = require('./roles');
const { DEFAULT_GUILD_CHANNELS } = require('./channels');
const { DEFAULT_GUILD_PANELS } = require('./panels');
const { BRAND } = require('./constants');

const DEFAULT_GUILD_CONFIG = {
  roles: DEFAULT_GUILD_ROLES,
  channels: DEFAULT_GUILD_CHANNELS,
  panels: DEFAULT_GUILD_PANELS
};

module.exports = { BRAND, DEFAULT_GUILD_CONFIG, COLORS, DEFAULT_GUILD_ROLES, DEFAULT_GUILD_CHANNELS, DEFAULT_GUILD_PANELS };