const DEFAULT_GUILD_CHANNELS = {
  verificationChannelId: '1504280532572307607',
  approvalChannelId: '1504295038262186076',
  investigationChannelId: '1504301073534550117',
  investigationCategoryId: '1504302179702542426',
  investigationFinalChannelId: '1504303393659686912',
  boPanelChannelId: '1504304478172614667',
  boLogChannelId: '1504303762653843658',
  prisonPanelChannelId: '1504303911987707945',
  prisonLogChannelId: '1504305958552338472',
  prisonMediaChannelId: null,
  wantedPanelChannelId: '1504306325490896976',
  wantedLogChannelId: '1504306354850889769',
  wantedMediaChannelId: null,
  coursesPanelChannelId: '1504560777808445660',
  coursesRequestChannelId: '1504560999104123020',
  noticesPanelChannelId: '1504570851591458960',
  noticesChannelId: '1504549601770737775',
  exonerationPanelChannelId: '1504571497178599545',
  exonerationLogChannelId: '1504571890037952532',
  corregedoriaPanelChannelId: '1504308133684838420',
  ticketCategoryId: '1504308710711886025',
  promotionPanelChannelId: '1531064935285526528',
  promotionLogChannelId: '1531064997155835954',
  spamChannelId: '1531081341079261455'
};

module.exports = { DEFAULT_GUILD_CHANNELS };