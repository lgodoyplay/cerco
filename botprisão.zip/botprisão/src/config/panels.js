const DEFAULT_GUILD_PANELS = {
  verificationMessageId: null,
  investigationMessageId: null,
  boMessageId: null,
  prisonMessageId: null,
  wantedMessageId: null,
  coursesMessageId: null,
  noticesMessageId: null,
  exonerationMessageId: null,
  corregedoriaMessageId: null,
  promotionMessageId: null
};

module.exports = { DEFAULT_GUILD_PANELS };