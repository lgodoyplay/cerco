const { baseEmbed } = require('./baseEmbed');

function errorEmbed({ title, description } = {}) {
  const embed = baseEmbed({ title, description, color: 0xed4245 });
  return embed;
}

module.exports = { errorEmbed };