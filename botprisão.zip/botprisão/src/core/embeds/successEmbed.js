const { baseEmbed } = require('./baseEmbed');

function successEmbed({ title, description } = {}) {
  const embed = baseEmbed({ title, description, color: 0x2b2d31 });
  return embed;
}

module.exports = { successEmbed };