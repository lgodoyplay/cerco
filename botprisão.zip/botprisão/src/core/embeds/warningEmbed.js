const { baseEmbed } = require('./baseEmbed');

function warningEmbed({ title, description } = {}) {
  const embed = baseEmbed({ title, description, color: 0xfee75c });
  return embed;
}

module.exports = { warningEmbed };