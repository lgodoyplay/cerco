const { EmbedBuilder } = require('discord.js');
const { BRAND } = require('../../config/constants');

function baseEmbed({ title, description, color } = {}) {
  const embed = new EmbedBuilder()
    .setColor(color ?? BRAND.colors.BLUE)
    .setTimestamp(new Date())
    .setFooter({ text: BRAND.name });

  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);

  return embed;
}

module.exports = { baseEmbed };